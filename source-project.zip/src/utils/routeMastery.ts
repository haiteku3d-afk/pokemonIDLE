import { EncounterRate } from '../types/pokemon';
import { POKEMON_BY_ID } from '../data/pokemon151';

export const ROUTE_MASTERY_THRESHOLDS = [50, 150, 300, 500, 800];

export function getRouteMastery(victories: number) {
  const rank = ROUTE_MASTERY_THRESHOLDS.filter(goal => victories >= goal).length;
  return { rank, chance: rank / 100, nextGoal: ROUTE_MASTERY_THRESHOLDS[rank] ?? null };
}

// Solo una evolución por nivel, disponible dentro del tope de medallas.
export function getMasteryEvolutionTable(table: EncounterRate[], cap: number, badges: string[]): EncounterRate[] {
  if (!badges.includes('boulder')) return [];
  return table.flatMap(entry => {
    const evolution = POKEMON_BY_ID[entry.speciesId]?.evolution;
    if (!evolution || evolution.type !== 'level' || evolution.level > cap) return [];
    return [{ ...entry, speciesId: evolution.into, minLevel: Math.min(cap, Math.max(entry.minLevel, evolution.level)), maxLevel: Math.min(cap, Math.max(entry.maxLevel, evolution.level)) }];
  });
}
