import { StatusCondition } from '../types/moves';

export interface StatusBadgeInfo {
  code: string;
  name: string;
  bgColor: string;
  textColor: string;
  effectDesc: string;
}

export const STATUS_CONFIG: Record<StatusCondition, StatusBadgeInfo> = {
  quemadura: {
    code: 'QUE',
    name: 'Quemadura',
    bgColor: '#d44f33',
    textColor: '#ffffff',
    effectDesc: 'Pierde 1/16 de PS por turno y su Ataque físico se reduce al 50%.',
  },
  paralisis: {
    code: 'PAR',
    name: 'Parálisis',
    bgColor: '#d89b25',
    textColor: '#ffffff',
    effectDesc: 'Velocidad efectiva reducida al 50% y 25% de probabilidad de no atacar.',
  },
  sueno: {
    code: 'DOR',
    name: 'Sueño',
    bgColor: '#7a8599',
    textColor: '#ffffff',
    effectDesc: 'Profundamente dormido: no puede atacar hasta despertar.',
  },
  veneno: {
    code: 'VEN',
    name: 'Veneno',
    bgColor: '#8a4baf',
    textColor: '#ffffff',
    effectDesc: 'Pierde 1/16 de PS por turno a causa de las toxinas.',
  },
};
