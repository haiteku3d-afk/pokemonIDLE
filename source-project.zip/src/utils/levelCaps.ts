/**
 * Sistema centralizado de Límites de Nivel por Medallas en Kanto Sobres:
 * - Antes de Brock: Nivel 14
 * - Tras Brock (Medalla Roca): Nivel 21
 * - Tras Misty (Medalla Cascada): Nivel 24
 * - Tras Lt. Surge (Medalla Trueno): Nivel 29
 * - Tras Erika (Medalla Arcoíris): Nivel 43
 * - Tras Koga (Medalla Alma): Nivel 43
 * - Tras Sabrina (Medalla Pantano): Nivel 47
 * - Tras Blaine (Medalla Volcán): Nivel 50
 * - Tras Giovanni (Medalla Tierra): Nivel 65
 * - Tras la Liga Pokémon (Campeón): Nivel 100
 */

export interface LevelCapInfo {
  cap: number;
  nextLeaderName: string;
  nextLeaderCity: string;
  badgeRequired: string;
  isMax: boolean;
}

export function getLevelCap(badges: string[] = []): LevelCapInfo {
  const badgeSet = new Set(badges);

  if (badgeSet.has('champion') || badgeSet.has('champion_ribbon')) {
    return {
      cap: 100,
      nextLeaderName: 'Campeón de Kanto',
      nextLeaderCity: 'Meseta Añil',
      badgeRequired: '',
      isMax: true,
    };
  }
  if (badgeSet.has('earth')) {
    return {
      cap: 65,
      nextLeaderName: 'Alto Mando y Campeón',
      nextLeaderCity: 'Meseta Añil',
      badgeRequired: 'champion',
      isMax: false,
    };
  }
  if (badgeSet.has('volcano')) {
    return {
      cap: 50,
      nextLeaderName: 'Giovanni',
      nextLeaderCity: 'Ciudad Verde',
      badgeRequired: 'earth',
      isMax: false,
    };
  }
  if (badgeSet.has('marsh')) {
    return {
      cap: 47,
      nextLeaderName: 'Blaine',
      nextLeaderCity: 'Isla Canela',
      badgeRequired: 'volcano',
      isMax: false,
    };
  }
  if (badgeSet.has('soul')) {
    return {
      cap: 43,
      nextLeaderName: 'Sabrina',
      nextLeaderCity: 'Ciudad Azafrán',
      badgeRequired: 'marsh',
      isMax: false,
    };
  }
  if (badgeSet.has('rainbow')) {
    return {
      cap: 43,
      nextLeaderName: 'Koga',
      nextLeaderCity: 'Ciudad Fucsia',
      badgeRequired: 'soul',
      isMax: false,
    };
  }
  if (badgeSet.has('thunder')) {
    return {
      cap: 29,
      nextLeaderName: 'Erika',
      nextLeaderCity: 'Ciudad Azulona',
      badgeRequired: 'rainbow',
      isMax: false,
    };
  }
  if (badgeSet.has('cascade')) {
    return {
      cap: 24,
      nextLeaderName: 'Lt. Surge',
      nextLeaderCity: 'Ciudad Carmín',
      badgeRequired: 'thunder',
      isMax: false,
    };
  }
  if (badgeSet.has('boulder')) {
    return {
      cap: 21,
      nextLeaderName: 'Misty',
      nextLeaderCity: 'Ciudad Celeste',
      badgeRequired: 'cascade',
      isMax: false,
    };
  }

  return {
    cap: 14,
    nextLeaderName: 'Brock',
    nextLeaderCity: 'Ciudad Plateada',
    badgeRequired: 'boulder',
    isMax: false,
  };
}

/**
 * Retorna el nivel efectivo de un Pokémon respetando el límite por medallas.
 * Si el nivel real es mayor (ej. partidas antiguas), se topa al límite en expedición
 * sin borrar el nivel histórico del Pokémon.
 */
export function getEffectiveLevel(realLevel: number, badges: string[] = []): number {
  const { cap } = getLevelCap(badges);
  return Math.min(realLevel, cap);
}
