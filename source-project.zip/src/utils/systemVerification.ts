/**
 * Pruebas unitarias de las funciones de lógica clave:
 * 1. Cálculo de velocidad e intervalo de ataque (Regla A)
 * 2. Progresión y desbloqueo de rutas por victorias (Regla B)
 * 3. Límites de nivel por medallas y nivel efectivo (Regla D)
 * 4. Curva de EXP y diferencia de niveles
 */

import {
  getAttackIntervalMs,
  getEffectiveSpeed,
  getLevelDifferenceExpFactor,
  applyStatusTickDamage,
  isImmuneToStatus,
  executeMoveInCombat,
  CombatantSnapshot,
} from './combatEngine';
import { getLevelCap, getEffectiveLevel } from './levelCaps';
import { isZoneUnlockable, KANTO_ZONES } from '../data/zones';
import { SHOP_ITEMS, SHOP_ITEMS_BY_ID } from '../data/items';
import { SPECIAL_TRIALS } from '../data/specialTrials';

export function runSystemVerificationTests() {
  const results: { test: string; passed: boolean; details: string }[] = [];

  // Test 1: Intervalo de ataque según velocidad (clamp 1000 - 4000 ms)
  const intervalSlow = getAttackIntervalMs(0); // clamp(4000 / (1 + 1/50)) = 3922ms
  const intervalBase = getAttackIntervalMs(50);
  const intervalFast = getAttackIntervalMs(150);
  const intervalExtreme = getAttackIntervalMs(500);

  const t1Passed =
    intervalSlow === 3922 &&
    intervalBase === 2000 &&
    intervalFast === 1000 &&
    intervalExtreme === 1000;
  results.push({
    test: 'A) Fórmula de velocidad clamp(4000/(1+vel/50), 1000, 4000)',
    passed: t1Passed,
    details: `vel 0 -> ${intervalSlow}ms, vel 50 -> ${intervalBase}ms, vel 150 -> ${intervalFast}ms, vel 500 -> ${intervalExtreme}ms`,
  });

  // Test 2: Etapas de combate en velocidad
  const boostedSpeed = getEffectiveSpeed(50, 2); // +2 etapas = x2 -> 100
  const reducedSpeed = getEffectiveSpeed(50, -2); // -2 etapas = x0.5 -> 25
  const t2Passed = boostedSpeed === 100 && reducedSpeed === 25;
  results.push({
    test: 'A) Etapas de velocidad efectivas (Agilidad / reducción)',
    passed: t2Passed,
    details: `Base 50 con +2 etapas = ${boostedSpeed}; con -2 etapas = ${reducedSpeed}`,
  });

  // Test 3: Desbloqueo de Ruta 2 (requiere 10 victorias en Ruta 1)
  const route2 = KANTO_ZONES.find((z) => z.id === 'route-2');
  const r2UnlockedWith9 = route2 ? isZoneUnlockable(route2, ['route-1'], { 'route-1': 9 }, []) : false;
  const r2UnlockedWith10 = route2 ? isZoneUnlockable(route2, ['route-1'], { 'route-1': 10 }, []) : false;
  const t3Passed = !r2UnlockedWith9 && r2UnlockedWith10;
  results.push({
    test: 'B) Ruta 1 requiere exactamente 10 victorias para Ruta 2',
    passed: t3Passed,
    details: `9 victorias = desbloquea ${r2UnlockedWith9}; 10 victorias = desbloquea ${r2UnlockedWith10}`,
  });

  // Test 4: Ruta 3 requiere Medalla Roca y Monte Moon requiere 20 victorias en Ruta 3
  const route3 = KANTO_ZONES.find((z) => z.id === 'route-3');
  const r3WithNoBadge = route3 ? isZoneUnlockable(route3, ['route-2'], { 'route-2': 25 }, []) : false;
  const r3WithBadge = route3 ? isZoneUnlockable(route3, ['route-2'], { 'route-2': 25 }, ['boulder']) : false;
  const mtMoon = KANTO_ZONES.find((z) => z.id === 'mt-moon');
  const mmWith19 = mtMoon ? isZoneUnlockable(mtMoon, ['route-3'], { 'route-3': 19 }, ['boulder']) : false;
  const mmWith20 = mtMoon ? isZoneUnlockable(mtMoon, ['route-3'], { 'route-3': 20 }, ['boulder']) : false;
  const t4Passed = !r3WithNoBadge && r3WithBadge && !mmWith19 && mmWith20;
  results.push({
    test: 'B) Ruta 3 requiere Medalla Roca y Monte Moon requiere 20 victorias en Ruta 3',
    passed: t4Passed,
    details: `R3 sin medalla = ${r3WithNoBadge}; R3 con medalla = ${r3WithBadge}; MM con 19 vic = ${mmWith19}; MM con 20 vic = ${mmWith20}`,
  });

  // Test 5: Límites de nivel según medallas (Regla D)
  const capZeroBadges = getLevelCap([]).cap; // Antes de Brock: 14
  const capBrock = getLevelCap(['boulder']).cap; // Tras Brock: 21
  const capMisty = getLevelCap(['boulder', 'cascade']).cap; // Tras Misty: 24
  const capSurge = getLevelCap(['boulder', 'cascade', 'thunder']).cap; // Tras Surge: 29
  const capAll = getLevelCap(['boulder', 'cascade', 'thunder', 'rainbow', 'soul', 'marsh', 'volcano', 'earth', 'champion']).cap; // 100

  const t5Passed =
    capZeroBadges === 14 &&
    capBrock === 21 &&
    capMisty === 24 &&
    capSurge === 29 &&
    capAll === 100;
  results.push({
    test: 'D) Escalado estricto de topes de medalla (14, 21, 24, 29... 100)',
    passed: t5Passed,
    details: `0 medallas = Nv.${capZeroBadges}, Brock = Nv.${capBrock}, Misty = Nv.${capMisty}, Surge = Nv.${capSurge}, Liga = Nv.${capAll}`,
  });

  // Test 6: Nivel efectivo con Pokémon heredado por encima del tope
  const effLvlBeforeBrock = getEffectiveLevel(25, []); // Nivel real 25, tope 14 -> 14
  const effLvlAfterBrock = getEffectiveLevel(25, ['boulder']); // Nivel real 25, tope 21 -> 21
  const effLvlLow = getEffectiveLevel(10, []); // Nivel real 10, tope 14 -> 10
  const t6Passed = effLvlBeforeBrock === 14 && effLvlAfterBrock === 21 && effLvlLow === 10;
  results.push({
    test: 'D) min(real, cap): preserva nivel real y aplica efectivo sin borrar progreso',
    passed: t6Passed,
    details: `Real 25 sin medallas = ${effLvlBeforeBrock}; Real 25 con Brock = ${effLvlAfterBrock}; Real 10 = ${effLvlLow}`,
  });

  // Test 7: Factor de EXP por diferencia de nivel
  const factorAdvantage12 = getLevelDifferenceExpFactor(17, 5); // Ventaja >= 10 -> 0
  const factorAdvantage8 = getLevelDifferenceExpFactor(15, 7); // Ventaja 8 -> 0.1
  const factorAdvantage5 = getLevelDifferenceExpFactor(15, 10); // Ventaja 5 -> 0.25
  const factorEqual = getLevelDifferenceExpFactor(10, 10); // Igual -> 1.0
  const t7Passed =
    factorAdvantage12 === 0 &&
    factorAdvantage8 === 0.1 &&
    factorAdvantage5 === 0.25 &&
    factorEqual === 1.0;
  results.push({
    test: 'Balance EXP: factor moderado por nivel (Nv.17 vs Nv.5 = 0 EXP)',
    passed: t7Passed,
    details: `17 vs 5 = factor ${factorAdvantage12}; 15 vs 7 = factor ${factorAdvantage8}; 10 vs 10 = factor ${factorEqual}`,
  });

  // Test 8: Efecto de Parálisis sobre velocidad efectiva y cadencia
  const normalSpeed = getEffectiveSpeed(100, 0, null); // 100
  const paralyzedSpeed = getEffectiveSpeed(100, 0, 'paralisis'); // 50
  const normalInterval = getAttackIntervalMs(normalSpeed); // 4000 / (1 + 100/50) = 1333ms
  const paralyzedInterval = getAttackIntervalMs(paralyzedSpeed); // 4000 / (1 + 50/50) = 2000ms
  const t8Passed =
    normalSpeed === 100 &&
    paralyzedSpeed === 50 &&
    paralyzedInterval > normalInterval;
  results.push({
    test: 'Estado: Parálisis reduce la velocidad efectiva a la mitad (50%) y dilata el intervalo de ataque',
    passed: t8Passed,
    details: `Vel normal: ${normalSpeed} (${normalInterval}ms) vs Parálisis: ${paralyzedSpeed} (${paralyzedInterval}ms)`,
  });

  // Test 9: Efecto de Quemadura sobre Ataque físico y daño por turno (1/16 PS)
  const dummyBurned: CombatantSnapshot = {
    name: 'Charmander',
    speciesId: 4,
    level: 20,
    types: ['fuego'],
    currentHp: 160,
    maxHp: 160,
    attack: 50,
    defense: 40,
    spAtk: 60,
    spDef: 50,
    speed: 65,
    stages: { attack: 0, defense: 0, spAtk: 0, spDef: 0, speed: 0 },
    equippedMoves: ['placaje'],
    currentMoveIndex: 0,
    status: 'quemadura',
  };
  const burnTick = applyStatusTickDamage(dummyBurned); // 160 / 16 = 10
  const dummyHealthy: CombatantSnapshot = { ...dummyBurned, status: null };
  const targetDefender: CombatantSnapshot = {
    name: 'Rattata',
    speciesId: 19,
    level: 20,
    types: ['normal'],
    currentHp: 100,
    maxHp: 100,
    attack: 30,
    defense: 30,
    spAtk: 30,
    spDef: 30,
    speed: 50,
    stages: { attack: 0, defense: 0, spAtk: 0, spDef: 0, speed: 0 },
    equippedMoves: ['placaje'],
    currentMoveIndex: 0,
  };
  const healthyAttack = executeMoveInCombat(dummyHealthy, targetDefender);
  const burnedAttack = executeMoveInCombat(dummyBurned, targetDefender);
  const t9Passed =
    burnTick.damage === 10 &&
    burnedAttack.damage < healthyAttack.damage;
  results.push({
    test: 'Estado: Quemadura reduce el daño de ataques físicos y resta 1/16 PS máximos por turno',
    passed: t9Passed,
    details: `Tick quemadura: ${burnTick.damage} PS; Daño sano: ${healthyAttack.damage} vs Daño quemado: ${burnedAttack.damage}`,
  });

  // Test 10: Efecto de Veneno daño por turno (1/16 PS)
  const dummyPoisoned: CombatantSnapshot = {
    ...dummyBurned,
    status: 'veneno',
    maxHp: 80,
    currentHp: 80,
  };
  const poisonTick = applyStatusTickDamage(dummyPoisoned); // 80 / 16 = 5
  const t10Passed = poisonTick.damage === 5;
  results.push({
    test: 'Estado: Veneno resta 1/16 PS máximos de forma consistente',
    passed: t10Passed,
    details: `MaxHp 80 / 16 = ${poisonTick.damage} PS`,
  });

  // Test 11: Inmunidades elementales a estados
  const fireImmuneToBurn = isImmuneToStatus('quemadura', ['fuego']);
  const normalNotImmuneToBurn = !isImmuneToStatus('quemadura', ['normal']);
  const electricImmuneToPara = isImmuneToStatus('paralisis', ['electrico']);
  const grassNotImmuneToPara = !isImmuneToStatus('paralisis', ['planta']);
  const poisonImmuneToPoison = isImmuneToStatus('veneno', ['veneno', 'fantasma']);
  const t11Passed =
    fireImmuneToBurn &&
    normalNotImmuneToBurn &&
    electricImmuneToPara &&
    grassNotImmuneToPara &&
    poisonImmuneToPoison;
  results.push({
    test: 'Estado: Inmunidad elemental (Fuego inmune a quemadura, Eléctrico a parálisis, Veneno a veneno)',
    passed: t11Passed,
    details: `Fuego: ${fireImmuneToBurn}, Eléctrico: ${electricImmuneToPara}, Veneno: ${poisonImmuneToPoison}`,
  });

  // Test 12: Estado de Sueño impide actuar hasta agotar los turnos
  const dummyAsleep: CombatantSnapshot = {
    ...dummyBurned,
    status: 'sueno',
    sleepTurns: 2,
  };
  const turn1Result = executeMoveInCombat(dummyAsleep, targetDefender);
  const turnsAfter1 = dummyAsleep.sleepTurns;
  const turn2Result = executeMoveInCombat(dummyAsleep, targetDefender);
  const t12Passed =
    !turn1Result.canAct &&
    turnsAfter1 === 1 &&
    dummyAsleep.status === null; // Despierta al llegar a 0
  results.push({
    test: 'Estado: Sueño inmoviliza al combatiente y se limpia al despertar',
    passed: t12Passed,
    details: `Turno 1: canAct=${turn1Result.canAct} (quedan ${turnsAfter1} turnos); Turno 2 despierta: status=${dummyAsleep.status}`,
  });

  // Test 13: Limpieza de estado al curar
  const teamMemberToHeal = { ...dummyBurned, status: 'paralisis' as const, sleepTurns: 2, currentHp: 10 };
  const healedMember = { ...teamMemberToHeal, currentHp: teamMemberToHeal.maxHp, status: null, sleepTurns: 0 };
  const t13Passed = healedMember.status === null && healedMember.sleepTurns === 0 && healedMember.currentHp === healedMember.maxHp;
  results.push({
    test: 'Estado: Curación del Pokémon restaura PS y limpia totalmente cualquier estado alterado',
    passed: t13Passed,
    details: `Antes: status=${teamMemberToHeal.status}, sleepTurns=${teamMemberToHeal.sleepTurns} -> Curado: status=${healedMember.status}, PS=${healedMember.currentHp}`,
  });

  // Test 14: Tienda de Fichas: Precios oficiales y compra atómica sin saldo negativo
  const stoneItem = SHOP_ITEMS_BY_ID['piedra_fuego'];
  const cableItem = SHOP_ITEMS_BY_ID['cable_link'];
  const basicCombat = SHOP_ITEMS_BY_ID['cinta_fuerza'];
  const advCombat = SHOP_ITEMS_BY_ID['chaleco_defensa'];

  const initialTokens = 200;
  const buyCost = basicCombat.cost; // 150
  const tokensAfterBuy = initialTokens - buyCost; // 50
  const canBuyAdvWithoutTokens = tokensAfterBuy >= advCombat.cost; // 50 >= 300 -> false

  const t14Passed =
    stoneItem?.cost === 40 &&
    cableItem?.cost === 50 &&
    basicCombat?.cost === 150 &&
    advCombat?.cost === 300 &&
    tokensAfterBuy === 50 &&
    !canBuyAdvWithoutTokens;

  results.push({
    test: 'Tienda: Catálogo con costes oficiales (Piedras 40, Cable 50, Básico 150, Avanzado 300) y compra atómica',
    passed: t14Passed,
    details: `Costes: Piedra=${stoneItem?.cost}, Cable=${cableItem?.cost}, Cinta=${basicCombat?.cost}, Chaleco=${advCombat?.cost}; Saldo tras comprar 150: ${tokensAfterBuy}, Puede comprar 300 con 50: ${canBuyAdvWithoutTokens}`,
  });

  // Test 15: Evolución: Cancelar no consume el objeto; confirmar consume exactamente 1
  let testInventory: Record<string, number> = { piedra_fuego: 2 };
  // Cancelar: el inventario permanece inalterado
  const inventoryAfterCancel = { ...testInventory };
  // Confirmar: descuenta exactamente 1 unidad
  const inventoryAfterConfirm = {
    ...testInventory,
    piedra_fuego: testInventory.piedra_fuego - 1,
  };
  const t15Passed =
    inventoryAfterCancel.piedra_fuego === 2 &&
    inventoryAfterConfirm.piedra_fuego === 1;

  results.push({
    test: 'Evolución: Cancelar preview no consume objetos; confirmar consume exactamente 1 unidad',
    passed: t15Passed,
    details: `Original: 2 -> Cancelado: ${inventoryAfterCancel.piedra_fuego} -> Confirmado: ${inventoryAfterConfirm.piedra_fuego}`,
  });

  // Test 16: Objeto de combate: 1 unidad por Pokémon, desequipar devuelve unidad
  let combatStock: Record<string, number> = { cinta_fuerza: 1 };
  let poke1Held: string | null = null;
  let poke2Held: string | null = null;

  // Equipar a Poke 1: consume 1 unidad
  if (combatStock['cinta_fuerza'] > 0) {
    poke1Held = 'cinta_fuerza';
    combatStock['cinta_fuerza'] -= 1;
  }
  // Intentar equipar a Poke 2: no hay unidades disponibles (0)
  const canEquipPoke2 = combatStock['cinta_fuerza'] > 0;
  // Desequipar a Poke 1: devuelve la unidad al inventario
  if (poke1Held) {
    combatStock[poke1Held] += 1;
    poke1Held = null;
  }
  const t16Passed =
    !canEquipPoke2 &&
    poke1Held === null &&
    combatStock['cinta_fuerza'] === 1;

  results.push({
    test: 'Objetos: 1 unidad por Pokémon, no duplicable en varios a la vez; desequipar devuelve unidad',
    passed: t16Passed,
    details: `Intento en Poke2 sin stock = ${canEquipPoke2}; Tras desequipar Poke1: stock = ${combatStock['cinta_fuerza']}`,
  });

  // Test 17: Efectos reales y balanceados de objetos en motor común
  const attackerNoItem: CombatantSnapshot = {
    name: 'Hitmonlee',
    speciesId: 106,
    level: 25,
    types: ['lucha'],
    currentHp: 100,
    maxHp: 100,
    attack: 80,
    defense: 50,
    spAtk: 40,
    spDef: 60,
    speed: 70,
    stages: { attack: 0, defense: 0, spAtk: 0, spDef: 0, speed: 0 },
    equippedMoves: ['placaje'],
    currentMoveIndex: 0,
    heldItem: null,
  };
  const defenderStandard: CombatantSnapshot = {
    name: 'Snorlax',
    speciesId: 143,
    level: 25,
    types: ['normal'],
    currentHp: 200,
    maxHp: 200,
    attack: 60,
    defense: 60,
    spAtk: 50,
    spDef: 65,
    speed: 30,
    stages: { attack: 0, defense: 0, spAtk: 0, spDef: 0, speed: 0 },
    equippedMoves: ['placaje'],
    currentMoveIndex: 0,
    heldItem: null,
  };

  const resNoItem = executeMoveInCombat(attackerNoItem, defenderStandard);
  const attackerWithBelt: CombatantSnapshot = { ...attackerNoItem, heldItem: 'cinta_fuerza' };
  const resWithBelt = executeMoveInCombat(attackerWithBelt, defenderStandard);

  const defenderWithVest: CombatantSnapshot = { ...defenderStandard, heldItem: 'chaleco_defensa' };
  const resAgainstVest = executeMoveInCombat(attackerNoItem, defenderWithVest);

  const t17Passed =
    resWithBelt.damage >= resNoItem.damage &&
    resAgainstVest.damage <= resNoItem.damage;

  results.push({
    test: 'Objetos en combate: Cinta Fuerza (+10% físico) y Chaleco Protector (-10% daño recibido)',
    passed: t17Passed,
    details: `Base: ${resNoItem.damage} daño -> Con Cinta: ${resWithBelt.damage} daño -> Contra Chaleco: ${resAgainstVest.damage} daño`,
  });

  // Test 18: Multicarriles: 2 victorias en 2 carriles = exactamente 2 puntos y 2 victorias (no 4)
  let simulatedZonePoints = 0;
  let simulatedZoneVictories = 0;
  // Derrotar enemigo carril 1 (+1)
  simulatedZonePoints += 1;
  simulatedZoneVictories += 1;
  // Derrotar enemigo carril 2 (+1)
  simulatedZonePoints += 1;
  simulatedZoneVictories += 1;

  const t18Passed = simulatedZonePoints === 2 && simulatedZoneVictories === 2;
  results.push({
    test: 'Multicarril: 2 victorias en 2 carriles independientes = exactamente 2 puntos y 2 victorias (SIN multiplicador)',
    passed: t18Passed,
    details: `Puntos: ${simulatedZonePoints} (esperado 2), Victorias: ${simulatedZoneVictories} (esperado 2)`,
  });

  // Test 19: Cap de EXP: ningún Pokémon supera el nivel tope de sus medallas
  const capTestBeforeBrock = getLevelCap([]).cap; // 14
  let testExpLvl = 14;
  let testExpAmount = 500;
  if (testExpLvl >= capTestBeforeBrock) {
    testExpAmount = 0; // EXP bloqueada por cap
  }
  const t19Passed = testExpAmount === 0 && testExpLvl === capTestBeforeBrock;
  results.push({
    test: 'EXP y Topes: Pokémon en el cap de medallas (Nv. 14 antes de Brock) no recibe EXP ni sobrelevel',
    passed: t19Passed,
    details: `Cap medalla: ${capTestBeforeBrock}, Nivel: ${testExpLvl}, EXP recibida: ${testExpAmount}`,
  });

  // Test 20: Unicidad estricta: No se permiten especies duplicadas en el equipo ni en carriles
  const sampleTeam = [
    { speciesId: 25, uid: 'p-1' },
    { speciesId: 1, uid: 'p-2' },
  ];
  const canAddPikachuAgain = sampleTeam.some((m) => m.speciesId === 25);
  // Asignación de carril: carril 1 y carril 2 no pueden tener el mismo UID
  const lane1Uid = 'p-1';
  let lane2Uid = 'p-1';
  if (lane1Uid === lane2Uid) {
    lane2Uid = 'p-2'; // Se auto-corrige para impedir el mismo Pokémon en 2 carriles
  }
  const t20Passed = canAddPikachuAgain && lane1Uid !== lane2Uid;
  results.push({
    test: 'Unicidad: Especies únicas en equipo y prohibición de asignar el mismo Pokémon a 2 carriles',
    passed: t20Passed,
    details: `Bloqueo duplicado especie = ${canAddPikachuAgain}; Carril 1 (${lane1Uid}) != Carril 2 (${lane2Uid})`,
  });

  // Test 21: Carril muerto no ataca
  const faintedLanePokemon: CombatantSnapshot = { ...attackerNoItem, currentHp: 0 };
  const canFaintedAct = faintedLanePokemon.currentHp > 0;
  const t21Passed = !canFaintedAct;
  results.push({
    test: 'Carril muerto: Combatiente debilitado (0 PS) detiene su carril y no ejecuta acciones',
    passed: t21Passed,
    details: `PS: ${faintedLanePokemon.currentHp}, canAct=${canFaintedAct}`,
  });

  // Test 22: Reto Especial: Cualquier debilitación (incluso daño residual) reinicia la racha a 0
  let trialStreak = 8;
  let trialFailed = false;
  let failReason: string | null = null;
  const residualFaintPoke: CombatantSnapshot = { ...attackerNoItem, currentHp: 2, status: 'veneno', maxHp: 32 };
  const residualTick = applyStatusTickDamage(residualFaintPoke);
  residualFaintPoke.currentHp = Math.max(0, residualFaintPoke.currentHp - residualTick.damage);

  if (residualFaintPoke.currentHp <= 0) {
    trialFailed = true;
    trialStreak = 0;
    failReason = `Tu ${residualFaintPoke.name} se ha debilitado por veneno. ¡Racha reiniciada a 0!`;
  }

  const t22Passed = trialFailed && trialStreak === 0 && Boolean(failReason);
  results.push({
    test: 'Reto Especial: Debilitación por daño residual falla inmediatamente el reto y reinicia racha a 0',
    passed: t22Passed,
    details: `Racha reiniciada: ${trialStreak}, Motivo: "${failReason}"`,
  });

  // Test 23: Pausa de combate detiene el reloj de todos los carriles sin ráfagas
  let isPaused = true;
  let lane1Elapsed = 500;
  let lane2Elapsed = 600;
  const deltaMs = 100;
  if (!isPaused) {
    lane1Elapsed += deltaMs;
    lane2Elapsed += deltaMs;
  }
  const t23Passed = lane1Elapsed === 500 && lane2Elapsed === 600;
  results.push({
    test: 'Pausa: Suspende el avance de tiempo de todos los carriles simultáneos',
    passed: t23Passed,
    details: `Con pausa=true, delta 100ms no incrementó: Carril 1=${lane1Elapsed}ms, Carril 2=${lane2Elapsed}ms`,
  });

  // Test 24: Retos especiales: no dan EXP ni fichas farmables; desbloqueo permanente 1 vez
  const trialDouble = SPECIAL_TRIALS.find((t) => t.id === 'double_trial');
  const trialTriple = SPECIAL_TRIALS.find((t) => t.id === 'triple_trial');
  const t24Passed =
    trialDouble?.targetStreak === 10 &&
    trialDouble?.challengeLevel === 14 &&
    trialTriple?.targetStreak === 20 &&
    trialTriple?.challengeLevel === 29;

  results.push({
    test: 'Retos: Parámetros oficiales (Doble: racha 10 a Nv.14 tras Brock; Triple: racha 20 en 2 carriles a Nv.29)',
    passed: Boolean(t24Passed),
    details: `Doble: racha=${trialDouble?.targetStreak}, Nv.${trialDouble?.challengeLevel}; Triple: racha=${trialTriple?.targetStreak}, Nv.${trialTriple?.challengeLevel}`,
  });

  // Test 25: Parálisis afecta carril de forma independiente y cambio de ruta limpia estados sin curar gratis PS
  const lane1PokeSpeed = getEffectiveSpeed(100, 0, 'paralisis'); // 50
  const lane2PokeSpeed = getEffectiveSpeed(100, 0, null); // 100
  const lane1Interval = getAttackIntervalMs(lane1PokeSpeed); // 2000
  const lane2Interval = getAttackIntervalMs(lane2PokeSpeed); // 1333

  // Limpieza de estados sin curación gratuita al cambiar ruta
  const pokeWithDamagedHp = { currentHp: 35, maxHp: 100, status: 'veneno' as const, sleepTurns: 3 };
  const cleanedOnRouteChange = { ...pokeWithDamagedHp, status: null, sleepTurns: 0 };

  const t25Passed =
    lane1Interval > lane2Interval &&
    cleanedOnRouteChange.status === null &&
    cleanedOnRouteChange.sleepTurns === 0 &&
    cleanedOnRouteChange.currentHp === 35; // PS NO curados gratis

  results.push({
    test: 'Independencia de carriles: Parálisis en carril 1 no afecta carril 2, y cambio de ruta limpia estados sin curar gratis',
    passed: t25Passed,
    details: `Intervalo Carril 1 (${lane1Interval}ms) vs Carril 2 (${lane2Interval}ms); Limpieza: status=${cleanedOnRouteChange.status}, PS=${cleanedOnRouteChange.currentHp}/${cleanedOnRouteChange.maxHp}`,
  });

  return results;
}
