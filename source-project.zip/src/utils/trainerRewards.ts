import { KANTO_TRAINERS, TrainerRival } from '../data/trainers';
import { POKEMON_BY_ID } from '../data/pokemon151';
import { GameSave } from '../types/pokemon';

export function getTrainerCooldownMs(trainer: TrainerRival) {
  return ({ normal: 6, experto: 12, elite: 24 }[trainer.difficulty]) * 60 * 60 * 1000;
}

export function getTrainerWaitMs(save: GameSave, trainerId: string, now = Date.now()) {
  return Math.max(0, (save.trainerCooldowns?.[trainerId] || 0) - now);
}

export function getTrainerRewardOptions(trainer: TrainerRival) {
  const families = new Map<number, Map<number, number>>();
  for (const member of trainer.team) {
    const path = [member.speciesId];
    let id = member.speciesId;
    while (true) {
      const parentId = [134, 135, 136].includes(id) ? 133 : Object.values(POKEMON_BY_ID).find(spec => spec.evolution?.into === id)?.id;
      if (!parentId || path.includes(parentId)) break;
      path.unshift(parentId);
      id = parentId;
    }
    const family = families.get(path[0]) || new Map<number, number>();
    path.forEach((speciesId, depth) => family.set(speciesId, depth));
    families.set(path[0], family);
  }
  const options: { speciesId: number; weight: number }[] = [];
  for (const family of families.values()) {
    const maxDepth = Math.max(...family.values());
    const weights = maxDepth === 0 ? [100] : maxDepth === 1 ? [70, 30] : [70, 20, 10];
    for (const [speciesId, depth] of family) {
      const siblings = [...family.values()].filter(d => d === depth).length;
      options.push({ speciesId, weight: weights[depth] / siblings / families.size });
    }
  }
  return options;
}

export function getTrainerRewardPool(trainer: TrainerRival) {
  return getTrainerRewardOptions(trainer).map(option => option.speciesId);
}

export function rollTrainerReward(trainer: TrainerRival, random = Math.random()) {
  const options = getTrainerRewardOptions(trainer);
  let roll = Math.max(0, Math.min(0.999999999, random)) * 100;
  for (const option of options) {
    roll -= option.weight;
    if (roll < 0) return option.speciesId;
  }
  return options[options.length - 1].speciesId;
}

export function canRewardTrainer(save: GameSave, trainerId: string, now = Date.now()) {
  const trainer = KANTO_TRAINERS.find(t => t.id === trainerId);
  return !!trainer && trainer.isUnlocked(save) && getTrainerWaitMs(save, trainerId, now) === 0;
}
