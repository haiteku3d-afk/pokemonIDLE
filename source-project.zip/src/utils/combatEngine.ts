import { PokemonType } from '../types/pokemon';
import { MoveData, StatusCondition } from '../types/moves';
import { getTypeMultiplier } from '../data/pokemon151';
import { MOVES_DATA } from '../data/moves';

/**
 * Constantes centralizadas de ritmo de combate de Kanto Sobres
 */
export const COMBAT_ACTION_INTERVAL_MS = 1500; // Ritmo base de referencia
export const COMBAT_ENEMY_TRANSITION_MS = 2000; // Mínimo 2000 ms entre enemigos para evitar cadenas instantáneas

/**
 * Calcula el intervalo de ataque en milisegundos a partir de la velocidad efectiva:
 * intervalo = clamp(4000 / (1 + velocidadEfectiva / 50), 1000, 4000)
 */
export function getAttackIntervalMs(effectiveSpeed: number, moveId?: string): number {
  const safeSpeed = Math.max(1, effectiveSpeed);
  const rawInterval = 4000 / (1 + safeSpeed / 50);
  const base = Math.max(1000, Math.min(4000, Math.round(rawInterval)));
  const priority = moveId ? MOVES_DATA[moveId]?.priority || 0 : 0;
  return Math.round(base * (priority > 0 ? Math.max(0.5, 1 - priority * 0.25) : 1));
}

/**
 * Calcula la velocidad efectiva aplicando el modificador de etapas (-6 a +6)
 * y el efecto de parálisis (reduce la velocidad efectiva al 50% en combate)
 */
export function getEffectiveSpeed(
  baseSpeed: number,
  speedStage: number = 0,
  status?: StatusCondition | null
): number {
  const multiplier = getStatStageMultiplier(speedStage);
  let effective = Math.round(baseSpeed * multiplier);

  // Parálisis: reduce la velocidad efectiva a la mitad (50%)
  if (status === 'paralisis') {
    effective = Math.floor(effective * 0.5);
  }

  return Math.max(1, effective);
}

/**
 * Curva de diferencia de nivel para obtención de EXP en rutas:
 * - factor 1.0 si receptor <= enemigo
 * - 0.75 si ventaja 1-2
 * - 0.50 si ventaja 3-4
 * - 0.25 si ventaja 5-6
 * - 0.10 si ventaja 7-9
 * - 0.00 si ventaja >= 10 (ej. Nivel 17 contra nivel 5: 0 EXP)
 */
export function getLevelDifferenceExpFactor(receiverLevel: number, enemyLevel: number): number {
  const diff = receiverLevel - enemyLevel;
  if (diff <= 0) return 1.0;
  if (diff <= 2) return 0.75;
  if (diff <= 4) return 0.5;
  if (diff <= 6) return 0.25;
  if (diff <= 9) return 0.1;
  return 0.0;
}

/**
 * Modificador multiplicador por etapas de estadística (-6 a +6)
 */
export function getStatStageMultiplier(stage: number): number {
  const clamped = Math.max(-6, Math.min(6, stage));
  if (clamped >= 0) {
    return (2 + clamped) / 2;
  } else {
    return 2 / (2 - clamped);
  }
}

export interface CombatantSnapshot {
  name: string;
  speciesId: number;
  level: number;
  types: PokemonType[];
  currentHp: number;
  maxHp: number;
  attack: number;
  defense: number;
  spAtk: number;
  spDef: number;
  speed: number;
  stages: {
    attack: number;
    defense: number;
    spAtk: number;
    spDef: number;
    speed: number;
  };
  equippedMoves: string[];
  currentMoveIndex: number;
  status?: StatusCondition | null;
  sleepTurns?: number;
  heldItem?: string | null;
}

export interface AttackExecutionResult {
  moveUsed: MoveData;
  isHit: boolean;
  canAct: boolean;
  damage: number;
  effectiveness: number;
  isStab: boolean;
  logMessage: string;
  statChangeText?: string;
  statusAppliedText?: string;
  statusApplied?: StatusCondition;
  recoilDamage?: number;
}

export interface StatusTickResult {
  damage: number;
  logMessage?: string;
}

/**
 * Aplica el daño por turno de estados persistentes (Quemadura o Veneno: 1/16 de los PS máximos)
 */
export function applyStatusTickDamage(combatant: CombatantSnapshot): StatusTickResult {
  if (!combatant.status || combatant.currentHp <= 0) {
    return { damage: 0 };
  }

  if (combatant.status === 'quemadura') {
    const burnDamage = Math.max(1, Math.floor(combatant.maxHp / 16));
    return {
      damage: burnDamage,
      logMessage: `¡${combatant.name} sufre ${burnDamage} de daño por sus quemaduras!`,
    };
  }

  if (combatant.status === 'veneno') {
    const poisonDamage = Math.max(1, Math.floor(combatant.maxHp / 16));
    return {
      damage: poisonDamage,
      logMessage: `¡El veneno resta ${poisonDamage} PS a ${combatant.name}!`,
    };
  }

  return { damage: 0 };
}

/**
 * Comprueba inmunidad elemental a estados:
 * - Fuego no puede quemarse
 * - Eléctrico no puede paralizarse
 * - Veneno no puede envenenarse
 */
export function isImmuneToStatus(status: StatusCondition, targetTypes: PokemonType[]): boolean {
  if (status === 'quemadura' && targetTypes.includes('fuego')) return true;
  if (status === 'paralisis' && targetTypes.includes('electrico')) return true;
  if (status === 'veneno' && targetTypes.includes('veneno')) return true;
  return false;
}

/**
 * Ejecuta un movimiento en combate respetando:
 * - Orden cíclico
 * - Comprobación de Sueño (despertar o impedir turno) y Parálisis plena (25% probabilidad de no atacar)
 * - Precisión real
 * - Potencia real y estadísticas físicas vs especiales (Quemadura reduce el Ataque físico a la mitad)
 * - Modificadores de etapa acumulados
 * - STAB y efectividad por tipos duales / inmunidad
 * - Aplicación de efectos de estado (quemadura, parálisis, sueño, veneno)
 * - Sin daño inventado en movimientos de estado
 * - Fallback a Forcejeo si solo existen movimientos de estado sin efecto
 */
export function executeMoveInCombat(
  attacker: CombatantSnapshot,
  defender: CombatantSnapshot
): AttackExecutionResult {
  let moveId = attacker.equippedMoves[attacker.currentMoveIndex % Math.max(1, attacker.equippedMoves.length)];
  let move = MOVES_DATA[moveId] || MOVES_DATA['placaje'];

  // 1. Chequeo de estados que impiden o alteran la acción: SUEÑO y PARÁLISIS
  if (attacker.status === 'sueno') {
    const remainingTurns = (attacker.sleepTurns ?? 2) - 1;
    if (remainingTurns <= 0) {
      attacker.status = null;
      attacker.sleepTurns = 0;
      // Despierta y puede atacar este turno
    } else {
      attacker.sleepTurns = remainingTurns;
      return {
        moveUsed: move,
        isHit: false,
        canAct: false,
        damage: 0,
        effectiveness: 1,
        isStab: false,
        logMessage: `¡${attacker.name} está profundamente dormido y no puede moverse!`,
      };
    }
  }

  if (attacker.status === 'paralisis') {
    // 25% de probabilidad de quedar totalmente paralizado
    const paralysisRoll = Math.random() * 100;
    if (paralysisRoll < 25) {
      return {
        moveUsed: move,
        isHit: false,
        canAct: false,
        damage: 0,
        effectiveness: 1,
        isStab: false,
        logMessage: `¡${attacker.name} está paralizado! ¡No se puede mover!`,
      };
    }
  }

  // Si solo tiene ataques de estado y ya no pueden modificarse las etapas (tope alcanzado),
  // se activa el fallback visible y coherente (Forcejeo) para no bloquear el combate.
  if (move.category === 'estado' && move.statMod) {
    const targetSnapshot = move.statMod.target === 'rival' ? defender : attacker;
    const currentStage = targetSnapshot.stages[move.statMod.stat] || 0;
    const delta = move.statMod.stages;
    const isAtLimit = (delta < 0 && currentStage <= -6) || (delta > 0 && currentStage >= 6);

    const allStatus = attacker.equippedMoves.every((id) => MOVES_DATA[id]?.category === 'estado');
    if (allStatus && isAtLimit) {
      move = MOVES_DATA['forcejeo'];
    }
  }

  // 2. Chequeo de Precisión
  const rollAcc = Math.random() * 100;
  if (rollAcc > move.accuracy) {
    return {
      moveUsed: move,
      isHit: false,
      canAct: true,
      damage: 0,
      effectiveness: 1,
      isStab: false,
      logMessage: `¡${attacker.name} usó ${move.name}, pero el ataque falló!`,
    };
  }

  // 3. Movimiento de Estado (Daño = 0, aplica cambios reales a estadísticas o estado)
  if (move.category === 'estado') {
    let statChangeText = '';
    let statusAppliedText = '';
    let appliedStatus: StatusCondition | undefined;

    // Modificación de etapas
    if (move.statMod) {
      const targetSnapshot = move.statMod.target === 'rival' ? defender : attacker;
      const statName =
        move.statMod.stat === 'attack'
          ? 'Ataque'
          : move.statMod.stat === 'defense'
          ? 'Defensa'
          : move.statMod.stat === 'spAtk'
          ? 'Ataque Especial'
          : move.statMod.stat === 'spDef'
          ? 'Defensa Especial'
          : 'Velocidad';

      const prevStage = targetSnapshot.stages[move.statMod.stat] || 0;
      const nextStage = Math.max(-6, Math.min(6, prevStage + move.statMod.stages));
      targetSnapshot.stages[move.statMod.stat] = nextStage;

      if (nextStage === prevStage) {
        statChangeText = `¡El ${statName} de ${targetSnapshot.name} no puede ${move.statMod.stages > 0 ? 'subir' : 'bajar'} más!`;
      } else {
        const magnitude = Math.abs(move.statMod.stages) >= 2 ? 'mucho' : '';
        const direction = move.statMod.stages > 0 ? `subió ${magnitude}`.trim() : `bajó ${magnitude}`.trim();
        statChangeText = `¡El ${statName} de ${targetSnapshot.name} ${direction}!`;
      }
    }

    // Efecto de estado puro (ej. Onda Trueno, Somnífero, Polvo Veneno, Tóxico, etc.)
    if (move.statusEffect) {
      const targetSnapshot = move.statusEffect.target === 'usuario' ? attacker : defender;
      if (!targetSnapshot.status) {
        if (isImmuneToStatus(move.statusEffect.status, targetSnapshot.types)) {
          statusAppliedText = `¡Pero no afecta a ${targetSnapshot.name}!`;
        } else {
          const rollStatus = Math.random() * 100;
          if (rollStatus <= move.statusEffect.chance) {
            targetSnapshot.status = move.statusEffect.status;
            appliedStatus = move.statusEffect.status;
            if (move.statusEffect.status === 'sueno') {
              targetSnapshot.sleepTurns = Math.floor(Math.random() * 3) + 2; // 2 a 4 turnos dormido
              statusAppliedText = `¡${targetSnapshot.name} se quedó profundamente dormido!`;
            } else if (move.statusEffect.status === 'paralisis') {
              statusAppliedText = `¡${targetSnapshot.name} ha quedado paralizado! Su velocidad disminuye.`;
            } else if (move.statusEffect.status === 'quemadura') {
              statusAppliedText = `¡${targetSnapshot.name} se ha quemado! Su ataque físico disminuye.`;
            } else if (move.statusEffect.status === 'veneno') {
              statusAppliedText = `¡${targetSnapshot.name} ha sido envenenado!`;
            }
          }
        }
      } else {
        statusAppliedText = `¡${targetSnapshot.name} ya tiene un problema de estado!`;
      }
    }

    const fullMessage = [
      `¡${attacker.name} usó ${move.name}!`,
      statChangeText,
      statusAppliedText,
    ]
      .filter(Boolean)
      .join(' ');

    return {
      moveUsed: move,
      isHit: true,
      canAct: true,
      damage: 0,
      effectiveness: 1,
      isStab: false,
      logMessage: fullMessage.trim(),
      statChangeText,
      statusAppliedText,
      statusApplied: appliedStatus,
    };
  }

  // 4. Movimiento de Daño (Físico o Especial)
  const isSpecial = move.category === 'especial';

  // Efecto de Quemadura: reduce el Ataque físico del usuario al 50%
  const burnAtkMultiplier = !isSpecial && attacker.status === 'quemadura' ? 0.5 : 1.0;

  const effectiveAtk = isSpecial
    ? attacker.spAtk * getStatStageMultiplier(attacker.stages.spAtk)
    : attacker.attack * getStatStageMultiplier(attacker.stages.attack) * burnAtkMultiplier;

  const effectiveDef = isSpecial
    ? defender.spDef * getStatStageMultiplier(defender.stages.spDef)
    : defender.defense * getStatStageMultiplier(defender.stages.defense);

  // Efectividad de tipo contra los tipos del defensor
  const totalEffectiveness = getTypeMultiplier(move.type, defender.types);

  // Inmunidad total
  if (totalEffectiveness === 0) {
    return {
      moveUsed: move,
      isHit: true,
      canAct: true,
      damage: 0,
      effectiveness: 0,
      isStab: false,
      logMessage: `¡${attacker.name} usó ${move.name}, pero no afecta a ${defender.name}!`,
    };
  }

  // Cálculo de Daño Estándar
  const levelPart = (2 * attacker.level) / 5 + 2;
  const statRatio = effectiveAtk / Math.max(1, effectiveDef);
  let baseDamage = Math.floor(Math.floor((levelPart * move.power * statRatio) / 50) + 2);

  // STAB: Bonificación de mismo tipo
  const isStab = attacker.types.includes(move.type);
  if (isStab) {
    baseDamage = Math.floor(baseDamage * 1.5);
  }

  // Modificadores de objetos de combate equipados (equilibrados y sin alterar IVs ni bases)
  let itemDamageMultiplier = 1.0;
  if (!isSpecial && attacker.heldItem === 'cinta_fuerza') {
    itemDamageMultiplier *= 1.10; // +10% daño físico
  } else if (isSpecial && attacker.heldItem === 'gafas_sabias') {
    itemDamageMultiplier *= 1.10; // +10% daño especial
  }

  if (defender.heldItem === 'chaleco_defensa') {
    itemDamageMultiplier *= 0.90; // -10% daño recibido
  }

  // Multiplicador por efectividad elemental y objetos
  const finalDamage = Math.max(1, Math.floor(baseDamage * totalEffectiveness * itemDamageMultiplier));

  let effectivenessMessage = '';
  if (totalEffectiveness > 1) effectivenessMessage = ' (¡Es muy eficaz!)';
  if (totalEffectiveness < 1 && totalEffectiveness > 0) effectivenessMessage = ' (No es muy eficaz...)';

  const recoilDamage = move.isStruggle ? Math.max(1, Math.floor(finalDamage * 0.25)) : undefined;

  // Efectos secundarios de estado en ataques con daño
  let statusAppliedText = '';
  let appliedStatus: StatusCondition | undefined;
  if (move.statusEffect && !defender.status && finalDamage > 0) {
    if (!isImmuneToStatus(move.statusEffect.status, defender.types)) {
      const rollSec = Math.random() * 100;
      if (rollSec <= move.statusEffect.chance) {
        defender.status = move.statusEffect.status;
        appliedStatus = move.statusEffect.status;
        if (move.statusEffect.status === 'quemadura') {
          statusAppliedText = ` ¡${defender.name} se quemó!`;
        } else if (move.statusEffect.status === 'paralisis') {
          statusAppliedText = ` ¡${defender.name} quedó paralizado!`;
        } else if (move.statusEffect.status === 'veneno') {
          statusAppliedText = ` ¡${defender.name} fue envenenado!`;
        } else if (move.statusEffect.status === 'sueno') {
          defender.sleepTurns = Math.floor(Math.random() * 3) + 2;
          statusAppliedText = ` ¡${defender.name} se quedó dormido!`;
        }
      }
    }
  }

  return {
    moveUsed: move,
    isHit: true,
    canAct: true,
    damage: finalDamage,
    effectiveness: totalEffectiveness,
    isStab,
    logMessage: `¡${attacker.name} usó ${move.name} e infligió ${finalDamage} de daño a ${defender.name}!${effectivenessMessage}${statusAppliedText}`,
    recoilDamage,
    statusApplied: appliedStatus,
    statusAppliedText,
  };
}
