import { getLevelDifferenceExpFactor } from './combatEngine';

export const SHARED_EXPERIENCE_RATE = 0.7;

// Acelera el entrenamiento inicial; la bonificación desaparece progresivamente.
export function getTrainingExperienceBonus(level: number): number {
  if (level < 10) return 3;
  if (level < 15) return 2;
  if (level < 20) return 1.5;
  if (level < 30) return 1.25;
  return 1;
}

export function calculateExpeditionExperience({ baseExp, enemyLevel, receiverLevel, levelCap, alive, active }: {
  baseExp: number; enemyLevel: number; receiverLevel: number; levelCap: number; alive: boolean; active: boolean;
}): number {
  if (!alive || receiverLevel >= levelCap) return 0;
  const pool = Math.floor(baseExp * enemyLevel / 7);
  return Math.max(1, Math.floor(pool * getLevelDifferenceExpFactor(receiverLevel, enemyLevel)
    * getTrainingExperienceBonus(receiverLevel) * (active ? 1 : SHARED_EXPERIENCE_RATE)));
}
