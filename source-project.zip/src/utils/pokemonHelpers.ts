import { POKEMON_BY_ID } from '../data/pokemon151';
import { GameSave, OwnedPokemon, EncounterRate, PokemonIVs, StatKey } from '../types/pokemon';
import { sanitizeEquippedMoves, getDefaultEquippedMoves } from '../data/speciesLearnsets';

/**
 * Fórmula estándar oficial de cálculo de PS: Nivel + Base + IV (sin EV)
 */
export function calculateMaxHp(baseHp: number, level: number, ivHp: number = 0): number {
  return Math.floor(((2 * baseHp + ivHp) * level) / 100) + level + 10;
}

/**
 * Fórmula estándar oficial para las 5 estadísticas de combate: Nivel + Base + IV (sin EV)
 */
export function calculateStat(baseStat: number, level: number, ivStat: number = 0): number {
  return Math.floor(((2 * baseStat + ivStat) * level) / 100) + 5;
}

/**
 * Coste incremental por estadística = 2 * IVactual + 1
 * Pasar de 0 a 1 cuesta 1 copia; de 1 a 2 cuesta 3 nuevas copias; de 2 a 3 cuesta 5, etc.
 * Tope: 31 IV.
 */
export function getNextIvCost(currentIv: number): number {
  if (currentIv >= 31) return Infinity;
  return 2 * currentIv + 1;
}

export function expRequiredForLevel(level: number): number {
  // Curva Media Rápida
  return Math.max(10, Math.floor((4 * Math.pow(level, 3)) / 5));
}

export function createDefaultIvs(): PokemonIVs {
  return {
    hp: 0,
    attack: 0,
    defense: 0,
    spAtk: 0,
    spDef: 0,
    speed: 0,
  };
}

export function createOwnedPokemon(
  speciesId: number,
  level: number,
  nickname?: string,
  ivs?: Partial<PokemonIVs>,
  upgradeCopies: number = 0,
  totalDuplicates: number = 0,
  moves?: string[]
): OwnedPokemon {
  const species = POKEMON_BY_ID[speciesId];
  if (!species) {
    throw new Error(`Especie #${speciesId} no encontrada`);
  }

  const finalIvs: PokemonIVs = {
    ...createDefaultIvs(),
    ...(ivs || {}),
  };

  const maxHp = calculateMaxHp(species.baseStats.hp, level, finalIvs.hp);
  const attack = calculateStat(species.baseStats.attack, level, finalIvs.attack);
  const defense = calculateStat(species.baseStats.defense, level, finalIvs.defense);
  const spAtk = calculateStat(species.baseStats.spAtk, level, finalIvs.spAtk);
  const spDef = calculateStat(species.baseStats.spDef, level, finalIvs.spDef);
  const speed = calculateStat(species.baseStats.speed, level, finalIvs.speed);

  const equippedMoves = sanitizeEquippedMoves(speciesId, level, moves);

  return {
    uid: `pkm-${speciesId}`,
    speciesId,
    nickname: nickname || species.name,
    level,
    currentHp: maxHp,
    maxHp,
    exp: 0,
    nextLevelExp: Math.max(15, expRequiredForLevel(level + 1) - expRequiredForLevel(level)),
    attack,
    defense,
    spAtk,
    spDef,
    speed,
    ivs: finalIvs,
    equippedMoves,
    upgradeCopies,
    totalDuplicates,
    obtainedAt: Date.now(),
  };
}

export function recalculatePokemonStats(poke: OwnedPokemon): OwnedPokemon {
  const species = POKEMON_BY_ID[poke.speciesId];
  if (!species) return poke;

  const maxHp = calculateMaxHp(species.baseStats.hp, poke.level, poke.ivs.hp);
  const attack = calculateStat(species.baseStats.attack, poke.level, poke.ivs.attack);
  const defense = calculateStat(species.baseStats.defense, poke.level, poke.ivs.defense);
  const spAtk = calculateStat(species.baseStats.spAtk, poke.level, poke.ivs.spAtk);
  const spDef = calculateStat(species.baseStats.spDef, poke.level, poke.ivs.spDef);
  const speed = calculateStat(species.baseStats.speed, poke.level, poke.ivs.speed);

  // Mantener relación de salud
  const currentHp = Math.min(maxHp, Math.max(poke.currentHp > 0 ? 1 : 0, poke.currentHp));
  const equippedMoves = sanitizeEquippedMoves(poke.speciesId, poke.level, poke.equippedMoves, poke.taughtMoves);

  return {
    ...poke,
    maxHp,
    currentHp,
    attack,
    defense,
    spAtk,
    spDef,
    speed,
    equippedMoves,
    nextLevelExp: Math.max(15, expRequiredForLevel(poke.level + 1) - expRequiredForLevel(poke.level)),
  };
}

/**
 * Realiza un sorteo independiente según las probabilidades exactas de encuentro
 */
export function rollFromEncounterTable(table: EncounterRate[]): { speciesId: number; level: number } {
  const totalRate = table.reduce((sum, item) => sum + item.rate, 0);
  const roll = Math.random() * totalRate;

  let accumulated = 0;
  for (const item of table) {
    accumulated += item.rate;
    if (roll <= accumulated) {
      const level = Math.floor(Math.random() * (item.maxLevel - item.minLevel + 1)) + item.minLevel;
      return { speciesId: item.speciesId, level };
    }
  }

  const last = table[table.length - 1];
  return { speciesId: last.speciesId, level: last.minLevel };
}

export const SAVE_KEY = 'kanto_sobres_save_v2';
export const BACKUP_KEY_V1 = 'kanto_sobres_save_backup_v1';

export function getDefaultSave(): GameSave {
  return {
    version: 2,
    timestamp: Date.now(),
    player: {
      name: 'Entrenador Rojo',
      starterChosen: false,
    },
    team: [],
    pcBox: [],
    pokedex: {},
    zonePoints: {
      'route-1': 0, // 0 puntos de regalo iniciales (bloqueo evitado con curación libre)
    },
    zoneVictories: {
      'route-1': 0, // Contador de victorias salvajes separado de los puntos
    },
    activeZoneId: 'route-1',
    unlockedZones: ['route-1'],
    badges: [],
    defeatedGyms: [],
    completedMissions: [],
    pendingMoves: [],
    items: {
      cable_link: 1,
    },
    trainerTokens: 0, // Fichas iniciales de combate de entrenador
    inventory: {}, // Inventario inicial de objetos comprados o acumulados
    completedTrainers: [],
    unlockedDoubleBattle: false,
    unlockedTripleBattle: false,
    completedTrials: [],
    activeLaneCount: 1,
    oakCandies: 0, // 0 Caramelos Raros de regalo para nueva partida
    stats: {
      totalVictories: 0,
      totalPacksOpened: 0,
      totalCardsDrawn: 0,
      totalEvolutions: 0,
      totalIvUpgrades: 0,
    },
    settings: {
      sound: true,
      battlePaused: false,
    },
  };
}

/**
 * Migra guardados anteriores al esquema v2:
 * 1. Colección única por especie: nunca almacenar duplicados de la misma especie.
 * 2. Conservar el ejemplar de mayor nivel/EXP.
 * 3. Cada ejemplar extra se convierte en +1 copia de mejora.
 * 4. Caramelos antiguos de especie se convierten a copias de mejora.
 * 5. Se elimina bonus a bases y se inicializan los 6 IVs.
 * 6. Equipo estrictamente único (máximo 6 especies distintas).
 * 7. Respaldo local de seguridad guardado antes de migrar.
 */
export function migrateSave(raw: any): GameSave {
  if (!raw || typeof raw !== 'object' || !raw.player) {
    return getDefaultSave();
  }

  // Si ya es versión 2 válida y saneada
  if (raw.version >= 2 && Array.isArray(raw.team) && Array.isArray(raw.pcBox)) {
    // Asegurar unicidad por especie por seguridad
    const seenSpecies = new Set<number>();
    const sanitizedTeam: OwnedPokemon[] = [];
    const sanitizedBox: OwnedPokemon[] = [];

    for (const p of raw.team) {
      if (!seenSpecies.has(p.speciesId) && sanitizedTeam.length < 6) {
        seenSpecies.add(p.speciesId);
        sanitizedTeam.push(recalculatePokemonStats(p));
      } else {
        // Si hubiera un duplicado, consolidar copias en la instancia ya registrada
        const existing = sanitizedTeam.find((item) => item.speciesId === p.speciesId) ||
          sanitizedBox.find((item) => item.speciesId === p.speciesId);
        if (existing) {
          existing.upgradeCopies += 1 + (p.upgradeCopies || 0);
          existing.totalDuplicates += 1 + (p.totalDuplicates || 0);
        }
      }
    }

    for (const p of raw.pcBox) {
      if (!seenSpecies.has(p.speciesId)) {
        seenSpecies.add(p.speciesId);
        sanitizedBox.push(recalculatePokemonStats(p));
      } else {
        const existing = sanitizedTeam.find((item) => item.speciesId === p.speciesId) ||
          sanitizedBox.find((item) => item.speciesId === p.speciesId);
        if (existing) {
          existing.upgradeCopies += 1 + (p.upgradeCopies || 0);
          existing.totalDuplicates += 1 + (p.totalDuplicates || 0);
        }
      }
    }

    return {
      ...getDefaultSave(),
      ...raw,
      version: 2,
      team: sanitizedTeam.map((p) => ({ ...p, heldItem: p.heldItem ?? null })),
      pcBox: sanitizedBox.map((p) => ({ ...p, heldItem: p.heldItem ?? null })),
      pokedex: raw.pokedex || {},
      zonePoints: raw.zonePoints || {},
      zoneVictories: raw.zoneVictories || {},
      trainerTokens: typeof raw.trainerTokens === 'number' ? raw.trainerTokens : 0,
      inventory: raw.inventory || (raw.items ? { ...raw.items } : {}),
      completedTrainers: Array.isArray(raw.completedTrainers) ? raw.completedTrainers : [],
      unlockedDoubleBattle: !!raw.unlockedDoubleBattle,
      unlockedTripleBattle: !!raw.unlockedTripleBattle,
      completedTrials: Array.isArray(raw.completedTrials) ? raw.completedTrials : [],
      activeLaneCount: raw.activeLaneCount === 2 || raw.activeLaneCount === 3 ? raw.activeLaneCount : 1,
      unlockedZones: Array.isArray(raw.unlockedZones) && raw.unlockedZones.length > 0
        ? raw.unlockedZones
        : ['route-1'],
      pendingMoves: Array.isArray(raw.pendingMoves) ? raw.pendingMoves : [],
      stats: { ...getDefaultSave().stats, ...(raw.stats || {}) },
      settings: { ...getDefaultSave().settings, ...(raw.settings || {}) },
    };
  }

  // --- MIGRACIÓN DESDE ESQUEMA V1 ---
  try {
    localStorage.setItem(BACKUP_KEY_V1, JSON.stringify(raw));
  } catch (err) {
    console.warn('No se pudo escribir respaldo en localStorage:', err);
  }

  const allOldPokes: any[] = [
    ...(Array.isArray(raw.team) ? raw.team : []),
    ...(Array.isArray(raw.pcBox) ? raw.pcBox : []),
  ];

  // Agrupar por speciesId
  const speciesMap = new Map<number, any[]>();
  for (const p of allOldPokes) {
    if (!p || !p.speciesId) continue;
    const group = speciesMap.get(p.speciesId) || [];
    group.push(p);
    speciesMap.set(p.speciesId, group);
  }

  const uniquePokemons: OwnedPokemon[] = [];

  for (const [speciesId, instances] of speciesMap.entries()) {
    // Ordenar por mayor nivel y luego por mayor EXP
    instances.sort((a, b) => {
      if (b.level !== a.level) return b.level - a.level;
      return (b.exp || 0) - (a.exp || 0);
    });

    const bestInstance = instances[0];
    const extraCopies = instances.length - 1;

    // Convertir caramelos antiguos a copias de mejora
    const oldCandies = raw.candies?.[speciesId] || 0;
    const oldBonusPower = bestInstance.bonusPower || 0;
    const totalCopies = extraCopies + oldCandies + oldBonusPower;

    const ivs: PokemonIVs = bestInstance.ivs || createDefaultIvs();

    const migratedPoke = createOwnedPokemon(
      speciesId,
      bestInstance.level || 5,
      bestInstance.nickname,
      ivs,
      totalCopies,
      raw.pokedex?.[speciesId]?.duplicates || totalCopies
    );

    migratedPoke.exp = bestInstance.exp || 0;
    migratedPoke.currentHp = Math.min(migratedPoke.maxHp, bestInstance.currentHp || migratedPoke.maxHp);

    uniquePokemons.push(migratedPoke);
  }

  // Reconstruir equipo único (máximo 6) preservando preferencia de los que estaban en el equipo anterior
  const oldTeamSpeciesIds = new Set<number>(
    (Array.isArray(raw.team) ? raw.team : []).map((p: any) => p?.speciesId).filter(Boolean)
  );

  const newTeam: OwnedPokemon[] = [];
  const newBox: OwnedPokemon[] = [];

  // Primero añadir los que estaban en el equipo anterior (en orden)
  for (const p of uniquePokemons) {
    if (oldTeamSpeciesIds.has(p.speciesId) && newTeam.length < 6) {
      newTeam.push(p);
    } else {
      newBox.push(p);
    }
  }

  // Si el equipo quedó con huecos y hay en caja, rellenar hasta que haya al menos 1 o los que había
  while (newTeam.length < Math.min(6, uniquePokemons.length) && newBox.length > 0) {
    newTeam.push(newBox.shift()!);
  }

  return {
    ...getDefaultSave(),
    ...raw,
    version: 2,
    timestamp: Date.now(),
    team: newTeam,
    pcBox: newBox,
    pokedex: raw.pokedex || {},
    zonePoints: raw.zonePoints || {},
    zoneVictories: raw.zoneVictories || {}, // Se inicia contador nuevo de victorias salvajes separado de los puntos
    unlockedZones: Array.isArray(raw.unlockedZones) ? raw.unlockedZones : ['route-1'],
    badges: Array.isArray(raw.badges) ? raw.badges : [],
    defeatedGyms: Array.isArray(raw.defeatedGyms) ? raw.defeatedGyms : [],
    completedMissions: Array.isArray(raw.completedMissions) ? raw.completedMissions : [],
    pendingMoves: Array.isArray(raw.pendingMoves) ? raw.pendingMoves : [],
    items: raw.items || { cable_link: 1 },
    oakCandies: raw.oakCandies || 1,
    stats: {
      totalVictories: raw.stats?.totalVictories || 0,
      totalPacksOpened: raw.stats?.totalPacksOpened || 0,
      totalCardsDrawn: raw.stats?.totalCardsDrawn || 0,
      totalEvolutions: raw.stats?.totalEvolutions || 0,
      totalIvUpgrades: 0,
    },
    settings: {
      sound: raw.settings?.sound ?? true,
      battlePaused: raw.settings?.battlePaused ?? false,
    },
  };
}

export function loadGame(): GameSave {
  try {
    // Intentar leer v2 primero
    const rawV2 = localStorage.getItem(SAVE_KEY);
    if (rawV2) {
      const parsed = JSON.parse(rawV2);
      return migrateSave(parsed);
    }

    // Si no existe v2, buscar v1 para migrar
    const rawV1 = localStorage.getItem('kanto_sobres_save_v1');
    if (rawV1) {
      const parsed = JSON.parse(rawV1);
      const migrated = migrateSave(parsed);
      saveGame(migrated);
      return migrated;
    }

    return getDefaultSave();
  } catch (err) {
    console.error('Error cargando partida:', err);
    return getDefaultSave();
  }
}

export function saveGame(state: GameSave): boolean {
  try {
    const serialized = JSON.stringify({ ...state, version: 2, timestamp: Date.now() });
    localStorage.setItem(SAVE_KEY, serialized);
    return true;
  } catch (err) {
    console.error('Error guardando partida:', err);
    return false;
  }
}
