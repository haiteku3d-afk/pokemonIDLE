import { ZoneData } from '../types/pokemon';

/**
 * Zonas y Rutas de Kanto con probabilidades exactas de Pokémon Rojo (Game Boy)
 * y variantes de Azul, Pesca y Surf.
 */
export const KANTO_ZONES: ZoneData[] = [
  {
    id: 'route-1',
    name: 'Ruta 1',
    subtitle: 'Pradera entre Pueblo Paleta y Ciudad Verde',
    order: 1,
    description: 'Camino inicial donde habitan aves pacíficas y pequeños roedores.',
    requiredVictories: 10,
    nextZoneId: 'route-2',
    encounterTable: [
      { speciesId: 16, minLevel: 2, maxLevel: 5, rate: 55 }, // Pidgey 55%
      { speciesId: 19, minLevel: 2, maxLevel: 4, rate: 45 }, // Rattata 45%
    ],
    isProvisionalTable: false,
  },
  {
    id: 'route-2',
    name: 'Ruta 2',
    subtitle: 'Senda hacia Bosque Verde',
    order: 2,
    description: 'Hierba alta con orugas venenosas y aves jóvenes.',
    requiredVictories: 15,
    nextZoneId: 'viridian-forest',
    unlockRequirement: {
      zoneId: 'route-1',
      requiredVictoriesInZone: 10,
      text: '10 victorias en la Ruta 1',
    },
    encounterTable: [
      { speciesId: 16, minLevel: 3, maxLevel: 7, rate: 45 }, // Pidgey 45%
      { speciesId: 19, minLevel: 2, maxLevel: 5, rate: 45 }, // Rattata 45%
      { speciesId: 13, minLevel: 3, maxLevel: 5, rate: 5 },  // Weedle 5%
      { speciesId: 32, minLevel: 3, maxLevel: 4, rate: 5 },  // Nidoran♂ 5%
    ],
    blueAlternateTable: [
      { speciesId: 16, minLevel: 3, maxLevel: 7, rate: 45 },
      { speciesId: 19, minLevel: 2, maxLevel: 5, rate: 45 },
      { speciesId: 10, minLevel: 3, maxLevel: 5, rate: 5 },  // Caterpie en Azul
      { speciesId: 29, minLevel: 3, maxLevel: 4, rate: 5 },  // Nidoran♀ en Azul
    ],
    isProvisionalTable: false,
  },
  {
    id: 'viridian-forest',
    name: 'Bosque Verde',
    subtitle: 'Laberinto frondoso de insectos y chispas',
    order: 3,
    description: 'Arboleda tupida donde habitan insectos en metamorfosis y el escurridizo Pikachu.',
    requiredVictories: 20,
    nextZoneId: 'pewter-city',
    unlockRequirement: {
      zoneId: 'route-2',
      requiredVictoriesInZone: 15,
      text: '15 victorias en la Ruta 2',
    },
    encounterTable: [
      { speciesId: 10, minLevel: 3, maxLevel: 6, rate: 50 }, // Caterpie 50%
      { speciesId: 11, minLevel: 4, maxLevel: 6, rate: 35 }, // Metapod 35%
      { speciesId: 13, minLevel: 3, maxLevel: 5, rate: 5 },  // Weedle 5%
      { speciesId: 14, minLevel: 4, maxLevel: 6, rate: 5 },  // Kakuna 5%
      { speciesId: 25, minLevel: 3, maxLevel: 5, rate: 5 },  // Pikachu 5%
    ],
    blueAlternateTable: [
      { speciesId: 13, minLevel: 3, maxLevel: 6, rate: 50 }, // Weedle 50% en Azul
      { speciesId: 14, minLevel: 4, maxLevel: 6, rate: 35 }, // Kakuna 35% en Azul
      { speciesId: 10, minLevel: 3, maxLevel: 5, rate: 5 },
      { speciesId: 11, minLevel: 4, maxLevel: 6, rate: 5 },
      { speciesId: 25, minLevel: 3, maxLevel: 5, rate: 5 },
    ],
    isProvisionalTable: false,
  },
  {
    id: 'pewter-city',
    name: 'Ciudad Plateada',
    subtitle: 'Ciudad de piedra sólida y ciencia de fósiles',
    order: 4,
    description: 'Sede del Gimnasio de Brock. Vence a Brock para desbloquear el paso al Monte Moon.',
    unlockRequirement: {
      zoneId: 'viridian-forest',
      requiredVictoriesInZone: 20,
      text: '20 victorias en Bosque Verde',
    },
    encounterTable: [
      { speciesId: 74, minLevel: 8, maxLevel: 10, rate: 50 }, // Geodude 50%
      { speciesId: 16, minLevel: 7, maxLevel: 9, rate: 35 },  // Pidgey 35%
      { speciesId: 19, minLevel: 6, maxLevel: 8, rate: 15 },  // Rattata 15%
    ],
    isProvisionalTable: false,
  },
  {
    id: 'route-3',
    name: 'Ruta 3',
    subtitle: 'Sendero montañoso hacia el Monte Moon',
    order: 5,
    description: 'Camino árido custodiado por jóvenes ornitólogos y pequeños cazadores.',
    requiredVictories: 20,
    nextZoneId: 'mt-moon',
    unlockRequirement: {
      badge: 'boulder',
      text: 'Derrota a Brock (Medalla Roca)',
    },
    encounterTable: [
      { speciesId: 21, minLevel: 6, maxLevel: 8, rate: 30 },  // Spearow 30%
      { speciesId: 16, minLevel: 6, maxLevel: 8, rate: 30 },  // Pidgey 30%
      { speciesId: 56, minLevel: 6, maxLevel: 7, rate: 15 },  // Mankey 15% (Rojo)
      { speciesId: 19, minLevel: 5, maxLevel: 7, rate: 15 },  // Rattata 15%
      { speciesId: 39, minLevel: 5, maxLevel: 7, rate: 10 },  // Jigglypuff 10%
    ],
    blueAlternateTable: [
      { speciesId: 21, minLevel: 6, maxLevel: 8, rate: 30 },
      { speciesId: 16, minLevel: 6, maxLevel: 8, rate: 30 },
      { speciesId: 52, minLevel: 6, maxLevel: 7, rate: 15 },  // Meowth 15% en Azul
      { speciesId: 19, minLevel: 5, maxLevel: 7, rate: 15 },
      { speciesId: 39, minLevel: 5, maxLevel: 7, rate: 10 },
    ],
    isProvisionalTable: false,
  },
  {
    id: 'mt-moon',
    name: 'Monte Moon',
    subtitle: 'Caverna profunda de meteoritos y fósiles',
    order: 6,
    description: 'Cueva plagada de murciélagos, rocas vivas y el misterio de los Fósiles Hélix y Domo.',
    requiredVictories: 25,
    nextZoneId: 'route-4',
    unlockRequirement: {
      zoneId: 'route-3',
      requiredVictoriesInZone: 20,
      text: '20 victorias en la Ruta 3',
    },
    encounterTable: [
      { speciesId: 41, minLevel: 7, maxLevel: 11, rate: 55 }, // Zubat 55%
      { speciesId: 74, minLevel: 7, maxLevel: 10, rate: 25 }, // Geodude 25%
      { speciesId: 46, minLevel: 8, maxLevel: 10, rate: 15 }, // Paras 15%
      { speciesId: 35, minLevel: 8, maxLevel: 12, rate: 5 },  // Clefairy 5%
    ],
    isProvisionalTable: false,
  },
  {
    id: 'route-4',
    name: 'Ruta 4',
    subtitle: 'Salida oriental del Monte Moon',
    order: 7,
    description: 'Laderas que descienden hacia Ciudad Celeste con serpientes y aves rapaces.',
    requiredVictories: 20,
    nextZoneId: 'cerulean-city',
    unlockRequirement: {
      zoneId: 'mt-moon',
      requiredVictoriesInZone: 25,
      text: '25 victorias en el Monte Moon',
    },
    encounterTable: [
      { speciesId: 19, minLevel: 8, maxLevel: 12, rate: 40 }, // Rattata 40%
      { speciesId: 21, minLevel: 8, maxLevel: 12, rate: 35 }, // Spearow 35%
      { speciesId: 23, minLevel: 8, maxLevel: 10, rate: 25 }, // Ekans 25% (Rojo)
    ],
    blueAlternateTable: [
      { speciesId: 19, minLevel: 8, maxLevel: 12, rate: 40 },
      { speciesId: 21, minLevel: 8, maxLevel: 12, rate: 35 },
      { speciesId: 27, minLevel: 8, maxLevel: 10, rate: 25 }, // Sandshrew 25% (Azul)
    ],
    isProvisionalTable: false,
  },
  {
    id: 'cerulean-city',
    name: 'Ciudad Celeste',
    subtitle: 'La ciudad de las aguas florales y Misty',
    order: 8,
    description: 'Sede del Gimnasio Cascada de Misty y del aficionado Bill al final de la colina.',
    nextZoneId: 'route-24',
    unlockRequirement: {
      zoneId: 'route-4',
      requiredVictoriesInZone: 20,
      text: '20 victorias en la Ruta 4',
    },
    encounterTable: [
      { speciesId: 43, minLevel: 12, maxLevel: 14, rate: 40 }, // Oddish 40% (Rojo)
      { speciesId: 16, minLevel: 10, maxLevel: 13, rate: 35 }, // Pidgey 35%
      { speciesId: 63, minLevel: 8, maxLevel: 12, rate: 25 },  // Abra 25%
    ],
    blueAlternateTable: [
      { speciesId: 69, minLevel: 12, maxLevel: 14, rate: 40 }, // Bellsprout 40% (Azul)
      { speciesId: 16, minLevel: 10, maxLevel: 13, rate: 35 },
      { speciesId: 63, minLevel: 8, maxLevel: 12, rate: 25 },
    ],
    fishingTable: {
      oldRod: [
        { speciesId: 129, minLevel: 5, maxLevel: 5, rate: 100 }, // Magikarp 100%
      ],
      goodRod: [
        { speciesId: 60, minLevel: 10, maxLevel: 15, rate: 50 },  // Poliwag 50%
        { speciesId: 118, minLevel: 10, maxLevel: 15, rate: 50 }, // Goldeen 50%
      ],
      superRod: [
        { speciesId: 54, minLevel: 15, maxLevel: 20, rate: 40 },  // Psyduck 40%
        { speciesId: 61, minLevel: 15, maxLevel: 20, rate: 40 },  // Poliwhirl 40%
        { speciesId: 119, minLevel: 15, maxLevel: 20, rate: 20 }, // Seaking 20%
      ],
    },
    surfTable: [
      { speciesId: 72, minLevel: 10, maxLevel: 20, rate: 100 }, // Tentacool 100%
    ],
    isProvisionalTable: false,
  },
  {
    id: 'route-24',
    name: 'Ruta 24 (Puente Pepita)',
    subtitle: 'Famoso puente de los 5 entrenadores',
    order: 9,
    description: 'Zona de paso hacia la casa de Bill con hierba espesa.',
    requiredVictories: 20,
    nextZoneId: 'vermilion-city',
    unlockRequirement: {
      badge: 'cascade',
      text: 'Derrota a Misty (Medalla Cascada)',
    },
    encounterTable: [
      { speciesId: 43, minLevel: 12, maxLevel: 14, rate: 25 }, // Oddish 25%
      { speciesId: 16, minLevel: 11, maxLevel: 13, rate: 25 }, // Pidgey 25%
      { speciesId: 63, minLevel: 10, maxLevel: 12, rate: 20 }, // Abra 20%
      { speciesId: 13, minLevel: 9, maxLevel: 11, rate: 15 },  // Weedle 15%
      { speciesId: 14, minLevel: 10, maxLevel: 12, rate: 15 }, // Kakuna 15%
    ],
    blueAlternateTable: [
      { speciesId: 69, minLevel: 12, maxLevel: 14, rate: 25 }, // Bellsprout 25% en Azul
      { speciesId: 16, minLevel: 11, maxLevel: 13, rate: 25 },
      { speciesId: 63, minLevel: 10, maxLevel: 12, rate: 20 },
      { speciesId: 10, minLevel: 9, maxLevel: 11, rate: 15 },  // Caterpie en Azul
      { speciesId: 11, minLevel: 10, maxLevel: 12, rate: 15 }, // Metapod en Azul
    ],
    isProvisionalTable: false,
  },
  {
    id: 'vermilion-city',
    name: 'Ciudad Carmín',
    subtitle: 'Puerto marítimo y fortaleza de Lt. Surge',
    order: 10,
    description: 'Ciudad costera con olor a salitre. Aquí atraca el crucero de lujo S.S. Anne.',
    nextZoneId: 'rock-tunnel',
    unlockRequirement: {
      badge: 'cascade',
      text: 'Derrota a Misty (Medalla Cascada)',
    },
    encounterTable: [
      { speciesId: 96, minLevel: 11, maxLevel: 15, rate: 40 }, // Drowzee 40%
      { speciesId: 21, minLevel: 13, maxLevel: 17, rate: 30 }, // Spearow 30%
      { speciesId: 23, minLevel: 13, maxLevel: 17, rate: 30 }, // Ekans 30%
    ],
    blueAlternateTable: [
      { speciesId: 96, minLevel: 11, maxLevel: 15, rate: 40 },
      { speciesId: 21, minLevel: 13, maxLevel: 17, rate: 30 },
      { speciesId: 27, minLevel: 13, maxLevel: 17, rate: 30 }, // Sandshrew 30% en Azul
    ],
    fishingTable: {
      oldRod: [{ speciesId: 129, minLevel: 5, maxLevel: 5, rate: 100 }],
      goodRod: [
        { speciesId: 90, minLevel: 10, maxLevel: 15, rate: 50 },  // Shellder 50%
        { speciesId: 98, minLevel: 10, maxLevel: 15, rate: 50 },  // Krabby 50%
      ],
      superRod: [
        { speciesId: 90, minLevel: 15, maxLevel: 25, rate: 40 },
        { speciesId: 98, minLevel: 15, maxLevel: 25, rate: 40 },
        { speciesId: 99, minLevel: 25, maxLevel: 30, rate: 20 }, // Kingler 20%
      ],
    },
    isProvisionalTable: false,
  },
  {
    id: 'rock-tunnel',
    name: 'Túnel Roca',
    subtitle: 'Paso oscuro entre Carmín y Lavanda',
    order: 11,
    description: 'Caverna en penumbra absoluta habitada por Onix y Machop.',
    requiredVictories: 25,
    nextZoneId: 'pokemon-tower',
    unlockRequirement: {
      badge: 'thunder',
      text: 'Derrota a Lt. Surge (Medalla Trueno)',
    },
    encounterTable: [
      { speciesId: 41, minLevel: 15, maxLevel: 18, rate: 40 }, // Zubat 40%
      { speciesId: 74, minLevel: 15, maxLevel: 17, rate: 30 }, // Geodude 30%
      { speciesId: 66, minLevel: 15, maxLevel: 18, rate: 15 }, // Machop 15%
      { speciesId: 95, minLevel: 13, maxLevel: 17, rate: 15 }, // Onix 15%
    ],
    isProvisionalTable: false,
  },
  {
    id: 'pokemon-tower',
    name: 'Torre Pokémon (Lavanda)',
    subtitle: 'Cementerio sagrado y descanso espiritual',
    order: 12,
    description: 'Torre con niebla espectral habitada por Gastly y el huérfano Cubone.',
    requiredVictories: 20,
    nextZoneId: 'celadon-city',
    unlockRequirement: {
      zoneId: 'rock-tunnel',
      requiredVictoriesInZone: 25,
      text: '25 victorias en el Túnel Roca',
    },
    encounterTable: [
      { speciesId: 92, minLevel: 18, maxLevel: 24, rate: 70 }, // Gastly 70%
      { speciesId: 93, minLevel: 20, maxLevel: 25, rate: 20 }, // Haunter 20%
      { speciesId: 104, minLevel: 17, maxLevel: 22, rate: 10 }, // Cubone 10%
    ],
    isProvisionalTable: false,
  },
  {
    id: 'celadon-city',
    name: 'Ciudad Azulona',
    subtitle: 'Gran metrópoli comercial y Erika',
    order: 13,
    description: 'Sede de los Grandes Almacenes, el Casino y el aromático gimnasio de Erika.',
    nextZoneId: 'safari-zone',
    unlockRequirement: {
      badge: 'thunder',
      text: 'Derrota a Lt. Surge (Medalla Trueno)',
    },
    encounterTable: [
      { speciesId: 58, minLevel: 18, maxLevel: 22, rate: 40 }, // Growlithe 40% (Rojo)
      { speciesId: 56, minLevel: 18, maxLevel: 22, rate: 35 }, // Mankey 35%
      { speciesId: 16, minLevel: 18, maxLevel: 22, rate: 25 }, // Pidgey 25%
    ],
    blueAlternateTable: [
      { speciesId: 37, minLevel: 18, maxLevel: 22, rate: 40 }, // Vulpix 40% (Azul)
      { speciesId: 52, minLevel: 18, maxLevel: 22, rate: 35 }, // Meowth 35% (Azul)
      { speciesId: 16, minLevel: 18, maxLevel: 22, rate: 25 },
    ],
    isProvisionalTable: false,
  },
  {
    id: 'safari-zone',
    name: 'Zona Safari (Fucsia)',
    subtitle: 'Reserva natural protegida de especies exóticas',
    order: 14,
    description: 'Extenso santuario donde se encuentran Chansey, Kangaskhan, Scyther y Tauros.',
    requiredVictories: 30,
    nextZoneId: 'silph-co',
    unlockRequirement: {
      badge: 'rainbow',
      text: 'Derrota a Erika (Medalla Arcoíris)',
    },
    encounterTable: [
      { speciesId: 33, minLevel: 22, maxLevel: 28, rate: 20 }, // Nidorino 20%
      { speciesId: 111, minLevel: 22, maxLevel: 28, rate: 20 }, // Rhyhorn 20%
      { speciesId: 47, minLevel: 22, maxLevel: 26, rate: 16 }, // Parasect 16%
      { speciesId: 114, minLevel: 22, maxLevel: 26, rate: 16 }, // Tangela 16%
      { speciesId: 123, minLevel: 23, maxLevel: 28, rate: 8 }, // Scyther 8% (Rojo)
      { speciesId: 113, minLevel: 23, maxLevel: 28, rate: 6 }, // Chansey 6%
      { speciesId: 115, minLevel: 25, maxLevel: 28, rate: 7 }, // Kangaskhan 7%
      { speciesId: 128, minLevel: 25, maxLevel: 28, rate: 7 }, // Tauros 7%
    ],
    blueAlternateTable: [
      { speciesId: 30, minLevel: 22, maxLevel: 28, rate: 20 }, // Nidorina 20% en Azul
      { speciesId: 111, minLevel: 22, maxLevel: 28, rate: 20 },
      { speciesId: 47, minLevel: 22, maxLevel: 26, rate: 16 },
      { speciesId: 114, minLevel: 22, maxLevel: 26, rate: 16 },
      { speciesId: 127, minLevel: 23, maxLevel: 28, rate: 8 }, // Pinsir 8% en Azul
      { speciesId: 113, minLevel: 23, maxLevel: 28, rate: 6 },
      { speciesId: 115, minLevel: 25, maxLevel: 28, rate: 7 },
      { speciesId: 128, minLevel: 25, maxLevel: 28, rate: 7 },
    ],
    fishingTable: {
      superRod: [
        { speciesId: 147, minLevel: 15, maxLevel: 25, rate: 25 }, // Dratini 25%!
        { speciesId: 118, minLevel: 15, maxLevel: 20, rate: 35 }, // Goldeen 35%
        { speciesId: 119, minLevel: 23, maxLevel: 28, rate: 40 }, // Seaking 40%
      ],
    },
    isProvisionalTable: false,
  },
  {
    id: 'silph-co',
    name: 'Silph S.A. (Azafrán)',
    subtitle: 'Sede corporativa y cuartel psíquico de Sabrina',
    order: 15,
    description: 'Rascacielos tecnológico custodiado por teletransportadores y Pokémon psíquicos.',
    requiredVictories: 25,
    nextZoneId: 'power-plant',
    unlockRequirement: {
      badge: 'soul',
      text: 'Derrota a Koga (Medalla Alma)',
    },
    encounterTable: [
      { speciesId: 100, minLevel: 28, maxLevel: 32, rate: 35 }, // Voltorb 35%
      { speciesId: 81, minLevel: 28, maxLevel: 32, rate: 35 },  // Magnemite 35%
      { speciesId: 109, minLevel: 28, maxLevel: 32, rate: 30 }, // Koffing 30%
    ],
    isProvisionalTable: true,
  },
  {
    id: 'power-plant',
    name: 'Central de Energía Abandonada',
    subtitle: 'Ruinas eléctricas nido de Zapdos',
    order: 16,
    description: 'Complejo electrificado con generadores zumbantes y trampa de Electrode.',
    requiredVictories: 30,
    nextZoneId: 'seafoam-islands',
    unlockRequirement: {
      badge: 'marsh',
      text: 'Derrota a Sabrina (Medalla Pantano)',
    },
    encounterTable: [
      { speciesId: 100, minLevel: 30, maxLevel: 36, rate: 35 }, // Voltorb 35%
      { speciesId: 81, minLevel: 30, maxLevel: 34, rate: 30 },  // Magnemite 30%
      { speciesId: 82, minLevel: 34, maxLevel: 38, rate: 15 },  // Magneton 15%
      { speciesId: 101, minLevel: 36, maxLevel: 40, rate: 10 }, // Electrode 10%
      { speciesId: 125, minLevel: 33, maxLevel: 37, rate: 10 }, // Electabuzz 10% (Rojo)
    ],
    blueAlternateTable: [
      { speciesId: 100, minLevel: 30, maxLevel: 36, rate: 35 },
      { speciesId: 81, minLevel: 30, maxLevel: 34, rate: 30 },
      { speciesId: 82, minLevel: 34, maxLevel: 38, rate: 15 },
      { speciesId: 101, minLevel: 36, maxLevel: 40, rate: 10 },
      { speciesId: 126, minLevel: 33, maxLevel: 37, rate: 10 }, // Magmar en Azul
    ],
    isProvisionalTable: false,
  },
  {
    id: 'seafoam-islands',
    name: 'Islas Espuma',
    subtitle: 'Grutas gélidas santuario de Articuno',
    order: 17,
    description: 'Cuevas marinas congeladas con fuertes corrientes subterráneas y témpanos de hielo.',
    requiredVictories: 30,
    nextZoneId: 'cinnabar-mansion',
    unlockRequirement: {
      badge: 'marsh',
      text: 'Derrota a Sabrina (Medalla Pantano)',
    },
    encounterTable: [
      { speciesId: 86, minLevel: 28, maxLevel: 34, rate: 35 },  // Seel 35%
      { speciesId: 79, minLevel: 28, maxLevel: 32, rate: 30 },  // Slowpoke 30%
      { speciesId: 42, minLevel: 30, maxLevel: 35, rate: 20 },  // Golbat 20%
      { speciesId: 87, minLevel: 34, maxLevel: 38, rate: 10 },  // Dewgong 10%
      { speciesId: 124, minLevel: 32, maxLevel: 36, rate: 5 },  // Jynx 5%
    ],
    surfTable: [
      { speciesId: 72, minLevel: 20, maxLevel: 35, rate: 80 },  // Tentacool 80%
      { speciesId: 73, minLevel: 30, maxLevel: 40, rate: 20 },  // Tentacruel 20%
    ],
    isProvisionalTable: false,
  },
  {
    id: 'cinnabar-mansion',
    name: 'Mansión Pokémon (Isla Canela)',
    subtitle: 'Laboratorio en ruinas donde nació Mewtwo',
    order: 18,
    description: 'Mansión quemada repleta de informes científicos clasificados y Pokémon de fuego.',
    requiredVictories: 25,
    nextZoneId: 'victory-road',
    unlockRequirement: {
      badge: 'volcano',
      text: 'Derrota a Blaine (Medalla Volcán)',
    },
    encounterTable: [
      { speciesId: 109, minLevel: 30, maxLevel: 35, rate: 35 }, // Koffing 35%
      { speciesId: 58, minLevel: 30, maxLevel: 34, rate: 30 },  // Growlithe 30% (Rojo)
      { speciesId: 77, minLevel: 30, maxLevel: 34, rate: 25 },  // Ponyta 25%
      { speciesId: 110, minLevel: 36, maxLevel: 40, rate: 10 }, // Weezing 10%
    ],
    blueAlternateTable: [
      { speciesId: 109, minLevel: 30, maxLevel: 35, rate: 35 },
      { speciesId: 37, minLevel: 30, maxLevel: 34, rate: 30 },  // Vulpix 30% en Azul
      { speciesId: 77, minLevel: 30, maxLevel: 34, rate: 25 },
      { speciesId: 126, minLevel: 34, maxLevel: 38, rate: 10 }, // Magmar en Azul
    ],
    isProvisionalTable: false,
  },
  {
    id: 'victory-road',
    name: 'Calle Victoria',
    subtitle: 'La última prueba antes del Alto Mando',
    order: 19,
    description: 'Caverna implacable que alberga a Moltres y a los Pokémon más feroces de Kanto.',
    requiredVictories: 40,
    nextZoneId: 'cerulean-cave',
    unlockRequirement: {
      badge: 'earth',
      text: 'Derrota a Giovanni (Medalla Tierra)',
    },
    encounterTable: [
      { speciesId: 67, minLevel: 38, maxLevel: 45, rate: 25 }, // Machoke 25%
      { speciesId: 75, minLevel: 38, maxLevel: 44, rate: 25 }, // Graveler 25%
      { speciesId: 95, minLevel: 38, maxLevel: 43, rate: 20 }, // Onix 20%
      { speciesId: 42, minLevel: 40, maxLevel: 45, rate: 15 }, // Golbat 15%
      { speciesId: 105, minLevel: 40, maxLevel: 46, rate: 15 }, // Marowak 15%
    ],
    isProvisionalTable: false,
  },
  {
    id: 'cerulean-cave',
    name: 'Cueva Celeste (Post-Liga)',
    subtitle: 'El abismo prohibido del titán genético',
    order: 20,
    description: 'Solo accesible para los Campeones de la Liga Pokémon. Hogar de Mewtwo.',
    requiredVictories: 50,
    unlockRequirement: {
      milestone: 'league_champion',
      badge: 'champion',
      text: 'Conviértete en Campeón de la Liga Pokémon',
    },
    encounterTable: [
      { speciesId: 42, minLevel: 50, maxLevel: 56, rate: 25 },  // Golbat 25%
      { speciesId: 47, minLevel: 52, maxLevel: 58, rate: 20 },  // Parasect 20%
      { speciesId: 97, minLevel: 52, maxLevel: 58, rate: 20 },  // Hypno 20%
      { speciesId: 26, minLevel: 53, maxLevel: 60, rate: 15 },  // Raichu 15%
      { speciesId: 132, minLevel: 50, maxLevel: 55, rate: 10 }, // Ditto 10%
      { speciesId: 113, minLevel: 54, maxLevel: 60, rate: 10 }, // Chansey 10%
    ],
    isProvisionalTable: true,
  },
];

// Cada objetivo permite reunir al menos los 30 puntos del primer sobre.
for (const zone of KANTO_ZONES) {
  zone.requiredVictories = Math.max(30, zone.requiredVictories || 0);
}
for (const zone of KANTO_ZONES) {
  const requirement = zone.unlockRequirement;
  if (requirement?.zoneId && requirement.requiredVictoriesInZone) {
    const previous = KANTO_ZONES.find(candidate => candidate.id === requirement.zoneId);
    requirement.requiredVictoriesInZone = previous?.requiredVictories || 30;
    requirement.text = requirement.requiredVictoriesInZone + ' victorias en ' + (previous?.name || requirement.zoneId);
  }
}

export const ZONES_BY_ID: Record<string, ZoneData> = KANTO_ZONES.reduce((acc, z) => {
  acc[z.id] = z;
  return acc;
}, {} as Record<string, ZoneData>);

/**
 * Comprueba si una zona cumple las condiciones para ser desbloqueada.
 */
export function isZoneUnlockable(
  zone: ZoneData,
  unlockedZones: string[],
  zoneVictories: Record<string, number>,
  badges: string[] = []
): boolean {
  if (unlockedZones.includes(zone.id)) return true;
  if (!zone.unlockRequirement) return false;

  const req = zone.unlockRequirement;
  if (req.badge && !badges.includes(req.badge)) {
    return false;
  }
  if (req.zoneId) {
    if (!unlockedZones.includes(req.zoneId)) return false;
    if (req.requiredVictoriesInZone) {
      const v = zoneVictories[req.zoneId] || 0;
      if (v < req.requiredVictoriesInZone) return false;
    }
  }
  return true;
}

/**
 * Retorna la lista de todas las zonas desbloqueadas agregando las que cumplan sus requisitos.
 * Preserva estrictamente cualquier zona ya desbloqueada en partidas existentes.
 */
export function evaluateAllUnlockedZones(
  currentUnlocked: string[],
  zoneVictories: Record<string, number>,
  badges: string[] = []
): string[] {
  const result = new Set<string>(currentUnlocked);
  // Ruta 1 siempre está desbloqueada
  result.add('route-1');

  let addedMore = true;
  while (addedMore) {
    addedMore = false;
    for (const zone of KANTO_ZONES) {
      if (!result.has(zone.id)) {
        if (isZoneUnlockable(zone, Array.from(result), zoneVictories, badges)) {
          result.add(zone.id);
          addedMore = true;
        }
      }
    }
  }

  return Array.from(result);
}
