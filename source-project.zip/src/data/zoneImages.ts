// Imágenes de Rojo Fuego / Verde Hoja archivadas por Bulbagarden Archives.
export const ZONE_IMAGES: Record<string, string> = {
  "route-1": "./zone-route-1.png",
  "route-2": "./zone-route-2.png",
  "route-3": "./zone-route-3.png",
  "route-4": "./zone-route-4.png",
  "route-24": "./zone-route-24.png",
  "viridian-forest": "./zone-viridian-forest.png",
  "pewter-city": "./zone-pewter-city.png",
  "mt-moon": "./zone-mt-moon.png",
  "cerulean-city": "./zone-cerulean-city.png",
  "vermilion-city": "./zone-vermilion-city.png",
  "rock-tunnel": "./zone-rock-tunnel.png",
  "pokemon-tower": "./zone-pokemon-tower.png",
  "celadon-city": "./zone-celadon-city.png",
  "safari-zone": "./zone-safari-zone.png",
  "silph-co": "./zone-silph-co.png",
  "power-plant": "./zone-power-plant.png",
  "seafoam-islands": "./zone-seafoam-islands.png",
  "cinnabar-mansion": "./zone-cinnabar-mansion.png",
  "victory-road": "./zone-victory-road.png",
  "cerulean-cave": "./zone-cerulean-cave.png"
};
