import { LevelUpMove } from '../types/moves';
import { MOVES_DATA } from './moves';

/**
 * Tabla de Aprendizaje de Movimientos por Nivel para los 151 Pokémon originales (Kanto / Gen 1).
 * Cada especie aprende movimientos auténticos según su nivel.
 */
export const SPECIES_LEARNSETS: Record<number, LevelUpMove[]> = {
  // Bulbasaur line
  1: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'grunido' },
    { level: 7, moveId: 'absorber' },
    { level: 13, moveId: 'latigo_cepa' },
    { level: 20, moveId: 'polvo_veneno' },
    { level: 27, moveId: 'somnifero' },
    { level: 34, moveId: 'hoja_afilada' },
    { level: 41, moveId: 'desarrollo' },
    { level: 48, moveId: 'rayo_solar' },
  ],
  2: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'grunido' },
    { level: 7, moveId: 'absorber' },
    { level: 13, moveId: 'latigo_cepa' },
    { level: 22, moveId: 'polvo_veneno' },
    { level: 30, moveId: 'somnifero' },
    { level: 38, moveId: 'hoja_afilada' },
    { level: 46, moveId: 'desarrollo' },
    { level: 54, moveId: 'rayo_solar' },
  ],
  3: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'grunido' },
    { level: 7, moveId: 'absorber' },
    { level: 13, moveId: 'latigo_cepa' },
    { level: 22, moveId: 'polvo_veneno' },
    { level: 30, moveId: 'somnifero' },
    { level: 43, moveId: 'hoja_afilada' },
    { level: 55, moveId: 'desarrollo' },
    { level: 65, moveId: 'rayo_solar' },
  ],

  // Charmander line
  4: [
    { level: 1, moveId: 'aranazo' },
    { level: 1, moveId: 'grunido' },
    { level: 9, moveId: 'ascuas' },
    { level: 15, moveId: 'pantalla_humo' },
    { level: 22, moveId: 'furia' },
    { level: 30, moveId: 'cuchillada' },
    { level: 38, moveId: 'lanzallamas' },
    { level: 46, moveId: 'giro_fuego' },
  ],
  5: [
    { level: 1, moveId: 'aranazo' },
    { level: 1, moveId: 'grunido' },
    { level: 9, moveId: 'ascuas' },
    { level: 15, moveId: 'pantalla_humo' },
    { level: 24, moveId: 'furia' },
    { level: 33, moveId: 'cuchillada' },
    { level: 42, moveId: 'lanzallamas' },
    { level: 56, moveId: 'giro_fuego' },
  ],
  6: [
    { level: 1, moveId: 'aranazo' },
    { level: 1, moveId: 'grunido' },
    { level: 9, moveId: 'ascuas' },
    { level: 15, moveId: 'pantalla_humo' },
    { level: 24, moveId: 'furia' },
    { level: 36, moveId: 'cuchillada' },
    { level: 46, moveId: 'lanzallamas' },
    { level: 55, moveId: 'giro_fuego' },
    { level: 65, moveId: 'llamarada' },
  ],

  // Squirtle line
  7: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'latigo' },
    { level: 8, moveId: 'burbuja' },
    { level: 15, moveId: 'refugio' },
    { level: 22, moveId: 'pistola_agua' },
    { level: 28, moveId: 'mordisco' },
    { level: 35, moveId: 'rayo_burbuja' },
    { level: 42, moveId: 'hidrobomba' },
  ],
  8: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'latigo' },
    { level: 8, moveId: 'burbuja' },
    { level: 15, moveId: 'refugio' },
    { level: 24, moveId: 'pistola_agua' },
    { level: 31, moveId: 'mordisco' },
    { level: 39, moveId: 'rayo_burbuja' },
    { level: 47, moveId: 'hidrobomba' },
  ],
  9: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'latigo' },
    { level: 8, moveId: 'burbuja' },
    { level: 15, moveId: 'refugio' },
    { level: 24, moveId: 'pistola_agua' },
    { level: 31, moveId: 'mordisco' },
    { level: 42, moveId: 'rayo_burbuja' },
    { level: 52, moveId: 'hidrobomba' },
  ],

  // Caterpie line
  10: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'atadura' },
  ],
  11: [
    { level: 1, moveId: 'fortaleza' },
    { level: 7, moveId: 'fortaleza' },
  ],
  12: [
    { level: 1, moveId: 'confusion' },
    { level: 10, moveId: 'confusion' },
    { level: 12, moveId: 'polvo_veneno' },
    { level: 15, moveId: 'somnifero' },
    { level: 18, moveId: 'tornado' },
    { level: 24, moveId: 'psicorrayo' },
    { level: 32, moveId: 'psiquico' },
  ],

  // Weedle line
  13: [
    { level: 1, moveId: 'picotazo_veneno' },
    { level: 1, moveId: 'atadura' },
  ],
  14: [
    { level: 1, moveId: 'fortaleza' },
    { level: 7, moveId: 'fortaleza' },
  ],
  15: [
    { level: 1, moveId: 'ataque_furia' },
    { level: 10, moveId: 'ataque_furia' },
    { level: 16, moveId: 'foco_energia' },
    { level: 20, moveId: 'tijera_x' },
    { level: 25, moveId: 'furia' },
    { level: 30, moveId: 'pin_misil' },
    { level: 35, moveId: 'agilidad' },
  ],

  // Pidgey line
  16: [
    { level: 1, moveId: 'tornado' },
    { level: 5, moveId: 'ataque_arena' },
    { level: 12, moveId: 'ataque_rapido' },
    { level: 19, moveId: 'tornado' },
    { level: 28, moveId: 'ataque_ala' },
    { level: 36, moveId: 'agilidad' },
  ],
  17: [
    { level: 1, moveId: 'tornado' },
    { level: 5, moveId: 'ataque_arena' },
    { level: 12, moveId: 'ataque_rapido' },
    { level: 21, moveId: 'tornado' },
    { level: 31, moveId: 'ataque_ala' },
    { level: 40, moveId: 'agilidad' },
  ],
  18: [
    { level: 1, moveId: 'tornado' },
    { level: 5, moveId: 'ataque_arena' },
    { level: 12, moveId: 'ataque_rapido' },
    { level: 21, moveId: 'tornado' },
    { level: 31, moveId: 'ataque_ala' },
    { level: 44, moveId: 'agilidad' },
  ],

  // Rattata line
  19: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'latigo' },
    { level: 7, moveId: 'ataque_rapido' },
    { level: 14, moveId: 'hipercolmillo' },
    { level: 23, moveId: 'foco_energia' },
    { level: 34, moveId: 'golpe_cuerpo' },
  ],
  20: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'latigo' },
    { level: 7, moveId: 'ataque_rapido' },
    { level: 14, moveId: 'hipercolmillo' },
    { level: 27, moveId: 'foco_energia' },
    { level: 41, moveId: 'golpe_cuerpo' },
  ],

  // Spearow line
  21: [
    { level: 1, moveId: 'picotazo' },
    { level: 1, moveId: 'grunido' },
    { level: 9, moveId: 'malicioso' },
    { level: 15, moveId: 'ataque_furia' },
    { level: 22, moveId: 'espejo' },
    { level: 29, moveId: 'pico_taladro' },
    { level: 36, moveId: 'agilidad' },
  ],
  22: [
    { level: 1, moveId: 'picotazo' },
    { level: 1, moveId: 'grunido' },
    { level: 9, moveId: 'malicioso' },
    { level: 15, moveId: 'ataque_furia' },
    { level: 25, moveId: 'espejo' },
    { level: 34, moveId: 'pico_taladro' },
    { level: 43, moveId: 'agilidad' },
  ],

  // Ekans line
  23: [
    { level: 1, moveId: 'atadura' },
    { level: 1, moveId: 'malicioso' },
    { level: 10, moveId: 'picotazo_veneno' },
    { level: 17, moveId: 'mordisco' },
    { level: 24, moveId: 'deslumbrar' },
    { level: 31, moveId: 'chirrido' },
    { level: 38, moveId: 'acido' },
  ],
  24: [
    { level: 1, moveId: 'atadura' },
    { level: 1, moveId: 'malicioso' },
    { level: 10, moveId: 'picotazo_veneno' },
    { level: 17, moveId: 'mordisco' },
    { level: 27, moveId: 'deslumbrar' },
    { level: 36, moveId: 'chirrido' },
    { level: 47, moveId: 'acido' },
  ],

  // Pikachu line
  25: [
    { level: 1, moveId: 'impactrueno' },
    { level: 1, moveId: 'grunido' },
    { level: 6, moveId: 'latigo' },
    { level: 9, moveId: 'onda_trueno' },
    { level: 16, moveId: 'ataque_rapido' },
    { level: 26, moveId: 'rayo' },
    { level: 33, moveId: 'agilidad' },
    { level: 43, moveId: 'trueno' },
  ],
  26: [
    { level: 1, moveId: 'impactrueno' },
    { level: 1, moveId: 'latigo' },
    { level: 1, moveId: 'rayo' },
  ],

  // Sandshrew line
  27: [
    { level: 1, moveId: 'aranazo' },
    { level: 1, moveId: 'rizo_defensa' },
    { level: 10, moveId: 'ataque_arena' },
    { level: 17, moveId: 'cuchillada' },
    { level: 24, moveId: 'picotazo_veneno' },
    { level: 31, moveId: 'excavar' },
    { level: 38, moveId: 'terremoto' },
  ],
  28: [
    { level: 1, moveId: 'aranazo' },
    { level: 1, moveId: 'rizo_defensa' },
    { level: 10, moveId: 'ataque_arena' },
    { level: 17, moveId: 'cuchillada' },
    { level: 27, moveId: 'picotazo_veneno' },
    { level: 36, moveId: 'excavar' },
    { level: 47, moveId: 'terremoto' },
  ],

  // Nidoran F line
  29: [
    { level: 1, moveId: 'grunido' },
    { level: 1, moveId: 'placaje' },
    { level: 8, moveId: 'aranazo' },
    { level: 14, moveId: 'picotazo_veneno' },
    { level: 21, moveId: 'latigo' },
    { level: 29, moveId: 'mordisco' },
    { level: 36, moveId: 'ataque_furia' },
    { level: 43, moveId: 'doble_filo' },
  ],
  30: [
    { level: 1, moveId: 'grunido' },
    { level: 1, moveId: 'placaje' },
    { level: 8, moveId: 'aranazo' },
    { level: 14, moveId: 'picotazo_veneno' },
    { level: 23, moveId: 'latigo' },
    { level: 32, moveId: 'mordisco' },
    { level: 41, moveId: 'ataque_furia' },
    { level: 50, moveId: 'doble_filo' },
  ],
  31: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'aranazo' },
    { level: 1, moveId: 'golpe_cuerpo' },
    { level: 23, moveId: 'golpe_cuerpo' },
  ],

  // Nidoran M line
  32: [
    { level: 1, moveId: 'malicioso' },
    { level: 1, moveId: 'placaje' },
    { level: 8, moveId: 'cornada' },
    { level: 14, moveId: 'picotazo_veneno' },
    { level: 21, moveId: 'foco_energia' },
    { level: 29, moveId: 'ataque_furia' },
    { level: 36, moveId: 'golpe_cabeza' },
    { level: 43, moveId: 'doble_filo' },
  ],
  33: [
    { level: 1, moveId: 'malicioso' },
    { level: 1, moveId: 'placaje' },
    { level: 8, moveId: 'cornada' },
    { level: 14, moveId: 'picotazo_veneno' },
    { level: 23, moveId: 'foco_energia' },
    { level: 32, moveId: 'ataque_furia' },
    { level: 41, moveId: 'golpe_cabeza' },
    { level: 50, moveId: 'doble_filo' },
  ],
  34: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'cornada' },
    { level: 1, moveId: 'golpe_cuerpo' },
    { level: 23, moveId: 'golpe_cuerpo' },
  ],

  // Clefairy line
  35: [
    { level: 1, moveId: 'destructor' },
    { level: 1, moveId: 'grunido' },
    { level: 13, moveId: 'canto' },
    { level: 18, moveId: 'bofeton' },
    { level: 24, moveId: 'reduccion' },
    { level: 31, moveId: 'metronomo' },
    { level: 39, moveId: 'armadura_acida' },
    { level: 48, moveId: 'luz_lunar' },
  ],
  36: [
    { level: 1, moveId: 'destructor' },
    { level: 1, moveId: 'bofeton' },
  ],

  // Vulpix line
  37: [
    { level: 1, moveId: 'ascuas' },
    { level: 1, moveId: 'latigo' },
    { level: 16, moveId: 'ataque_rapido' },
    { level: 21, moveId: 'furia' },
    { level: 28, moveId: 'rayo_confuso' },
    { level: 35, moveId: 'lanzallamas' },
    { level: 42, moveId: 'giro_fuego' },
  ],
  38: [
    { level: 1, moveId: 'ascuas' },
    { level: 1, moveId: 'ataque_rapido' },
    { level: 1, moveId: 'lanzallamas' },
  ],

  // Jigglypuff line
  39: [
    { level: 1, moveId: 'canto' },
    { level: 9, moveId: 'destructor' },
    { level: 14, moveId: 'desactivacion' },
    { level: 19, moveId: 'rizo_defensa' },
    { level: 24, moveId: 'bofeton' },
    { level: 29, moveId: 'descanso' },
    { level: 34, moveId: 'golpe_cuerpo' },
    { level: 39, moveId: 'doble_filo' },
  ],
  40: [
    { level: 1, moveId: 'canto' },
    { level: 1, moveId: 'destructor' },
    { level: 1, moveId: 'golpe_cuerpo' },
  ],

  // Zubat line
  41: [
    { level: 1, moveId: 'picotazo' },
    { level: 1, moveId: 'picadura' },
    { level: 10, moveId: 'supersonico' },
    { level: 15, moveId: 'mordisco' },
    { level: 21, moveId: 'rayo_confuso' },
    { level: 28, moveId: 'ataque_ala' },
    { level: 36, moveId: 'tinieblas' },
  ],
  42: [
    { level: 1, moveId: 'picotazo' },
    { level: 1, moveId: 'picadura' },
    { level: 10, moveId: 'supersonico' },
    { level: 15, moveId: 'mordisco' },
    { level: 21, moveId: 'rayo_confuso' },
    { level: 32, moveId: 'ataque_ala' },
    { level: 43, moveId: 'tinieblas' },
  ],

  // Oddish line
  43: [
    { level: 1, moveId: 'absorber' },
    { level: 15, moveId: 'polvo_veneno' },
    { level: 17, moveId: 'somnifero' },
    { level: 19, moveId: 'acido' },
    { level: 24, moveId: 'megaagotar' },
    { level: 33, moveId: 'danza_petalo' },
    { level: 46, moveId: 'rayo_solar' },
  ],
  44: [
    { level: 1, moveId: 'absorber' },
    { level: 15, moveId: 'polvo_veneno' },
    { level: 17, moveId: 'somnifero' },
    { level: 19, moveId: 'acido' },
    { level: 24, moveId: 'megaagotar' },
    { level: 38, moveId: 'danza_petalo' },
    { level: 52, moveId: 'rayo_solar' },
  ],
  45: [
    { level: 1, moveId: 'absorber' },
    { level: 1, moveId: 'acido' },
    { level: 1, moveId: 'danza_petalo' },
  ],

  // Paras line
  46: [
    { level: 1, moveId: 'aranazo' },
    { level: 13, moveId: 'espora' },
    { level: 20, moveId: 'picadura' },
    { level: 27, moveId: 'cuchillada' },
    { level: 34, moveId: 'desarrollo' },
    { level: 41, moveId: 'danza_espada' },
  ],
  47: [
    { level: 1, moveId: 'aranazo' },
    { level: 13, moveId: 'espora' },
    { level: 20, moveId: 'picadura' },
    { level: 30, moveId: 'cuchillada' },
    { level: 39, moveId: 'desarrollo' },
    { level: 48, moveId: 'danza_espada' },
  ],

  // Venonat line
  48: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'desactivacion' },
    { level: 11, moveId: 'confusion' },
    { level: 19, moveId: 'polvo_veneno' },
    { level: 24, moveId: 'picadura' },
    { level: 27, moveId: 'somnifero' },
    { level: 35, moveId: 'psicorrayo' },
    { level: 43, moveId: 'psiquico' },
  ],
  49: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'desactivacion' },
    { level: 11, moveId: 'confusion' },
    { level: 19, moveId: 'polvo_veneno' },
    { level: 24, moveId: 'picadura' },
    { level: 27, moveId: 'somnifero' },
    { level: 38, moveId: 'psicorrayo' },
    { level: 50, moveId: 'psiquico' },
  ],

  // Diglett line
  50: [
    { level: 1, moveId: 'aranazo' },
    { level: 1, moveId: 'ataque_arena' },
    { level: 15, moveId: 'grunido' },
    { level: 19, moveId: 'excavar' },
    { level: 24, moveId: 'ataque_arena' },
    { level: 31, moveId: 'cuchillada' },
    { level: 40, moveId: 'terremoto' },
  ],
  51: [
    { level: 1, moveId: 'aranazo' },
    { level: 1, moveId: 'ataque_arena' },
    { level: 15, moveId: 'grunido' },
    { level: 19, moveId: 'excavar' },
    { level: 24, moveId: 'triataque' },
    { level: 35, moveId: 'cuchillada' },
    { level: 47, moveId: 'terremoto' },
  ],

  // Meowth line
  52: [
    { level: 1, moveId: 'aranazo' },
    { level: 1, moveId: 'grunido' },
    { level: 12, moveId: 'mordisco' },
    { level: 17, moveId: 'dia_pago' },
    { level: 24, moveId: 'chirrido' },
    { level: 33, moveId: 'furia' },
    { level: 44, moveId: 'cuchillada' },
  ],
  53: [
    { level: 1, moveId: 'aranazo' },
    { level: 1, moveId: 'grunido' },
    { level: 12, moveId: 'mordisco' },
    { level: 17, moveId: 'dia_pago' },
    { level: 24, moveId: 'chirrido' },
    { level: 37, moveId: 'furia' },
    { level: 51, moveId: 'cuchillada' },
  ],

  // Psyduck line
  54: [
    { level: 1, moveId: 'aranazo' },
    { level: 1, moveId: 'latigo' },
    { level: 15, moveId: 'desactivacion' },
    { level: 28, moveId: 'confusion' },
    { level: 36, moveId: 'furia' },
    { level: 44, moveId: 'hidrobomba' },
  ],
  55: [
    { level: 1, moveId: 'aranazo' },
    { level: 1, moveId: 'latigo' },
    { level: 15, moveId: 'desactivacion' },
    { level: 28, moveId: 'confusion' },
    { level: 39, moveId: 'furia' },
    { level: 48, moveId: 'hidrobomba' },
  ],

  // Mankey line
  56: [
    { level: 1, moveId: 'aranazo' },
    { level: 1, moveId: 'malicioso' },
    { level: 9, moveId: 'golpe_karate' },
    { level: 15, moveId: 'furia' },
    { level: 21, moveId: 'foco_energia' },
    { level: 27, moveId: 'movimiento_sismico' },
    { level: 33, moveId: 'chirrido' },
    { level: 39, moveId: 'sumision' },
  ],
  57: [
    { level: 1, moveId: 'aranazo' },
    { level: 1, moveId: 'malicioso' },
    { level: 9, moveId: 'golpe_karate' },
    { level: 15, moveId: 'furia' },
    { level: 21, moveId: 'foco_energia' },
    { level: 27, moveId: 'movimiento_sismico' },
    { level: 37, moveId: 'chirrido' },
    { level: 45, moveId: 'sumision' },
  ],

  // Growlithe line
  58: [
    { level: 1, moveId: 'mordisco' },
    { level: 1, moveId: 'rugido' },
    { level: 18, moveId: 'ascuas' },
    { level: 23, moveId: 'malicioso' },
    { level: 30, moveId: 'derribo' },
    { level: 39, moveId: 'agilidad' },
    { level: 50, moveId: 'lanzallamas' },
  ],
  59: [
    { level: 1, moveId: 'mordisco' },
    { level: 1, moveId: 'rugido' },
    { level: 1, moveId: 'ascuas' },
    { level: 1, moveId: 'lanzallamas' },
  ],

  // Poliwag line
  60: [
    { level: 1, moveId: 'burbuja' },
    { level: 16, moveId: 'hipnosis' },
    { level: 19, moveId: 'pistola_agua' },
    { level: 25, moveId: 'bofeton' },
    { level: 31, moveId: 'golpe_cuerpo' },
    { level: 38, moveId: 'amnesia' },
    { level: 45, moveId: 'hidrobomba' },
  ],
  61: [
    { level: 1, moveId: 'burbuja' },
    { level: 16, moveId: 'hipnosis' },
    { level: 19, moveId: 'pistola_agua' },
    { level: 26, moveId: 'bofeton' },
    { level: 33, moveId: 'golpe_cuerpo' },
    { level: 41, moveId: 'amnesia' },
    { level: 49, moveId: 'hidrobomba' },
  ],
  62: [
    { level: 1, moveId: 'burbuja' },
    { level: 1, moveId: 'hipnosis' },
    { level: 1, moveId: 'pistola_agua' },
    { level: 1, moveId: 'sumision' },
  ],

  // Abra line
  63: [
    { level: 1, moveId: 'teletransporte' },
  ],
  64: [
    { level: 1, moveId: 'teletransporte' },
    { level: 16, moveId: 'confusion' },
    { level: 20, moveId: 'desactivacion' },
    { level: 27, moveId: 'psicorrayo' },
    { level: 31, moveId: 'recuperacion' },
    { level: 38, moveId: 'psiquico' },
    { level: 42, moveId: 'reflejo' },
  ],
  65: [
    { level: 1, moveId: 'teletransporte' },
    { level: 16, moveId: 'confusion' },
    { level: 20, moveId: 'desactivacion' },
    { level: 27, moveId: 'psicorrayo' },
    { level: 31, moveId: 'recuperacion' },
    { level: 38, moveId: 'psiquico' },
    { level: 42, moveId: 'reflejo' },
  ],

  // Machop line
  66: [
    { level: 1, moveId: 'golpe_karate' },
    { level: 1, moveId: 'malicioso' },
    { level: 20, moveId: 'foco_energia' },
    { level: 25, moveId: 'movimiento_sismico' },
    { level: 32, moveId: 'sumision' },
  ],
  67: [
    { level: 1, moveId: 'golpe_karate' },
    { level: 1, moveId: 'malicioso' },
    { level: 20, moveId: 'foco_energia' },
    { level: 25, moveId: 'movimiento_sismico' },
    { level: 36, moveId: 'sumision' },
  ],
  68: [
    { level: 1, moveId: 'golpe_karate' },
    { level: 1, moveId: 'malicioso' },
    { level: 20, moveId: 'foco_energia' },
    { level: 25, moveId: 'movimiento_sismico' },
    { level: 36, moveId: 'sumision' },
  ],

  // Bellsprout line
  69: [
    { level: 1, moveId: 'latigo_cepa' },
    { level: 13, moveId: 'desarrollo' },
    { level: 15, moveId: 'polvo_veneno' },
    { level: 18, moveId: 'somnifero' },
    { level: 21, moveId: 'acido' },
    { level: 26, moveId: 'hoja_afilada' },
    { level: 33, moveId: 'portazo' },
  ],
  70: [
    { level: 1, moveId: 'latigo_cepa' },
    { level: 13, moveId: 'desarrollo' },
    { level: 15, moveId: 'polvo_veneno' },
    { level: 18, moveId: 'somnifero' },
    { level: 23, moveId: 'acido' },
    { level: 29, moveId: 'hoja_afilada' },
    { level: 38, moveId: 'portazo' },
  ],
  71: [
    { level: 1, moveId: 'latigo_cepa' },
    { level: 1, moveId: 'hoja_afilada' },
    { level: 1, moveId: 'somnifero' },
  ],

  // Tentacool line
  72: [
    { level: 1, moveId: 'acido' },
    { level: 7, moveId: 'supersonico' },
    { level: 13, moveId: 'constriccion' },
    { level: 18, moveId: 'picotazo_veneno' },
    { level: 22, moveId: 'pistola_agua' },
    { level: 27, moveId: 'armadura_acida' },
    { level: 33, moveId: 'barrera' },
    { level: 40, moveId: 'hidrobomba' },
  ],
  73: [
    { level: 1, moveId: 'acido' },
    { level: 7, moveId: 'supersonico' },
    { level: 13, moveId: 'constriccion' },
    { level: 18, moveId: 'picotazo_veneno' },
    { level: 22, moveId: 'pistola_agua' },
    { level: 27, moveId: 'armadura_acida' },
    { level: 35, moveId: 'barrera' },
    { level: 47, moveId: 'hidrobomba' },
  ],

  // Geodude line
  74: [
    { level: 1, moveId: 'placaje' },
    { level: 11, moveId: 'rizo_defensa' },
    { level: 16, moveId: 'lanzarrocas' },
    { level: 21, moveId: 'autodestruccion' },
    { level: 26, moveId: 'fortaleza' },
    { level: 31, moveId: 'terremoto' },
    { level: 36, moveId: 'explosion' },
  ],
  75: [
    { level: 1, moveId: 'placaje' },
    { level: 11, moveId: 'rizo_defensa' },
    { level: 16, moveId: 'lanzarrocas' },
    { level: 21, moveId: 'autodestruccion' },
    { level: 29, moveId: 'fortaleza' },
    { level: 36, moveId: 'terremoto' },
    { level: 43, moveId: 'explosion' },
  ],
  76: [
    { level: 1, moveId: 'placaje' },
    { level: 11, moveId: 'rizo_defensa' },
    { level: 16, moveId: 'lanzarrocas' },
    { level: 21, moveId: 'autodestruccion' },
    { level: 29, moveId: 'fortaleza' },
    { level: 36, moveId: 'terremoto' },
    { level: 43, moveId: 'explosion' },
  ],

  // Ponyta line
  77: [
    { level: 1, moveId: 'ascuas' },
    { level: 1, moveId: 'latigo' },
    { level: 30, moveId: 'pisoton' },
    { level: 32, moveId: 'grunido' },
    { level: 35, moveId: 'giro_fuego' },
    { level: 39, moveId: 'derribo' },
    { level: 43, moveId: 'agilidad' },
    { level: 48, moveId: 'llamarada' },
  ],
  78: [
    { level: 1, moveId: 'ascuas' },
    { level: 1, moveId: 'latigo' },
    { level: 30, moveId: 'pisoton' },
    { level: 32, moveId: 'grunido' },
    { level: 35, moveId: 'giro_fuego' },
    { level: 39, moveId: 'derribo' },
    { level: 47, moveId: 'agilidad' },
    { level: 55, moveId: 'llamarada' },
  ],

  // Slowpoke line
  79: [
    { level: 1, moveId: 'confusion' },
    { level: 18, moveId: 'desactivacion' },
    { level: 22, moveId: 'golpe_cabeza' },
    { level: 27, moveId: 'grunido' },
    { level: 33, moveId: 'pistola_agua' },
    { level: 40, moveId: 'amnesia' },
    { level: 48, moveId: 'psiquico' },
  ],
  80: [
    { level: 1, moveId: 'confusion' },
    { level: 18, moveId: 'desactivacion' },
    { level: 22, moveId: 'golpe_cabeza' },
    { level: 27, moveId: 'grunido' },
    { level: 33, moveId: 'pistola_agua' },
    { level: 37, moveId: 'refugio' },
    { level: 44, moveId: 'amnesia' },
    { level: 55, moveId: 'psiquico' },
  ],

  // Magnemite line
  81: [
    { level: 1, moveId: 'placaje' },
    { level: 21, moveId: 'sonico' },
    { level: 25, moveId: 'impactrueno' },
    { level: 29, moveId: 'supersonico' },
    { level: 35, moveId: 'onda_trueno' },
    { level: 41, moveId: 'rapidez' },
    { level: 47, moveId: 'chirrido' },
  ],
  82: [
    { level: 1, moveId: 'placaje' },
    { level: 21, moveId: 'sonico' },
    { level: 25, moveId: 'impactrueno' },
    { level: 29, moveId: 'supersonico' },
    { level: 38, moveId: 'onda_trueno' },
    { level: 46, moveId: 'rapidez' },
    { level: 54, moveId: 'chirrido' },
  ],

  // Farfetch'd
  83: [
    { level: 1, moveId: 'picotazo' },
    { level: 1, moveId: 'tornado' },
    { level: 7, moveId: 'malicioso' },
    { level: 15, moveId: 'ataque_furia' },
    { level: 23, moveId: 'danza_espada' },
    { level: 31, moveId: 'agilidad' },
    { level: 39, moveId: 'cuchillada' },
  ],

  // Doduo line
  84: [
    { level: 1, moveId: 'picotazo' },
    { level: 20, moveId: 'grunido' },
    { level: 24, moveId: 'ataque_furia' },
    { level: 30, moveId: 'pico_taladro' },
    { level: 36, moveId: 'furia' },
    { level: 40, moveId: 'agilidad' },
  ],
  85: [
    { level: 1, moveId: 'picotazo' },
    { level: 20, moveId: 'grunido' },
    { level: 24, moveId: 'ataque_furia' },
    { level: 30, moveId: 'pico_taladro' },
    { level: 39, moveId: 'furia' },
    { level: 45, moveId: 'agilidad' },
  ],

  // Seel line
  86: [
    { level: 1, moveId: 'golpe_cabeza' },
    { level: 30, moveId: 'grunido' },
    { level: 35, moveId: 'rayo_aurora' },
    { level: 40, moveId: 'descanso' },
    { level: 45, moveId: 'derribo' },
    { level: 50, moveId: 'rayo_hielo' },
  ],
  87: [
    { level: 1, moveId: 'golpe_cabeza' },
    { level: 30, moveId: 'grunido' },
    { level: 35, moveId: 'rayo_aurora' },
    { level: 44, moveId: 'descanso' },
    { level: 50, moveId: 'derribo' },
    { level: 56, moveId: 'rayo_hielo' },
  ],

  // Grimer line
  88: [
    { level: 1, moveId: 'destructor' },
    { level: 1, moveId: 'gas_venenoso' },
    { level: 30, moveId: 'residuos' },
    { level: 33, moveId: 'fortaleza' },
    { level: 37, moveId: 'chirrido' },
    { level: 42, moveId: 'armadura_acida' },
    { level: 48, moveId: 'bomba_lodo' },
  ],
  89: [
    { level: 1, moveId: 'destructor' },
    { level: 1, moveId: 'gas_venenoso' },
    { level: 30, moveId: 'residuos' },
    { level: 33, moveId: 'fortaleza' },
    { level: 37, moveId: 'chirrido' },
    { level: 45, moveId: 'armadura_acida' },
    { level: 53, moveId: 'bomba_lodo' },
  ],

  // Shellder line
  90: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'refugio' },
    { level: 18, moveId: 'supersonico' },
    { level: 23, moveId: 'tenaza' },
    { level: 30, moveId: 'rayo_aurora' },
    { level: 39, moveId: 'malicioso' },
    { level: 50, moveId: 'hidrobomba' },
  ],
  91: [
    { level: 1, moveId: 'refugio' },
    { level: 1, moveId: 'supersonico' },
    { level: 1, moveId: 'tenaza' },
    { level: 1, moveId: 'rayo_aurora' },
  ],

  // Gastly line
  92: [
    { level: 1, moveId: 'lenguetazo' },
    { level: 1, moveId: 'rayo_confuso' },
    { level: 1, moveId: 'tinieblas' },
    { level: 27, moveId: 'hipnosis' },
    { level: 35, moveId: 'comesuenos' },
  ],
  93: [
    { level: 1, moveId: 'lenguetazo' },
    { level: 1, moveId: 'rayo_confuso' },
    { level: 1, moveId: 'tinieblas' },
    { level: 29, moveId: 'hipnosis' },
    { level: 38, moveId: 'comesuenos' },
  ],
  94: [
    { level: 1, moveId: 'lenguetazo' },
    { level: 1, moveId: 'rayo_confuso' },
    { level: 1, moveId: 'tinieblas' },
    { level: 29, moveId: 'hipnosis' },
    { level: 38, moveId: 'comesuenos' },
  ],

  // Onix
  95: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'chirrido' },
    { level: 15, moveId: 'atadura' },
    { level: 19, moveId: 'lanzarrocas' },
    { level: 25, moveId: 'furia' },
    { level: 33, moveId: 'portazo' },
    { level: 43, moveId: 'fortaleza' },
  ],

  // Drowzee line
  96: [
    { level: 1, moveId: 'destructor' },
    { level: 1, moveId: 'hipnosis' },
    { level: 12, moveId: 'desactivacion' },
    { level: 17, moveId: 'confusion' },
    { level: 24, moveId: 'golpe_cabeza' },
    { level: 29, moveId: 'gas_venenoso' },
    { level: 32, moveId: 'psiquico' },
    { level: 37, moveId: 'meditacion' },
  ],
  97: [
    { level: 1, moveId: 'destructor' },
    { level: 1, moveId: 'hipnosis' },
    { level: 12, moveId: 'desactivacion' },
    { level: 17, moveId: 'confusion' },
    { level: 24, moveId: 'golpe_cabeza' },
    { level: 33, moveId: 'gas_venenoso' },
    { level: 37, moveId: 'psiquico' },
    { level: 43, moveId: 'meditacion' },
  ],

  // Krabby line
  98: [
    { level: 1, moveId: 'burbuja' },
    { level: 1, moveId: 'malicioso' },
    { level: 20, moveId: 'tenaza' },
    { level: 25, moveId: 'pistola_agua' },
    { level: 30, moveId: 'guillotina' },
    { level: 35, moveId: 'pisoton' },
    { level: 40, moveId: 'armadura_acida' },
  ],
  99: [
    { level: 1, moveId: 'burbuja' },
    { level: 1, moveId: 'malicioso' },
    { level: 20, moveId: 'tenaza' },
    { level: 25, moveId: 'pistola_agua' },
    { level: 34, moveId: 'guillotina' },
    { level: 42, moveId: 'pisoton' },
    { level: 49, moveId: 'armadura_acida' },
  ],

  // Voltorb line
  100: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'chirrido' },
    { level: 17, moveId: 'sonico' },
    { level: 22, moveId: 'autodestruccion' },
    { level: 29, moveId: 'rapidez' },
    { level: 36, moveId: 'explosion' },
    { level: 43, moveId: 'pantalla_luz' },
  ],
  101: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'chirrido' },
    { level: 17, moveId: 'sonico' },
    { level: 22, moveId: 'autodestruccion' },
    { level: 29, moveId: 'rapidez' },
    { level: 40, moveId: 'explosion' },
    { level: 50, moveId: 'pantalla_luz' },
  ],

  // Exeggcute line
  102: [
    { level: 1, moveId: 'barrera' },
    { level: 1, moveId: 'hipnosis' },
    { level: 25, moveId: 'reflejo' },
    { level: 28, moveId: 'deslumbrar' },
    { level: 32, moveId: 'polvo_veneno' },
    { level: 37, moveId: 'somnifero' },
    { level: 42, moveId: 'rayo_solar' },
  ],
  103: [
    { level: 1, moveId: 'barrera' },
    { level: 1, moveId: 'hipnosis' },
    { level: 1, moveId: 'pisoton' },
  ],

  // Cubone line
  104: [
    { level: 1, moveId: 'hueso_palo' },
    { level: 1, moveId: 'grunido' },
    { level: 10, moveId: 'latigo' },
    { level: 13, moveId: 'golpe_cabeza' },
    { level: 18, moveId: 'malicioso' },
    { level: 25, moveId: 'foco_energia' },
    { level: 31, moveId: 'huesomerang' },
    { level: 38, moveId: 'furia' },
  ],
  105: [
    { level: 1, moveId: 'hueso_palo' },
    { level: 1, moveId: 'grunido' },
    { level: 10, moveId: 'latigo' },
    { level: 13, moveId: 'golpe_cabeza' },
    { level: 18, moveId: 'malicioso' },
    { level: 25, moveId: 'foco_energia' },
    { level: 33, moveId: 'huesomerang' },
    { level: 41, moveId: 'furia' },
  ],

  // Hitmonlee & Hitmonchan
  106: [
    { level: 1, moveId: 'patada_doble' },
    { level: 1, moveId: 'meditacion' },
    { level: 33, moveId: 'patada_giro' },
    { level: 38, moveId: 'patada_salto' },
    { level: 43, moveId: 'foco_energia' },
    { level: 48, moveId: 'patada_alta' },
    { level: 53, moveId: 'mega_patada' },
  ],
  107: [
    { level: 1, moveId: 'punetazo_cometa' },
    { level: 1, moveId: 'agilidad' },
    { level: 33, moveId: 'puno_fuego' },
    { level: 38, moveId: 'puno_hielo' },
    { level: 43, moveId: 'puno_trueno' },
    { level: 48, moveId: 'mega_puno' },
    { level: 53, moveId: 'contraataque' },
  ],

  // Lickitung
  108: [
    { level: 1, moveId: 'atadura' },
    { level: 1, moveId: 'supersonico' },
    { level: 7, moveId: 'pisoton' },
    { level: 15, moveId: 'desactivacion' },
    { level: 23, moveId: 'armadura_acida' },
    { level: 31, moveId: 'portazo' },
    { level: 39, moveId: 'chirrido' },
  ],

  // Koffing line
  109: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'pantalla_humo' },
    { level: 32, moveId: 'residuos' },
    { level: 37, moveId: 'pantalla_humo' },
    { level: 40, moveId: 'autodestruccion' },
    { level: 45, moveId: 'polucion' },
    { level: 48, moveId: 'explosion' },
  ],
  110: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'pantalla_humo' },
    { level: 32, moveId: 'residuos' },
    { level: 39, moveId: 'pantalla_humo' },
    { level: 43, moveId: 'autodestruccion' },
    { level: 49, moveId: 'polucion' },
    { level: 53, moveId: 'explosion' },
  ],

  // Rhyhorn line
  111: [
    { level: 1, moveId: 'cornada' },
    { level: 30, moveId: 'pisoton' },
    { level: 35, moveId: 'latigo' },
    { level: 40, moveId: 'malicioso' },
    { level: 45, moveId: 'furia' },
    { level: 50, moveId: 'terremoto' },
  ],
  112: [
    { level: 1, moveId: 'cornada' },
    { level: 30, moveId: 'pisoton' },
    { level: 35, moveId: 'latigo' },
    { level: 40, moveId: 'malicioso' },
    { level: 48, moveId: 'furia' },
    { level: 55, moveId: 'terremoto' },
  ],

  // Chansey
  113: [
    { level: 1, moveId: 'destructor' },
    { level: 1, moveId: 'bofeton' },
    { level: 24, moveId: 'canto' },
    { level: 30, moveId: 'grunido' },
    { level: 38, moveId: 'reduccion' },
    { level: 44, moveId: 'armadura_acida' },
    { level: 48, moveId: 'pantalla_luz' },
    { level: 54, moveId: 'doble_filo' },
  ],

  // Tangela
  114: [
    { level: 1, moveId: 'constriccion' },
    { level: 1, moveId: 'somnifero' },
    { level: 29, moveId: 'absorber' },
    { level: 32, moveId: 'polvo_veneno' },
    { level: 36, moveId: 'atadura' },
    { level: 39, moveId: 'megaagotar' },
    { level: 45, moveId: 'portazo' },
    { level: 49, moveId: 'desarrollo' },
  ],

  // Kangaskhan
  115: [
    { level: 1, moveId: 'punetazo_cometa' },
    { level: 1, moveId: 'furia' },
    { level: 26, moveId: 'mordisco' },
    { level: 31, moveId: 'latigo' },
    { level: 36, moveId: 'mega_puno' },
    { level: 41, moveId: 'malicioso' },
    { level: 46, moveId: 'pisoton' },
  ],

  // Horsea line
  116: [
    { level: 1, moveId: 'burbuja' },
    { level: 19, moveId: 'pantalla_humo' },
    { level: 24, moveId: 'malicioso' },
    { level: 30, moveId: 'pistola_agua' },
    { level: 37, moveId: 'agilidad' },
    { level: 45, moveId: 'hidrobomba' },
  ],
  117: [
    { level: 1, moveId: 'burbuja' },
    { level: 19, moveId: 'pantalla_humo' },
    { level: 24, moveId: 'malicioso' },
    { level: 30, moveId: 'pistola_agua' },
    { level: 41, moveId: 'agilidad' },
    { level: 52, moveId: 'hidrobomba' },
  ],

  // Goldeen line
  118: [
    { level: 1, moveId: 'picotazo' },
    { level: 1, moveId: 'latigo' },
    { level: 19, moveId: 'ataque_rapido' },
    { level: 24, moveId: 'cornada' },
    { level: 30, moveId: 'ataque_furia' },
    { level: 37, moveId: 'cascada' },
    { level: 45, moveId: 'perforador' },
    { level: 54, moveId: 'agilidad' },
  ],
  119: [
    { level: 1, moveId: 'picotazo' },
    { level: 1, moveId: 'latigo' },
    { level: 19, moveId: 'ataque_rapido' },
    { level: 24, moveId: 'cornada' },
    { level: 30, moveId: 'ataque_furia' },
    { level: 39, moveId: 'cascada' },
    { level: 48, moveId: 'perforador' },
    { level: 54, moveId: 'agilidad' },
  ],

  // Staryu line
  120: [
    { level: 1, moveId: 'placaje' },
    { level: 17, moveId: 'pistola_agua' },
    { level: 22, moveId: 'fortaleza' },
    { level: 27, moveId: 'recuperacion' },
    { level: 32, moveId: 'rapidez' },
    { level: 37, moveId: 'rayo_burbuja' },
    { level: 42, moveId: 'reduccion' },
    { level: 47, moveId: 'pantalla_luz' },
    { level: 52, moveId: 'hidrobomba' },
  ],
  121: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'pistola_agua' },
    { level: 1, moveId: 'recuperacion' },
    { level: 1, moveId: 'rayo_burbuja' },
  ],

  // Mr. Mime
  122: [
    { level: 1, moveId: 'confusion' },
    { level: 1, moveId: 'barrera' },
    { level: 15, moveId: 'pantalla_luz' },
    { level: 23, moveId: 'bofeton' },
    { level: 31, moveId: 'meditacion' },
    { level: 39, moveId: 'sustituto' },
  ],

  // Scyther
  123: [
    { level: 1, moveId: 'ataque_rapido' },
    { level: 17, moveId: 'malicioso' },
    { level: 20, moveId: 'foco_energia' },
    { level: 24, moveId: 'tijera_x' },
    { level: 29, moveId: 'cuchillada' },
    { level: 35, moveId: 'danza_espada' },
    { level: 42, moveId: 'agilidad' },
  ],

  // Jynx
  124: [
    { level: 1, moveId: 'destructor' },
    { level: 1, moveId: 'lenguetazo' },
    { level: 18, moveId: 'bofeton' },
    { level: 23, moveId: 'puno_hielo' },
    { level: 31, moveId: 'golpe_cuerpo' },
    { level: 39, moveId: 'alud' },
    { level: 47, moveId: 'ventisca' },
  ],

  // Electabuzz
  125: [
    { level: 1, moveId: 'ataque_rapido' },
    { level: 1, moveId: 'malicioso' },
    { level: 34, moveId: 'impactrueno' },
    { level: 37, moveId: 'chirrido' },
    { level: 42, moveId: 'puno_trueno' },
    { level: 49, moveId: 'pantalla_luz' },
    { level: 54, moveId: 'trueno' },
  ],

  // Magmar
  126: [
    { level: 1, moveId: 'ascuas' },
    { level: 36, moveId: 'malicioso' },
    { level: 39, moveId: 'confusion' },
    { level: 43, moveId: 'puno_fuego' },
    { level: 48, moveId: 'pantalla_humo' },
    { level: 52, moveId: 'lanzallamas' },
    { level: 55, moveId: 'llamarada' },
  ],

  // Pinsir
  127: [
    { level: 1, moveId: 'malicioso' },
    { level: 1, moveId: 'tenaza' },
    { level: 21, moveId: 'movimiento_sismico' },
    { level: 25, moveId: 'guillotina' },
    { level: 30, moveId: 'foco_energia' },
    { level: 36, moveId: 'sumision' },
    { level: 43, moveId: 'cuchillada' },
    { level: 49, moveId: 'danza_espada' },
  ],

  // Tauros
  128: [
    { level: 1, moveId: 'placaje' },
    { level: 21, moveId: 'pisoton' },
    { level: 28, moveId: 'latigo' },
    { level: 35, moveId: 'malicioso' },
    { level: 44, moveId: 'furia' },
    { level: 51, moveId: 'derribo' },
  ],

  // Magikarp line
  129: [
    { level: 1, moveId: 'placaje' },
    { level: 15, moveId: 'placaje' },
  ],
  130: [
    { level: 1, moveId: 'mordisco' },
    { level: 20, moveId: 'furia_dragon' },
    { level: 25, moveId: 'malicioso' },
    { level: 32, moveId: 'hidrobomba' },
    { level: 41, moveId: 'hiperrayo' },
  ],

  // Lapras
  131: [
    { level: 1, moveId: 'pistola_agua' },
    { level: 1, moveId: 'grunido' },
    { level: 16, moveId: 'canto' },
    { level: 20, moveId: 'niebla' },
    { level: 25, moveId: 'golpe_cuerpo' },
    { level: 31, moveId: 'rayo_confuso' },
    { level: 38, moveId: 'rayo_hielo' },
    { level: 46, moveId: 'hidrobomba' },
  ],

  // Ditto
  132: [
    { level: 1, moveId: 'placaje' },
  ],

  // Eevee line
  133: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'latigo' },
    { level: 8, moveId: 'ataque_arena' },
    { level: 16, moveId: 'ataque_rapido' },
    { level: 23, moveId: 'mordisco' },
    { level: 30, moveId: 'foco_energia' },
    { level: 36, moveId: 'derribo' },
  ],
  134: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'latigo' },
    { level: 8, moveId: 'ataque_arena' },
    { level: 16, moveId: 'pistola_agua' },
    { level: 23, moveId: 'mordisco' },
    { level: 30, moveId: 'armadura_acida' },
    { level: 42, moveId: 'hidrobomba' },
  ],
  135: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'latigo' },
    { level: 8, moveId: 'ataque_arena' },
    { level: 16, moveId: 'impactrueno' },
    { level: 23, moveId: 'ataque_rapido' },
    { level: 30, moveId: 'onda_trueno' },
    { level: 42, moveId: 'pin_misil' },
  ],
  136: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'latigo' },
    { level: 8, moveId: 'ataque_arena' },
    { level: 16, moveId: 'ascuas' },
    { level: 23, moveId: 'ataque_rapido' },
    { level: 30, moveId: 'mordisco' },
    { level: 42, moveId: 'lanzallamas' },
  ],

  // Porygon
  137: [
    { level: 1, moveId: 'placaje' },
    { level: 1, moveId: 'conversion' },
    { level: 23, moveId: 'psicorrayo' },
    { level: 28, moveId: 'recuperacion' },
    { level: 35, moveId: 'agilidad' },
    { level: 42, moveId: 'triataque' },
  ],

  // Omanyte line
  138: [
    { level: 1, moveId: 'pistola_agua' },
    { level: 1, moveId: 'refugio' },
    { level: 34, moveId: 'cornada' },
    { level: 39, moveId: 'malicioso' },
    { level: 46, moveId: 'pisoton' },
    { level: 53, moveId: 'hidrobomba' },
  ],
  139: [
    { level: 1, moveId: 'pistola_agua' },
    { level: 1, moveId: 'refugio' },
    { level: 34, moveId: 'cornada' },
    { level: 39, moveId: 'malicioso' },
    { level: 44, moveId: 'pisoton' },
    { level: 54, moveId: 'hidrobomba' },
  ],

  // Kabuto line
  140: [
    { level: 1, moveId: 'aranazo' },
    { level: 1, moveId: 'fortaleza' },
    { level: 34, moveId: 'absorber' },
    { level: 39, moveId: 'cuchillada' },
    { level: 44, moveId: 'malicioso' },
    { level: 49, moveId: 'hidrobomba' },
  ],
  141: [
    { level: 1, moveId: 'aranazo' },
    { level: 1, moveId: 'fortaleza' },
    { level: 34, moveId: 'absorber' },
    { level: 39, moveId: 'cuchillada' },
    { level: 46, moveId: 'malicioso' },
    { level: 53, moveId: 'hidrobomba' },
  ],

  // Aerodactyl
  142: [
    { level: 1, moveId: 'ataque_ala' },
    { level: 1, moveId: 'agilidad' },
    { level: 33, moveId: 'supersonico' },
    { level: 38, moveId: 'mordisco' },
    { level: 45, moveId: 'derribo' },
    { level: 54, moveId: 'hiperrayo' },
  ],

  // Snorlax
  143: [
    { level: 1, moveId: 'golpe_cabeza' },
    { level: 1, moveId: 'amnesia' },
    { level: 1, moveId: 'descanso' },
    { level: 35, moveId: 'golpe_cuerpo' },
    { level: 41, moveId: 'fortaleza' },
    { level: 48, moveId: 'doble_filo' },
    { level: 56, moveId: 'hiperrayo' },
  ],

  // Articuno
  144: [
    { level: 1, moveId: 'tornado' },
    { level: 1, moveId: 'niebla' },
    { level: 51, moveId: 'ventisca' },
    { level: 55, moveId: 'agilidad' },
    { level: 60, moveId: 'rayo_hielo' },
  ],

  // Zapdos
  145: [
    { level: 1, moveId: 'impactrueno' },
    { level: 1, moveId: 'pico_taladro' },
    { level: 51, moveId: 'trueno' },
    { level: 55, moveId: 'agilidad' },
    { level: 60, moveId: 'rayo' },
  ],

  // Moltres
  146: [
    { level: 1, moveId: 'ataque_ala' },
    { level: 1, moveId: 'ascuas' },
    { level: 51, moveId: 'llamarada' },
    { level: 55, moveId: 'agilidad' },
    { level: 60, moveId: 'lanzallamas' },
  ],

  // Dratini line
  147: [
    { level: 1, moveId: 'atadura' },
    { level: 1, moveId: 'malicioso' },
    { level: 10, moveId: 'onda_trueno' },
    { level: 20, moveId: 'agilidad' },
    { level: 30, moveId: 'portazo' },
    { level: 40, moveId: 'furia_dragon' },
    { level: 50, moveId: 'hiperrayo' },
  ],
  148: [
    { level: 1, moveId: 'atadura' },
    { level: 1, moveId: 'malicioso' },
    { level: 10, moveId: 'onda_trueno' },
    { level: 20, moveId: 'agilidad' },
    { level: 35, moveId: 'portazo' },
    { level: 45, moveId: 'furia_dragon' },
    { level: 55, moveId: 'hiperrayo' },
  ],
  149: [
    { level: 1, moveId: 'atadura' },
    { level: 1, moveId: 'malicioso' },
    { level: 10, moveId: 'onda_trueno' },
    { level: 20, moveId: 'agilidad' },
    { level: 35, moveId: 'portazo' },
    { level: 45, moveId: 'furia_dragon' },
    { level: 60, moveId: 'hiperrayo' },
  ],

  // Mewtwo
  150: [
    { level: 1, moveId: 'confusion' },
    { level: 1, moveId: 'desactivacion' },
    { level: 63, moveId: 'barrera' },
    { level: 66, moveId: 'psicorrayo' },
    { level: 70, moveId: 'recuperacion' },
    { level: 75, moveId: 'amnesia' },
    { level: 81, moveId: 'psiquico' },
  ],

  // Mew
  151: [
    { level: 1, moveId: 'destructor' },
    { level: 10, moveId: 'transformacion' },
    { level: 20, moveId: 'megaagotar' },
    { level: 30, moveId: 'metronomo' },
    { level: 40, moveId: 'psiquico' },
    { level: 50, moveId: 'barrera' },
  ],
};

/**
 * Retorna todos los movimientos que una especie desbloquea a un determinado nivel.
 * Si algún movimiento referenciado no está en MOVES_DATA, se ignora de forma segura.
 */
export function getUnlockedMovesForSpecies(speciesId: number, level: number): LevelUpMove[] {
  const learnset = SPECIES_LEARNSETS[speciesId] || [];
  return learnset.filter((m) => m.level <= level && Boolean(MOVES_DATA[m.moveId]));
}

/**
 * Retorna los hasta 4 movimientos por defecto equipados para una especie a su nivel actual.
 * Elige los más recientes aprendidos por nivel (hasta 4).
 */
export function getDefaultEquippedMoves(speciesId: number, level: number): string[] {
  const unlocked = getUnlockedMovesForSpecies(speciesId, level);
  if (unlocked.length === 0) {
    return ['placaje'];
  }

  // Filtrar duplicados de IDs de movimiento quedándonos con los últimos
  const seen = new Set<string>();
  const reversedUnique: string[] = [];

  for (let i = unlocked.length - 1; i >= 0; i--) {
    const moveId = unlocked[i].moveId;
    if (!seen.has(moveId)) {
      seen.add(moveId);
      reversedUnique.push(moveId);
      if (reversedUnique.length >= 4) break;
    }
  }

  // Invertir para que queden en orden natural de aprendizaje
  return reversedUnique.reverse();
}

/**
 * Valida y sanea un conjunto de movimientos equipados:
 * - Máximo 4 ranuras.
 * - Sin duplicados.
 * - Deben ser movimientos válidos y realmente desbloqueados por la especie a ese nivel.
 */
export function sanitizeEquippedMoves(speciesId: number, level: number, moves?: string[], taughtMoves: string[] = []): string[] {
  const unlocked = getUnlockedMovesForSpecies(speciesId, level);
  const unlockedSet = new Set(unlocked.map((m) => m.moveId));
  taughtMoves.filter(id => MOVES_DATA[id]).forEach(id => unlockedSet.add(id));

  if (!Array.isArray(moves) || moves.length === 0) {
    return getDefaultEquippedMoves(speciesId, level);
  }

  const validMoves: string[] = [];
  for (const m of moves) {
    if (unlockedSet.has(m) && !validMoves.includes(m) && MOVES_DATA[m]) {
      validMoves.push(m);
      if (validMoves.length >= 4) break;
    }
  }

  if (validMoves.length === 0) {
    return getDefaultEquippedMoves(speciesId, level);
  }

  return validMoves;
}
