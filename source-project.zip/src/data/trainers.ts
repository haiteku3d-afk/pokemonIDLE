import { GameSave } from '../types/pokemon';
import { KANTO_GYMS } from './gymsAndMissions';

export type TrainerDifficulty = 'normal' | 'experto' | 'elite';

export interface TrainerPokemon {
  speciesId: number;
  level: number;
  name: string;
}

export interface TrainerRival {
  id: string;
  name: string;
  title: string;
  location: string;
  difficulty: TrainerDifficulty;
  rewardTokens: number; // 10 normal, 20 experto, 35 elite
  challengeLevel: number; // Nivel igualado para el combate
  unlockRequirementText: string;
  isUnlocked: (save: GameSave) => boolean;
  team: TrainerPokemon[];
  dialogue: {
    intro: string;
    defeat: string;
  };
}

export const KANTO_TRAINERS: TrainerRival[] = [
  // --- DIFICULTAD NORMAL (10 FICHAS) ---
  {
    id: 'trainer_joey',
    name: 'Joven Chano',
    title: 'Entrenador Novato',
    location: 'Ciudad Plateada',
    difficulty: 'normal',
    rewardTokens: 10,
    challengeLevel: 12,
    unlockRequirementText: 'Llega a Ciudad Plateada (desbloquea Ruta 2)',
    isUnlocked: (save) => save.unlockedZones.includes('route-2') || save.unlockedZones.includes('pewter-city') || save.badges.includes('boulder'),
    team: [
      { speciesId: 19, level: 12, name: 'Rattata' },
      { speciesId: 16, level: 12, name: 'Pidgey' },
    ],
    dialogue: {
      intro: '¡Mi Rattata está en el percentil superior de todos los Pokémon!',
      defeat: '¡Vaya, tu equipo está muy bien entrenado!',
    },
  },
  {
    id: 'trainer_sammy',
    name: 'Cazabichos Sam',
    title: 'Coleccionista de Insectos',
    location: 'Bosque Verde / Ruta 3',
    difficulty: 'normal',
    rewardTokens: 10,
    challengeLevel: 14,
    unlockRequirementText: 'Derrota a Brock (Medalla Roca)',
    isUnlocked: (save) => save.badges.includes('boulder'),
    team: [
      { speciesId: 12, level: 14, name: 'Butterfree' },
      { speciesId: 15, level: 14, name: 'Beedrill' },
      { speciesId: 46, level: 14, name: 'Paras' },
    ],
    dialogue: {
      intro: '¡Mis Pokémon bicho están completamente desarrollados y listos para picar!',
      defeat: '¡Mis bichos cayeron! Necesito investigar más sobre tipos...',
    },
  },
  {
    id: 'trainer_lass_sara',
    name: 'Chica Sara',
    title: 'Entrenadora de Ruta',
    location: 'Ruta 4 / Ciudad Celeste',
    difficulty: 'normal',
    rewardTokens: 10,
    challengeLevel: 18,
    unlockRequirementText: 'Desbloquea la Ruta 4 o Ciudad Celeste',
    isUnlocked: (save) => save.unlockedZones.includes('route-4') || save.unlockedZones.includes('cerulean-city') || save.badges.includes('cascade'),
    team: [
      { speciesId: 35, level: 18, name: 'Clefairy' },
      { speciesId: 30, level: 18, name: 'Nidorina' },
      { speciesId: 69, level: 18, name: 'Bellsprout' },
    ],
    dialogue: {
      intro: '¡No subestimes la ternura de mis Pokémon en combate!',
      defeat: '¡Qué fuerza! Tienes madera de gran campeón.',
    },
  },
  {
    id: 'trainer_sailor_bob',
    name: 'Marinero Bob',
    title: 'Lobo de Mar',
    location: 'Ciudad Carmín (Muelle)',
    difficulty: 'normal',
    rewardTokens: 10,
    challengeLevel: 22,
    unlockRequirementText: 'Desbloquea Ciudad Carmín / Ruta 6',
    isUnlocked: (save) => save.unlockedZones.includes('vermilion-city') || save.unlockedZones.includes('route-6') || save.badges.includes('thunder'),
    team: [
      { speciesId: 66, level: 22, name: 'Machop' },
      { speciesId: 61, level: 22, name: 'Poliwhirl' },
      { speciesId: 72, level: 22, name: 'Tentacool' },
    ],
    dialogue: {
      intro: '¡Surqué los siete mares y mis Pokémon no le temen a ninguna tempestad!',
      defeat: '¡Me has mandado a pique con un torbellino!',
    },
  },

  // --- DIFICULTAD EXPERTO (20 FICHAS) ---
  {
    id: 'trainer_mechanic_miguel',
    name: 'Mecánico Miguel',
    title: 'Especialista en Voltios',
    location: 'Ruta 9 / Central de Energía',
    difficulty: 'experto',
    rewardTokens: 20,
    challengeLevel: 28,
    unlockRequirementText: 'Derrota a Lt. Surge (Medalla Trueno)',
    isUnlocked: (save) => save.badges.includes('thunder'),
    team: [
      { speciesId: 82, level: 28, name: 'Magneton' },
      { speciesId: 100, level: 28, name: 'Voltorb' },
      { speciesId: 125, level: 28, name: 'Electabuzz' },
    ],
    dialogue: {
      intro: '¡Mis circuitos están calibrados a máxima potencia de descarga!',
      defeat: '¡Cortocircuito total! Mis máquinas no pudieron con tu estrategia.',
    },
  },
  {
    id: 'trainer_psychic_rebeca',
    name: 'Médium Rebeca',
    title: 'Canalizadora Psíquica',
    location: 'Torre Pokémon / Pueblo Lavanda',
    difficulty: 'experto',
    rewardTokens: 20,
    challengeLevel: 38,
    unlockRequirementText: 'Derrota a Erika (Medalla Arcoíris)',
    isUnlocked: (save) => save.badges.includes('rainbow'),
    team: [
      { speciesId: 64, level: 38, name: 'Kadabra' },
      { speciesId: 96, level: 38, name: 'Drowzee' },
      { speciesId: 122, level: 38, name: 'Mr. Mime' },
    ],
    dialogue: {
      intro: 'Ya vi el futuro de este combate en mi bola de cristal...',
      defeat: '¡Imposible! Has roto mi percepción telepática.',
    },
  },
  {
    id: 'trainer_blackbelt_ken',
    name: 'Karateka Ken',
    title: 'Maestro del Dojo Kanto',
    location: 'Ciudad Azafrán (Dojo)',
    difficulty: 'experto',
    rewardTokens: 20,
    challengeLevel: 42,
    unlockRequirementText: 'Derrota a Koga (Medalla Alma)',
    isUnlocked: (save) => save.badges.includes('soul'),
    team: [
      { speciesId: 106, level: 42, name: 'Hitmonlee' },
      { speciesId: 107, level: 42, name: 'Hitmonchan' },
      { speciesId: 57, level: 42, name: 'Primeape' },
    ],
    dialogue: {
      intro: '¡Kiai! ¡El espíritu del entrenamiento físico vence a cualquier adversario!',
      defeat: '¡Impresionante golpe! Reconozco tu superioridad marcial.',
    },
  },
  {
    id: 'trainer_scientist_travis',
    name: 'Científico Travis',
    title: 'Investigador de Silph S.A.',
    location: 'Edificio Silph S.A.',
    difficulty: 'experto',
    rewardTokens: 20,
    challengeLevel: 46,
    unlockRequirementText: 'Derrota a Sabrina (Medalla Pantano)',
    isUnlocked: (save) => save.badges.includes('marsh'),
    team: [
      { speciesId: 89, level: 46, name: 'Muk' },
      { speciesId: 110, level: 46, name: 'Weezing' },
      { speciesId: 137, level: 46, name: 'Porygon' },
    ],
    dialogue: {
      intro: 'La ciencia y los experimentos de Silph superarán a cualquier Pokémon salvaje.',
      defeat: 'Mis datos no contemplaban este resultado tan desfavorable...',
    },
  },

  // --- DIFICULTAD ÉLITE (35 FICHAS) ---
  {
    id: 'trainer_ace_axel',
    name: 'Entrenador Guay Axel',
    title: 'As de la Ruta 21',
    location: 'Ruta 21 / Isla Canela',
    difficulty: 'elite',
    rewardTokens: 35,
    challengeLevel: 50,
    unlockRequirementText: 'Derrota a Blaine (Medalla Volcán)',
    isUnlocked: (save) => save.badges.includes('volcano'),
    team: [
      { speciesId: 130, level: 50, name: 'Gyarados' },
      { speciesId: 59, level: 50, name: 'Arcanine' },
      { speciesId: 103, level: 50, name: 'Exeggutor' },
    ],
    dialogue: {
      intro: 'He recorrido todas las islas de Kanto. Solo los mejores llegan hasta mí.',
      defeat: '¡Qué combate tan épico! Te mereces cada una de estas fichas.',
    },
  },
  {
    id: 'trainer_rival_green',
    name: 'Rival Verde',
    title: 'Aspirante al Título',
    location: 'Ruta 22 / Meseta Añil',
    difficulty: 'elite',
    rewardTokens: 35,
    challengeLevel: 60,
    unlockRequirementText: 'Derrota a Giovanni (Medalla Tierra)',
    isUnlocked: (save) => save.badges.includes('earth'),
    team: [
      { speciesId: 18, level: 60, name: 'Pidgeot' },
      { speciesId: 65, level: 60, name: 'Alakazam' },
      { speciesId: 112, level: 60, name: 'Rhydon' },
      { speciesId: 9, level: 60, name: 'Blastoise' },
    ],
    dialogue: {
      intro: '¡Ja! ¿Crees que puedes superarme antes de la Liga Pokémon? ¡Demuéstramelo!',
      defeat: '¡Maldición! Todavía tengo que perfeccionar mi equipo... ¡Nos vemos en la Liga!',
    },
  },
];

// Resistencia: una cadena continua, sin curaciones ni cambios de equipo entre rivales.
for (const [id, name, badge, level, count, reward] of [
  ['endurance_forest', 'Resistencia del Bosque', 'boulder', 14, 10, 30],
  ['endurance_kanto', 'Resistencia de Kanto', 'rainbow', 43, 20, 60],
] as const) {
  const pool = id === 'endurance_forest' ? [16, 19, 12, 15, 25] : [26, 67, 93, 64, 75, 61, 44];
  KANTO_TRAINERS.push({ id, name, title: `${count} rivales sin curación`, location: 'Club de Resistencia', difficulty: 'elite', rewardTokens: reward, challengeLevel: level, unlockRequirementText: `Requiere la medalla ${badge}`, isUnlocked: save => save.badges.includes(badge), team: Array.from({ length: count }, (_, i) => ({ speciesId: pool[i % pool.length], level, name: `Rival ${i + 1}` })), dialogue: { intro: 'Tu equipo conserva la vida entre rivales. Una derrota termina el intento; abandonar reinicia la cadena.', defeat: '¡Has resistido toda la cadena!' } });
}

// Revanchas de líderes y Liga: conservan IV, ataques y objetos; nivel igualado.
KANTO_GYMS.forEach(gym => {
  const isLeague = gym.id === 'pokemon_league';
  KANTO_TRAINERS.push({ id: `rematch_${gym.id}`, name: `Revancha: ${gym.name}`, title: isLeague ? 'Liga de Campeones' : 'Líder de Kanto', location: gym.city, difficulty: 'elite', rewardTokens: isLeague ? 100 : 35, challengeLevel: isLeague ? 75 : Math.max(...gym.team.map(p => p.level)), unlockRequirementText: isLeague ? 'Requiere superar la Liga' : `Requiere derrotar a ${gym.name}`, isUnlocked: save => save.defeatedGyms.includes(gym.id), team: gym.team, dialogue: { intro: '¡Volvamos a medir tu estrategia!', defeat: '¡Una victoria digna de una revancha!' } });
});
