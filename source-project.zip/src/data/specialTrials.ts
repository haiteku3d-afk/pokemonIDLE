import { GameSave } from '../types/pokemon';
import { ZONES_BY_ID } from './zones';
import { POKEMON_BY_ID } from './pokemon151';
import { getLevelCap } from '../utils/levelCaps';

export interface TrialRivalStage {
  speciesId: number;
  level: number;
  name: string;
}

export interface SpecialTrial {
  zoneId?: string;
  id: 'double_trial' | 'triple_trial';
  title: string;
  subtitle: string;
  description: string;
  rewardText: string;
  requiredBadge: string;
  badgeName: string;
  challengeLevel: number;
  targetStreak: number;
  laneCount: 1 | 2;
  requiresTrialId?: 'double_trial';
  isUnlocked: (save: GameSave) => boolean;
  isCompleted: (save: GameSave) => boolean;
  poolRivals: TrialRivalStage[];
}

export function getRouteTrials(zoneId: string, save: GameSave): SpecialTrial[] {
  const zone = ZONES_BY_ID[zoneId];
  if (!zone) return [];
  const completed = (state: GameSave) => state.unlockedZones.includes(zoneId) && (state.zoneVictories[zoneId] || 0) >= (zone.requiredVictories || 30);
  const level = Math.min(getLevelCap(save.badges).cap, Math.max(14, ...zone.encounterTable.map(p => p.maxLevel)));
  return SPECIAL_TRIALS.map(trial => ({ ...trial, zoneId,
    title: `${zone.name} · ${trial.id === 'double_trial' ? 'Reto doble' : 'Reto triple'}`,
    subtitle: `${trial.targetStreak} victorias sin bajas · niveles igualados`,
    description: `Supera ${trial.targetStreak} victorias en ${trial.laneCount} carril(es) a nivel ${level} sin ninguna baja. Solo desbloquea este modo en ${zone.name}.`,
    rewardText: `${trial.id === 'double_trial' ? 'Doble' : 'Triple'} permanente en ${zone.name}.`,
    challengeLevel: level,
    isUnlocked: state => completed(state) && state.badges.includes(trial.requiredBadge) && (trial.id === 'double_trial' || !!state.routeBattleUnlocks?.[zoneId]?.double),
    isCompleted: state => !!state.routeBattleUnlocks?.[zoneId]?.[trial.id === 'double_trial' ? 'double' : 'triple'],
    poolRivals: zone.encounterTable.map(p => ({ speciesId: p.speciesId, level, name: POKEMON_BY_ID[p.speciesId].name })),
  }));
}

export const SPECIAL_TRIALS: SpecialTrial[] = [
  {
    id: 'double_trial',
    title: 'Reto de Combate Doble (Racha de 10)',
    subtitle: 'Prueba de resistencia individual sin bajas tras Medalla Roca',
    description:
      'Supera 10 victorias consecutivas a Nivel Igualado 14 en combate individual contra rivales preparados sin que ningún Pokémon de tu equipo caiga debilitado. Si algún Pokémon cae (incluso por daño residual de veneno o quemadura), el intento fracasa y la racha vuelve a 0.',
    rewardText: 'Desbloqueo permanente del Modo Combate Doble (2 carriles simultáneos) en rutas completadas.',
    requiredBadge: 'boulder',
    badgeName: 'Medalla Roca (Brock)',
    challengeLevel: 14,
    targetStreak: 10,
    laneCount: 1,
    isUnlocked: (save) => save.badges.includes('boulder'),
    isCompleted: (save) => save.unlockedDoubleBattle || save.completedTrials?.includes('double_trial'),
    poolRivals: [
      { speciesId: 19, level: 14, name: 'Rattata de Élite' },
      { speciesId: 16, level: 14, name: 'Pidgey Cazador' },
      { speciesId: 12, level: 14, name: 'Butterfree Ágil' },
      { speciesId: 15, level: 14, name: 'Beedrill Feroz' },
      { speciesId: 21, level: 14, name: 'Spearow Agresivo' },
      { speciesId: 27, level: 14, name: 'Sandshrew Defensivo' },
      { speciesId: 41, level: 14, name: 'Zubat Nocturno' },
      { speciesId: 74, level: 14, name: 'Geodude Firme' },
      { speciesId: 56, level: 14, name: 'Mankey Rabioso' },
      { speciesId: 25, level: 14, name: 'Pikachu Chispeante' },
    ],
  },
  {
    id: 'triple_trial',
    title: 'Reto de Combate Triple (Racha de 20 en 2 Carriles)',
    subtitle: 'Prueba de coordinación táctica tras Medalla Trueno',
    description:
      'Supera 20 victorias acumuladas en 2 carriles simultáneos a Nivel Igualado 29 contra rivales preparados sin que ningún miembro caiga debilitado. Si cualquier Pokémon cae en cualquiera de los dos carriles, el intento fracasa y la racha vuelve a 0.',
    rewardText: 'Desbloqueo permanente del Modo Combate Triple (3 carriles simultáneos) en rutas completadas.',
    requiredBadge: 'thunder',
    badgeName: 'Medalla Trueno (Lt. Surge)',
    requiresTrialId: 'double_trial',
    challengeLevel: 29,
    targetStreak: 20,
    laneCount: 2,
    isUnlocked: (save) =>
      save.badges.includes('thunder') && (save.unlockedDoubleBattle || save.completedTrials?.includes('double_trial')),
    isCompleted: (save) => save.unlockedTripleBattle || save.completedTrials?.includes('triple_trial'),
    poolRivals: [
      { speciesId: 26, level: 29, name: 'Raichu Eléctrico' },
      { speciesId: 100, level: 29, name: 'Voltorb Veloz' },
      { speciesId: 82, level: 29, name: 'Magneton Blindado' },
      { speciesId: 125, level: 29, name: 'Electabuzz Temible' },
      { speciesId: 57, level: 29, name: 'Primeape Fuerte' },
      { speciesId: 67, level: 29, name: 'Machoke Firme' },
      { speciesId: 61, level: 29, name: 'Poliwhirl Acuático' },
      { speciesId: 75, level: 29, name: 'Graveler Ricoso' },
      { speciesId: 64, level: 29, name: 'Kadabra Telepático' },
      { speciesId: 93, level: 29, name: 'Haunter Espectral' },
      { speciesId: 44, level: 29, name: 'Gloom Tóxico' },
      { speciesId: 59, level: 29, name: 'Arcanine Flamígero' },
    ],
  },
];
