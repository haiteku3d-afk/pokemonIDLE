import { ShopItem } from '../types/items';

export type { ShopItem };

export const SHOP_ITEMS: ShopItem[] = [
  // Piedras Evolutivas (40 Fichas cada una, disponibles tras derrotar a Brock)
  {
    id: 'piedra_fuego',
    name: 'Piedra Fuego',
    category: 'evolution',
    cost: 40,
    description: 'Piedra evolutiva rojiza impregnada del calor volcánico.',
    effectText: 'Evoluciona a Vulpix, Growlithe o Eevee (Flareon).',
    requiredBadge: 'boulder',
    badgeName: 'Medalla Roca (Brock)',
    evolutionTarget: { stone: 'fire' },
  },
  {
    id: 'piedra_agua',
    name: 'Piedra Agua',
    category: 'evolution',
    cost: 40,
    description: 'Piedra de un azul translúcido con gotas en su interior.',
    effectText: 'Evoluciona a Poliwhirl, Shellder, Staryu o Eevee (Vaporeon).',
    requiredBadge: 'boulder',
    badgeName: 'Medalla Roca (Brock)',
    evolutionTarget: { stone: 'water' },
  },
  {
    id: 'piedra_trueno',
    name: 'Piedra Trueno',
    category: 'evolution',
    cost: 40,
    description: 'Piedra brillante que emite chispas eléctricas continuas.',
    effectText: 'Evoluciona a Pikachu o Eevee (Jolteon).',
    requiredBadge: 'boulder',
    badgeName: 'Medalla Roca (Brock)',
    evolutionTarget: { stone: 'thunder' },
  },
  {
    id: 'piedra_hoja',
    name: 'Piedra Hoja',
    category: 'evolution',
    cost: 40,
    description: 'Piedra misteriosa con la impronta de una hoja en su centro.',
    effectText: 'Evoluciona a Gloom, Weepinbell o Exeggcute.',
    requiredBadge: 'boulder',
    badgeName: 'Medalla Roca (Brock)',
    evolutionTarget: { stone: 'leaf' },
  },
  {
    id: 'piedra_lunar',
    name: 'Piedra Lunar',
    category: 'evolution',
    cost: 40,
    description: 'Piedra negra oscura que brilla tenuemente bajo la noche.',
    effectText: 'Evoluciona a Nidorina, Nidorino, Clefairy o Jigglypuff.',
    requiredBadge: 'boulder',
    badgeName: 'Medalla Roca (Brock)',
    evolutionTarget: { stone: 'moon' },
  },

  // Cable Link (50 Fichas, evolución de intercambio, tras Brock)
  {
    id: 'cable_link',
    name: 'Cable Link',
    category: 'evolution',
    cost: 50,
    description: 'Dispositivo retro de enlace que emula un intercambio Pokémon auténtico.',
    effectText: 'Evoluciona a Kadabra (Alakazam), Machoke (Machamp), Graveler (Golem) y Haunter (Gengar).',
    requiredBadge: 'boulder',
    badgeName: 'Medalla Roca (Brock)',
    evolutionTarget: { item: 'cable_link' },
  },

  // Objetos de Combate Básicos (150 Fichas cada uno, disponibles tras derrotar a Misty)
  {
    id: 'cinta_fuerza',
    name: 'Cinta Fuerza',
    category: 'combat',
    cost: 150,
    description: 'Cinta que infunde vigor y concentración muscular en el combate.',
    effectText: '+10% de daño en todos los ataques físicos ejecutados por el portador.',
    requiredBadge: 'cascade',
    badgeName: 'Medalla Cascada (Misty)',
    combatModifier: {
      type: 'physical_attack',
      value: 0.10,
    },
  },
  {
    id: 'gafas_sabias',
    name: 'Gafas Sabias',
    category: 'combat',
    cost: 150,
    description: 'Lentes que aumentan la agudeza mental y canalizan la energía elemental.',
    effectText: '+10% de daño en todos los ataques especiales ejecutados por el portador.',
    requiredBadge: 'cascade',
    badgeName: 'Medalla Cascada (Misty)',
    combatModifier: {
      type: 'special_attack',
      value: 0.10,
    },
  },

  // Objeto de Combate Avanzado (300 Fichas, disponible tras derrotar a Erika)
  {
    id: 'chaleco_defensa',
    name: 'Chaleco Protector',
    category: 'combat',
    cost: 300,
    description: 'Chaleco acolchado de aleación reforzada que absorbe impactos contundentes.',
    effectText: '-10% de reducción en todo daño directo recibido por el portador.',
    requiredBadge: 'rainbow',
    badgeName: 'Medalla Arcoíris (Erika)',
    combatModifier: {
      type: 'damage_reduction',
      value: 0.10,
    },
  },
];

export const SHOP_ITEMS_BY_ID: Record<string, ShopItem> = SHOP_ITEMS.reduce((acc, item) => {
  acc[item.id] = item;
  return acc;
}, {} as Record<string, ShopItem>);

/**
 * Determina qué evolución por objeto/piedra corresponde a una especie
 */
export interface AvailableItemEvolution {
  targetSpeciesId: number;
  requiredItemId: string;
  itemName: string;
}

export function getAvailableItemEvolutions(speciesId: number): AvailableItemEvolution[] {
  // Caso especial: Eevee tiene 3 ramas en Gen 1
  if (speciesId === 133) {
    return [
      { targetSpeciesId: 134, requiredItemId: 'piedra_agua', itemName: 'Piedra Agua' },
      { targetSpeciesId: 135, requiredItemId: 'piedra_trueno', itemName: 'Piedra Trueno' },
      { targetSpeciesId: 136, requiredItemId: 'piedra_fuego', itemName: 'Piedra Fuego' },
    ];
  }

  // Cable Link (Intercambio en 1ra Generación)
  if (speciesId === 64) return [{ targetSpeciesId: 65, requiredItemId: 'cable_link', itemName: 'Cable Link' }]; // Kadabra -> Alakazam
  if (speciesId === 67) return [{ targetSpeciesId: 68, requiredItemId: 'cable_link', itemName: 'Cable Link' }]; // Machoke -> Machamp
  if (speciesId === 75) return [{ targetSpeciesId: 76, requiredItemId: 'cable_link', itemName: 'Cable Link' }]; // Graveler -> Golem
  if (speciesId === 93) return [{ targetSpeciesId: 94, requiredItemId: 'cable_link', itemName: 'Cable Link' }]; // Haunter -> Gengar

  // Piedra Trueno
  if (speciesId === 25) return [{ targetSpeciesId: 26, requiredItemId: 'piedra_trueno', itemName: 'Piedra Trueno' }]; // Pikachu -> Raichu

  // Piedra Lunar
  if (speciesId === 30) return [{ targetSpeciesId: 31, requiredItemId: 'piedra_lunar', itemName: 'Piedra Lunar' }]; // Nidorina -> Nidoqueen
  if (speciesId === 33) return [{ targetSpeciesId: 34, requiredItemId: 'piedra_lunar', itemName: 'Piedra Lunar' }]; // Nidorino -> Nidoking
  if (speciesId === 35) return [{ targetSpeciesId: 36, requiredItemId: 'piedra_lunar', itemName: 'Piedra Lunar' }]; // Clefairy -> Clefable
  if (speciesId === 39) return [{ targetSpeciesId: 40, requiredItemId: 'piedra_lunar', itemName: 'Piedra Lunar' }]; // Jigglypuff -> Wigglytuff

  // Piedra Fuego
  if (speciesId === 37) return [{ targetSpeciesId: 38, requiredItemId: 'piedra_fuego', itemName: 'Piedra Fuego' }]; // Vulpix -> Ninetales
  if (speciesId === 58) return [{ targetSpeciesId: 59, requiredItemId: 'piedra_fuego', itemName: 'Piedra Fuego' }]; // Growlithe -> Arcanine

  // Piedra Hoja
  if (speciesId === 44) return [{ targetSpeciesId: 45, requiredItemId: 'piedra_hoja', itemName: 'Piedra Hoja' }]; // Gloom -> Vileplume
  if (speciesId === 70) return [{ targetSpeciesId: 71, requiredItemId: 'piedra_hoja', itemName: 'Piedra Hoja' }]; // Weepinbell -> Victreebel
  if (speciesId === 102) return [{ targetSpeciesId: 103, requiredItemId: 'piedra_hoja', itemName: 'Piedra Hoja' }]; // Exeggcute -> Exeggutor

  // Piedra Agua
  if (speciesId === 61) return [{ targetSpeciesId: 62, requiredItemId: 'piedra_agua', itemName: 'Piedra Agua' }]; // Poliwhirl -> Poliwrath
  if (speciesId === 90) return [{ targetSpeciesId: 91, requiredItemId: 'piedra_agua', itemName: 'Piedra Agua' }]; // Shellder -> Cloyster
  if (speciesId === 120) return [{ targetSpeciesId: 121, requiredItemId: 'piedra_agua', itemName: 'Piedra Agua' }]; // Staryu -> Starmie

  return [];
}
