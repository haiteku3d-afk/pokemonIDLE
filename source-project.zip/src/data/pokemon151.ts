import { PokemonSpecies, PokemonType } from '../types/pokemon';

/**
 * Tabla de tipos y colores temáticos retro
 */
export const TYPE_COLORS: Record<PokemonType, { bg: string; text: string; border: string }> = {
  normal: { bg: '#8a8a79', text: '#ffffff', border: '#606050' },
  fuego: { bg: '#d44f33', text: '#ffffff', border: '#9e341f' },
  agua: { bg: '#3a72b8', text: '#ffffff', border: '#254d7d' },
  planta: { bg: '#589b43', text: '#ffffff', border: '#3b6a2c' },
  electrico: { bg: '#d89b25', text: '#1c2e24', border: '#996d16' },
  hielo: { bg: '#56a7a5', text: '#1c2e24', border: '#387372' },
  lucha: { bg: '#913b29', text: '#ffffff', border: '#602417' },
  veneno: { bg: '#863b84', text: '#ffffff', border: '#5a2559' },
  tierra: { bg: '#b28b49', text: '#ffffff', border: '#7a5d2e' },
  volador: { bg: '#7274b8', text: '#ffffff', border: '#4d4f82' },
  psiquico: { bg: '#d8446b', text: '#ffffff', border: '#9b2b49' },
  bicho: { bg: '#7d8e2a', text: '#ffffff', border: '#536018' },
  roca: { bg: '#938343', text: '#ffffff', border: '#63582a' },
  fantasma: { bg: '#5b4a78', text: '#ffffff', border: '#3c3051' },
  dragon: { bg: '#5742a0', text: '#ffffff', border: '#382a69' },
};

/**
 * Tabla de efectividades de tipos de 1ra Generación
 */
export const TYPE_CHART: Record<PokemonType, Partial<Record<PokemonType, number>>> = {
  normal: { roca: 0.5, fantasma: 0 },
  fuego: { fuego: 0.5, agua: 0.5, planta: 2, hielo: 2, bicho: 2, roca: 0.5, dragon: 0.5 },
  agua: { fuego: 2, agua: 0.5, planta: 0.5, tierra: 2, roca: 2, dragon: 0.5 },
  planta: { fuego: 0.5, agua: 2, planta: 0.5, veneno: 0.5, tierra: 2, volador: 0.5, bicho: 0.5, roca: 2, dragon: 0.5 },
  electrico: { agua: 2, electrico: 0.5, planta: 0.5, tierra: 0, volador: 2, dragon: 0.5 },
  hielo: { agua: 0.5, planta: 2, hielo: 0.5, tierra: 2, volador: 2, dragon: 2 },
  lucha: { normal: 2, hielo: 2, veneno: 0.5, volador: 0.5, psiquico: 0.5, bicho: 0.5, roca: 2, fantasma: 0 },
  veneno: { planta: 2, veneno: 0.5, tierra: 0.5, roca: 0.5, fantasma: 0.5, bicho: 2 },
  tierra: { fuego: 2, electrico: 2, planta: 0.5, veneno: 2, volador: 0, bicho: 0.5, roca: 2 },
  volador: { electrico: 0.5, planta: 2, lucha: 2, bicho: 2, roca: 0.5 },
  psiquico: { lucha: 2, veneno: 2, psiquico: 0.5 },
  bicho: { fuego: 0.5, planta: 2, veneno: 2, volador: 0.5, psiquico: 2, fantasma: 0.5 },
  roca: { fuego: 2, hielo: 2, lucha: 0.5, tierra: 0.5, volador: 2, bicho: 2 },
  fantasma: { normal: 0, psiquico: 0, fantasma: 2 },
  dragon: { dragon: 2 },
};

export function getTypeMultiplier(attackType: PokemonType, defenderTypes: PokemonType[]): number {
  let multiplier = 1;
  const attackChart = TYPE_CHART[attackType] || {};
  for (const defType of defenderTypes) {
    if (attackChart[defType] !== undefined) {
      multiplier *= attackChart[defType]!;
    }
  }
  return multiplier;
}

/**
 * Los 151 Pokémon de Kanto con las 6 estadísticas base oficiales:
 * (HP, Ataque, Defensa, Atq. Especial, Def. Especial, Velocidad)
 */
export const POKEMON_151: PokemonSpecies[] = [
  // 1-9 Iniciales
  { id: 1, name: 'Bulbasaur', types: ['planta', 'veneno'], baseStats: { hp: 45, attack: 49, defense: 49, spAtk: 65, spDef: 65, speed: 45 }, evolution: { type: 'level', level: 16, into: 2 }, catchRate: 45, baseExp: 64, description: 'Lleva una semilla en su lomo que crece con él desde su nacimiento.' },
  { id: 2, name: 'Ivysaur', types: ['planta', 'veneno'], baseStats: { hp: 60, attack: 62, defense: 63, spAtk: 80, spDef: 80, speed: 60 }, evolution: { type: 'level', level: 32, into: 3 }, catchRate: 45, baseExp: 142, description: 'El bulbo de su espalda florece cuando absorbe energía del sol.' },
  { id: 3, name: 'Venusaur', types: ['planta', 'veneno'], baseStats: { hp: 80, attack: 82, defense: 83, spAtk: 100, spDef: 100, speed: 80 }, catchRate: 45, baseExp: 236, description: 'La flor de su lomo desprende un aroma embriagador que calma a los demás.' },
  { id: 4, name: 'Charmander', types: ['fuego'], baseStats: { hp: 39, attack: 52, defense: 43, spAtk: 60, spDef: 50, speed: 65 }, evolution: { type: 'level', level: 16, into: 5 }, catchRate: 45, baseExp: 62, description: 'La llama en la punta de su cola indica su vitalidad y estado de ánimo.' },
  { id: 5, name: 'Charmeleon', types: ['fuego'], baseStats: { hp: 58, attack: 64, defense: 58, spAtk: 80, spDef: 65, speed: 80 }, evolution: { type: 'level', level: 36, into: 6 }, catchRate: 45, baseExp: 142, description: 'De temperamento fogoso, agita su cola con fuerza cuando se emociona.' },
  { id: 6, name: 'Charizard', types: ['fuego', 'volador'], baseStats: { hp: 78, attack: 84, defense: 78, spAtk: 109, spDef: 85, speed: 100 }, catchRate: 45, baseExp: 240, description: 'Escupe llamaradas tan calientes que pueden fundir incluso las rocas.' },
  { id: 7, name: 'Squirtle', types: ['agua'], baseStats: { hp: 44, attack: 48, defense: 65, spAtk: 50, spDef: 64, speed: 43 }, evolution: { type: 'level', level: 16, into: 8 }, catchRate: 45, baseExp: 63, description: 'Se resguarda dentro de su caparazón y contraataca disparando chorros de agua.' },
  { id: 8, name: 'Wartortle', types: ['agua'], baseStats: { hp: 59, attack: 63, defense: 80, spAtk: 65, spDef: 80, speed: 58 }, evolution: { type: 'level', level: 36, into: 9 }, catchRate: 45, baseExp: 142, description: 'Su cola esponjosa es símbolo de longevidad y sabiduría entre los ancianos.' },
  { id: 9, name: 'Blastoise', types: ['agua'], baseStats: { hp: 79, attack: 83, defense: 100, spAtk: 85, spDef: 105, speed: 78 }, catchRate: 45, baseExp: 239, description: 'Dispara potentes cañones de agua desde su caparazón con gran precisión.' },

  // 10-15 Bichos tempranos
  { id: 10, name: 'Caterpie', types: ['bicho'], baseStats: { hp: 45, attack: 30, defense: 35, spAtk: 20, spDef: 20, speed: 45 }, evolution: { type: 'level', level: 7, into: 11 }, catchRate: 255, baseExp: 39, description: 'Sus pequeñas patas tienen ventosas que le permiten trepar cualquier superficie.' },
  { id: 11, name: 'Metapod', types: ['bicho'], baseStats: { hp: 50, attack: 20, defense: 55, spAtk: 25, spDef: 25, speed: 30 }, evolution: { type: 'level', level: 10, into: 12 }, catchRate: 120, baseExp: 72, description: 'Endurece su corteza para protegerse mientras su cuerpo interior se transforma.' },
  { id: 12, name: 'Butterfree', types: ['bicho', 'volador'], baseStats: { hp: 60, attack: 45, defense: 50, spAtk: 90, spDef: 80, speed: 70 }, catchRate: 45, baseExp: 178, description: 'Vuela entre las flores recogiendo néctar y liberando esporas somníferas.' },
  { id: 13, name: 'Weedle', types: ['bicho', 'veneno'], baseStats: { hp: 40, attack: 35, defense: 30, spAtk: 20, spDef: 20, speed: 50 }, evolution: { type: 'level', level: 7, into: 14 }, catchRate: 255, baseExp: 39, description: 'Tiene un aguijón afilado y venenoso de 5 cm en la cabeza para protegerse.' },
  { id: 14, name: 'Kakuna', types: ['bicho', 'veneno'], baseStats: { hp: 45, attack: 25, defense: 50, spAtk: 25, spDef: 25, speed: 35 }, evolution: { type: 'level', level: 10, into: 15 }, catchRate: 120, baseExp: 72, description: 'Prácticamente inmóvil, permanece oculto entre los árboles mientras madura.' },
  { id: 15, name: 'Beedrill', types: ['bicho', 'veneno'], baseStats: { hp: 65, attack: 90, defense: 40, spAtk: 45, spDef: 80, speed: 75 }, catchRate: 45, baseExp: 178, description: 'Vuela a toda velocidad y ataca en enjambre con sus tres afilados aguijones.' },

  // 16-18 Aves tempranas
  { id: 16, name: 'Pidgey', types: ['normal', 'volador'], baseStats: { hp: 40, attack: 45, defense: 40, spAtk: 35, spDef: 35, speed: 56 }, evolution: { type: 'level', level: 18, into: 17 }, catchRate: 255, baseExp: 50, description: 'Dócil y común en praderas, levanta nubes de arena con sus alas si lo amenazan.' },
  { id: 17, name: 'Pidgeotto', types: ['normal', 'volador'], baseStats: { hp: 63, attack: 60, defense: 55, spAtk: 50, spDef: 50, speed: 71 }, evolution: { type: 'level', level: 36, into: 18 }, catchRate: 120, baseExp: 122, description: 'Patrulla un amplio territorio desde las alturas con su aguda vista rapaz.' },
  { id: 18, name: 'Pidgeot', types: ['normal', 'volador'], baseStats: { hp: 83, attack: 80, defense: 75, spAtk: 70, spDef: 70, speed: 101 }, catchRate: 45, baseExp: 216, description: 'Vuela majestuoso a velocidad Mach 2 en busca de presas acuáticas.' },

  // 19-20 Roedores
  { id: 19, name: 'Rattata', types: ['normal'], baseStats: { hp: 30, attack: 56, defense: 35, spAtk: 25, spDef: 35, speed: 72 }, evolution: { type: 'level', level: 20, into: 20 }, catchRate: 255, baseExp: 51, description: 'Muy prudente y adaptable, sus incisivos afilados crecen sin detenerse.' },
  { id: 20, name: 'Raticate', types: ['normal'], baseStats: { hp: 55, attack: 81, defense: 60, spAtk: 50, spDef: 70, speed: 97 }, catchRate: 127, baseExp: 145, description: 'Roedor tenaz que puede mordisquear paredes de hormigón con sus colmillos.' },

  // 21-22 Aves rapaces
  { id: 21, name: 'Spearow', types: ['normal', 'volador'], baseStats: { hp: 40, attack: 60, defense: 30, spAtk: 31, spDef: 31, speed: 70 }, evolution: { type: 'level', level: 20, into: 22 }, catchRate: 255, baseExp: 52, description: 'Muy territorial y chillón, defiende su zona volando en círculos rápidos.' },
  { id: 22, name: 'Fearow', types: ['normal', 'volador'], baseStats: { hp: 65, attack: 90, defense: 65, spAtk: 61, spDef: 61, speed: 100 }, catchRate: 90, baseExp: 155, description: 'Con sus inmensas alas puede volar durante días enteros sin tener que aterrizar.' },

  // 23-24 Serpientes
  { id: 23, name: 'Ekans', types: ['veneno'], baseStats: { hp: 35, attack: 60, defense: 44, spAtk: 40, spDef: 54, speed: 55 }, evolution: { type: 'level', level: 22, into: 24 }, catchRate: 255, baseExp: 58, description: 'Se mueve silenciosamente por la hierba para sorprender y engullir huevos enteros.' },
  { id: 24, name: 'Arbok', types: ['veneno'], baseStats: { hp: 60, attack: 85, defense: 69, spAtk: 65, spDef: 79, speed: 80 }, catchRate: 90, baseExp: 157, description: 'El patrón intimidatorio de su vientre paraliza a los rivales antes de constreñirlos.' },

  // 25-26 Eléctricos
  { id: 25, name: 'Pikachu', types: ['electrico'], baseStats: { hp: 35, attack: 55, defense: 40, spAtk: 50, spDef: 50, speed: 90 }, evolution: { type: 'stone', stone: 'thunder', into: 26 }, catchRate: 190, baseExp: 112, description: 'Acumula electricidad estática en las mejillas rojas y descarga rayos al asustarse.' },
  { id: 26, name: 'Raichu', types: ['electrico'], baseStats: { hp: 60, attack: 90, defense: 55, spAtk: 90, spDef: 80, speed: 110 }, catchRate: 75, baseExp: 218, description: 'Si almacena demasiada energía en su cuerpo, descarga el exceso a través de su cola.' },

  // 27-28 Tierra
  { id: 27, name: 'Sandshrew', types: ['tierra'], baseStats: { hp: 50, attack: 75, defense: 85, spAtk: 20, spDef: 30, speed: 40 }, evolution: { type: 'level', level: 22, into: 28 }, catchRate: 255, baseExp: 60, description: 'Madriguero del desierto, se enrolla como una bola dura para esquivar ataques.' },
  { id: 28, name: 'Sandslash', types: ['tierra'], baseStats: { hp: 75, attack: 100, defense: 110, spAtk: 45, spDef: 55, speed: 65 }, catchRate: 90, baseExp: 158, description: 'Cubre su espalda con duras espinas y desgarra rocas con sus afiladas garras.' },

  // 29-34 Familia Nidoran
  { id: 29, name: 'Nidoran♀', types: ['veneno'], baseStats: { hp: 55, attack: 47, defense: 52, spAtk: 40, spDef: 40, speed: 41 }, evolution: { type: 'level', level: 16, into: 30 }, catchRate: 235, baseExp: 55, description: 'Pequeña pero armada con púas venenosas para protegerse en la maleza.' },
  { id: 30, name: 'Nidorina', types: ['veneno'], baseStats: { hp: 70, attack: 62, defense: 67, spAtk: 55, spDef: 55, speed: 56 }, evolution: { type: 'stone', stone: 'moon', into: 31 }, catchRate: 120, baseExp: 128, description: 'Cariñosa con su cría, retrae sus espinas cuando está en reposo con su manada.' },
  { id: 31, name: 'Nidoqueen', types: ['veneno', 'tierra'], baseStats: { hp: 90, attack: 92, defense: 87, spAtk: 75, spDef: 85, speed: 76 }, catchRate: 45, baseExp: 227, description: 'Su cuerpo cubierto de escamas resiste impactos demoledores sin retroceder.' },
  { id: 32, name: 'Nidoran♂', types: ['veneno'], baseStats: { hp: 46, attack: 57, defense: 40, spAtk: 40, spDef: 40, speed: 50 }, evolution: { type: 'level', level: 16, into: 33 }, catchRate: 235, baseExp: 55, description: 'Mueve sus grandes orejas para detectar peligros y ataca con su cuerno tóxico.' },
  { id: 33, name: 'Nidorino', types: ['veneno'], baseStats: { hp: 61, attack: 72, defense: 57, spAtk: 55, spDef: 55, speed: 65 }, evolution: { type: 'stone', stone: 'moon', into: 34 }, catchRate: 120, baseExp: 128, description: 'Fácilmente irritable, arremete contra cualquiera con su cuerno impregnado de veneno.' },
  { id: 34, name: 'Nidoking', types: ['veneno', 'tierra'], baseStats: { hp: 81, attack: 102, defense: 77, spAtk: 85, spDef: 75, speed: 85 }, catchRate: 45, baseExp: 227, description: 'Poderoso y temible, un golpe de su cola puede partir en dos postes de acero.' },

  // 35-36 Hadas Lunares
  { id: 35, name: 'Clefairy', types: ['normal'], baseStats: { hp: 70, attack: 45, defense: 48, spAtk: 60, spDef: 65, speed: 35 }, evolution: { type: 'stone', stone: 'moon', into: 36 }, catchRate: 150, baseExp: 113, description: 'Rara vez visto por humanos, danza bajo la luz de la luna en Monte Moon.' },
  { id: 36, name: 'Clefable', types: ['normal'], baseStats: { hp: 95, attack: 70, defense: 73, spAtk: 95, spDef: 90, speed: 60 }, catchRate: 25, baseExp: 217, description: 'Oído sumamente fino que le permite escuchar una aguja caer a un kilómetro.' },

  // 37-38 Zorros
  { id: 37, name: 'Vulpix', types: ['fuego'], baseStats: { hp: 38, attack: 41, defense: 40, spAtk: 50, spDef: 65, speed: 65 }, evolution: { type: 'stone', stone: 'fire', into: 38 }, catchRate: 190, baseExp: 60, description: 'Nace con una cola blanca que se divide en seis hermosas colas al crecer.' },
  { id: 38, name: 'Ninetales', types: ['fuego'], baseStats: { hp: 73, attack: 76, defense: 75, spAtk: 81, spDef: 100, speed: 100 }, catchRate: 75, baseExp: 177, description: 'Se dice que cada una de sus nueve colas posee un misterioso poder milenario.' },

  // 39-40 Globos
  { id: 39, name: 'Jigglypuff', types: ['normal'], baseStats: { hp: 115, attack: 45, defense: 20, spAtk: 45, spDef: 25, speed: 20 }, evolution: { type: 'stone', stone: 'moon', into: 40 }, catchRate: 170, baseExp: 95, description: 'Infla su cuerpo y canta una dulce melodía que induce el sueño inmediato.' },
  { id: 40, name: 'Wigglytuff', types: ['normal'], baseStats: { hp: 140, attack: 70, defense: 45, spAtk: 85, spDef: 50, speed: 45 }, catchRate: 50, baseExp: 196, description: 'Su pelaje es tan suave y esponjoso que nadie puede resistirse a acariciarlo.' },

  // 41-42 Murciélagos
  { id: 41, name: 'Zubat', types: ['veneno', 'volador'], baseStats: { hp: 40, attack: 45, defense: 35, spAtk: 30, spDef: 40, speed: 55 }, evolution: { type: 'level', level: 22, into: 42 }, catchRate: 255, baseExp: 49, description: 'Emite ondas ultrasónicas por la boca para ubicarse en las oscuras cavernas.' },
  { id: 42, name: 'Golbat', types: ['veneno', 'volador'], baseStats: { hp: 75, attack: 80, defense: 70, spAtk: 65, spDef: 75, speed: 90 }, catchRate: 90, baseExp: 159, description: 'Se abalanza en bandada y drena hasta 300 ml de sangre de su presa.' },

  // 43-45 Plantas venenosas
  { id: 43, name: 'Oddish', types: ['planta', 'veneno'], baseStats: { hp: 45, attack: 50, defense: 55, spAtk: 75, spDef: 65, speed: 30 }, evolution: { type: 'level', level: 21, into: 44 }, catchRate: 255, baseExp: 64, description: 'Durante el día duerme enterrado en la tierra y sale de noche a la luz lunar.' },
  { id: 44, name: 'Gloom', types: ['planta', 'veneno'], baseStats: { hp: 60, attack: 65, defense: 70, spAtk: 85, spDef: 75, speed: 40 }, evolution: { type: 'stone', stone: 'leaf', into: 45 }, catchRate: 120, baseExp: 138, description: 'El olor putrefacto de su pistilo es capaz de desmayar a quienes lo inhalan.' },
  { id: 45, name: 'Vileplume', types: ['planta', 'veneno'], baseStats: { hp: 75, attack: 80, defense: 85, spAtk: 110, spDef: 90, speed: 50 }, catchRate: 45, baseExp: 221, description: 'Posee los pétalos más grandes del mundo, cargados con abundante polen tóxico.' },

  // 46-47 Cangrejos hongos
  { id: 46, name: 'Paras', types: ['bicho', 'planta'], baseStats: { hp: 35, attack: 70, defense: 55, spAtk: 45, spDef: 55, speed: 25 }, evolution: { type: 'level', level: 24, into: 47 }, catchRate: 190, baseExp: 57, description: 'Hongos llamados tochukaso crecen en su lomo alimentándose de sus nutrientes.' },
  { id: 47, name: 'Parasect', types: ['bicho', 'planta'], baseStats: { hp: 60, attack: 95, defense: 80, spAtk: 60, spDef: 80, speed: 30 }, catchRate: 75, baseExp: 142, description: 'El hongo ha tomado el control total de su mente y esparce esporas venenosas.' },

  // 48-49 Polillas
  { id: 48, name: 'Venonat', types: ['bicho', 'veneno'], baseStats: { hp: 60, attack: 55, defense: 50, spAtk: 40, spDef: 55, speed: 45 }, evolution: { type: 'level', level: 31, into: 49 }, catchRate: 190, baseExp: 61, description: 'Grandes ojos compuestos que funcionan como radar para cazar insectos nocturnos.' },
  { id: 49, name: 'Venomoth', types: ['bicho', 'veneno'], baseStats: { hp: 70, attack: 65, defense: 60, spAtk: 90, spDef: 75, speed: 90 }, catchRate: 75, baseExp: 158, description: 'Esparce polvo de diferentes colores con sus alas: paralizante o venenoso.' },

  // 50-51 Topos
  { id: 50, name: 'Diglett', types: ['tierra'], baseStats: { hp: 10, attack: 55, defense: 25, spAtk: 35, spDef: 45, speed: 95 }, evolution: { type: 'level', level: 26, into: 51 }, catchRate: 255, baseExp: 53, description: 'Excava galerías subterráneas comiendo raíces y asoma su cabeza a la superficie.' },
  { id: 51, name: 'Dugtrio', types: ['tierra'], baseStats: { hp: 35, attack: 100, defense: 50, spAtk: 50, spDef: 70, speed: 120 }, catchRate: 50, baseExp: 149, description: 'Trío de cabezas que excavan coordinadas provocando temblores de tierra.' },

  // 52-53 Felinos
  { id: 52, name: 'Meowth', types: ['normal'], baseStats: { hp: 40, attack: 45, defense: 35, spAtk: 40, spDef: 40, speed: 90 }, evolution: { type: 'level', level: 28, into: 53 }, catchRate: 255, baseExp: 58, description: 'Le fascinan los objetos brillantes y redondos, especialmente las monedas.' },
  { id: 53, name: 'Persian', types: ['normal'], baseStats: { hp: 65, attack: 70, defense: 60, spAtk: 65, spDef: 65, speed: 115 }, catchRate: 90, baseExp: 154, description: 'Felino altivo y elegante con una joya brillante incrustada en la frente.' },

  // 54-55 Patos
  { id: 54, name: 'Psyduck', types: ['agua'], baseStats: { hp: 50, attack: 52, defense: 48, spAtk: 65, spDef: 50, speed: 55 }, evolution: { type: 'level', level: 33, into: 55 }, catchRate: 190, baseExp: 64, description: 'Sufre constantes dolores de cabeza que liberan misteriosos poderes telequinéticos.' },
  { id: 55, name: 'Golduck', types: ['agua'], baseStats: { hp: 80, attack: 82, defense: 78, spAtk: 95, spDef: 80, speed: 85 }, catchRate: 75, baseExp: 175, description: 'Nada con gran agilidad en lagos tranquilos superando incluso a campeones olímpicos.' },

  // 56-57 Monos
  { id: 56, name: 'Mankey', types: ['lucha'], baseStats: { hp: 40, attack: 80, defense: 35, spAtk: 35, spDef: 45, speed: 70 }, evolution: { type: 'level', level: 28, into: 57 }, catchRate: 190, baseExp: 61, description: 'Se enfurece rápidamente por cualquier motivo y arremete a golpes sin pensar.' },
  { id: 57, name: 'Primeape', types: ['lucha'], baseStats: { hp: 65, attack: 105, defense: 60, spAtk: 60, spDef: 70, speed: 95 }, catchRate: 75, baseExp: 159, description: 'Siempre furioso; la sangre corre con tanta fuerza por sus venas que se le eriza el pelo.' },

  // 58-59 Perros de fuego
  { id: 58, name: 'Growlithe', types: ['fuego'], baseStats: { hp: 55, attack: 70, defense: 45, spAtk: 70, spDef: 50, speed: 60 }, evolution: { type: 'stone', stone: 'fire', into: 59 }, catchRate: 190, baseExp: 70, description: 'Leal y valiente guardián, ladra ferozmente contra intrusos protegiendo a su amo.' },
  { id: 59, name: 'Arcanine', types: ['fuego'], baseStats: { hp: 90, attack: 110, defense: 80, spAtk: 100, spDef: 80, speed: 95 }, catchRate: 75, baseExp: 194, description: 'Legendario por su porte señorial y su velocidad como el viento.' },

  // 60-62 Renacuajos
  { id: 60, name: 'Poliwag', types: ['agua'], baseStats: { hp: 40, attack: 50, defense: 40, spAtk: 40, spDef: 40, speed: 90 }, evolution: { type: 'level', level: 25, into: 61 }, catchRate: 255, baseExp: 60, description: 'La espiral visible en su vientre transparente cambia de sentido según su región.' },
  { id: 61, name: 'Poliwhirl', types: ['agua'], baseStats: { hp: 65, attack: 65, defense: 65, spAtk: 50, spDef: 50, speed: 90 }, evolution: { type: 'stone', stone: 'water', into: 62 }, catchRate: 120, baseExp: 135, description: 'Capaz de caminar sobre dos patas y lanzar bofetones de agua giratorios.' },
  { id: 62, name: 'Poliwrath', types: ['agua', 'lucha'], baseStats: { hp: 90, attack: 95, defense: 95, spAtk: 70, spDef: 90, speed: 70 }, catchRate: 45, baseExp: 230, description: 'Excelente nadador cuyos músculos fibrosos nunca se fatigan cruzando mares.' },

  // 63-65 Psíquicos
  { id: 63, name: 'Abra', types: ['psiquico'], baseStats: { hp: 25, attack: 20, defense: 15, spAtk: 105, spDef: 55, speed: 90 }, evolution: { type: 'level', level: 16, into: 64 }, catchRate: 200, baseExp: 62, description: 'Duerme 18 horas al día y se teletransporta por reflejo cuando siente peligro.' },
  { id: 64, name: 'Kadabra', types: ['psiquico'], baseStats: { hp: 40, attack: 35, defense: 30, spAtk: 120, spDef: 70, speed: 105 }, evolution: { type: 'item', item: 'cable_link', into: 65 }, catchRate: 100, baseExp: 140, description: 'Sostiene una cuchara de plata para enfocar y amplificar sus ondas cerebrales.' },
  { id: 65, name: 'Alakazam', types: ['psiquico'], baseStats: { hp: 55, attack: 50, defense: 45, spAtk: 135, spDef: 95, speed: 120 }, catchRate: 50, baseExp: 225, description: 'Su cerebro prodigioso con CI de 5000 recuerda cada suceso desde su nacimiento.' },

  // 66-68 Luchadores
  { id: 66, name: 'Machop', types: ['lucha'], baseStats: { hp: 70, attack: 80, defense: 50, spAtk: 35, spDef: 35, speed: 35 }, evolution: { type: 'level', level: 28, into: 67 }, catchRate: 180, baseExp: 61, description: 'Entrena levantando rocas en las montañas para tonificar toda su musculatura.' },
  { id: 67, name: 'Machoke', types: ['lucha'], baseStats: { hp: 80, attack: 100, defense: 70, spAtk: 50, spDef: 60, speed: 45 }, evolution: { type: 'item', item: 'cable_link', into: 68 }, catchRate: 90, baseExp: 142, description: 'Lleva un cinturón limitador para contener su fuerza titánica y no desbordarse.' },
  { id: 68, name: 'Machamp', types: ['lucha'], baseStats: { hp: 90, attack: 130, defense: 80, spAtk: 65, spDef: 85, speed: 55 }, catchRate: 45, baseExp: 227, description: 'Con sus cuatro brazos puede soltar mil puñetazos en cuestión de dos segundos.' },

  // 69-71 Carnívoras
  { id: 69, name: 'Bellsprout', types: ['planta', 'veneno'], baseStats: { hp: 50, attack: 75, defense: 35, spAtk: 70, spDef: 30, speed: 40 }, evolution: { type: 'level', level: 21, into: 70 }, catchRate: 255, baseExp: 60, description: 'Planta con cuerpo flexible que esquiva golpes y atrapa insectos desprevenidos.' },
  { id: 70, name: 'Weepinbell', types: ['planta', 'veneno'], baseStats: { hp: 65, attack: 90, defense: 50, spAtk: 85, spDef: 45, speed: 55 }, evolution: { type: 'stone', stone: 'leaf', into: 71 }, catchRate: 120, baseExp: 137, description: 'Se cuelga de ramas con su gancho trasero y disuelve a sus presas con ácido.' },
  { id: 71, name: 'Victreebel', types: ['planta', 'veneno'], baseStats: { hp: 80, attack: 105, defense: 65, spAtk: 100, spDef: 70, speed: 70 }, catchRate: 45, baseExp: 221, description: 'Atrae víctimas con un aroma dulce y las traga enteras en su boca devoradora.' },

  // 72-73 Medusas
  { id: 72, name: 'Tentacool', types: ['agua', 'veneno'], baseStats: { hp: 40, attack: 40, defense: 35, spAtk: 50, spDef: 100, speed: 70 }, evolution: { type: 'level', level: 30, into: 73 }, catchRate: 190, baseExp: 67, description: 'Cuerpo compuesto en un 99% por agua, flota libre por todos los océanos.' },
  { id: 73, name: 'Tentacruel', types: ['agua', 'veneno'], baseStats: { hp: 80, attack: 70, defense: 65, spAtk: 80, spDef: 120, speed: 100 }, catchRate: 60, baseExp: 180, description: 'Posee 80 tentáculos que estira a voluntad para inmovilizar a sus rivales.' },

  // 74-76 Rocas
  { id: 74, name: 'Geodude', types: ['roca', 'tierra'], baseStats: { hp: 40, attack: 80, defense: 100, spAtk: 30, spDef: 30, speed: 20 }, evolution: { type: 'level', level: 25, into: 75 }, catchRate: 255, baseExp: 60, description: 'Se confunde con rocas en los caminos y rueda cuesta abajo si se enfada.' },
  { id: 75, name: 'Graveler', types: ['roca', 'tierra'], baseStats: { hp: 55, attack: 95, defense: 115, spAtk: 45, spDef: 45, speed: 35 }, evolution: { type: 'item', item: 'cable_link', into: 76 }, catchRate: 120, baseExp: 137, description: 'Rueda a gran velocidad por las laderas aplastando cualquier obstáculo en su camino.' },
  { id: 76, name: 'Golem', types: ['roca', 'tierra'], baseStats: { hp: 80, attack: 120, defense: 130, spAtk: 55, spDef: 65, speed: 45 }, catchRate: 45, baseExp: 223, description: 'Su caparazón rocoso resiste dinamita; muda de piel una vez al año.' },

  // 77-78 Caballos de fuego
  { id: 77, name: 'Ponyta', types: ['fuego'], baseStats: { hp: 50, attack: 85, defense: 55, spAtk: 65, spDef: 65, speed: 90 }, evolution: { type: 'level', level: 40, into: 78 }, catchRate: 190, baseExp: 82, description: 'Sus pezuñas son diez veces más duras que el diamante; salta montañas con soltura.' },
  { id: 78, name: 'Rapidash', types: ['fuego'], baseStats: { hp: 65, attack: 100, defense: 70, spAtk: 80, spDef: 80, speed: 105 }, catchRate: 60, baseExp: 175, description: 'Galopa a más de 240 km/h envuelto en una deslumbrante melena de fuego.' },

  // 79-80 Perezosos
  { id: 79, name: 'Slowpoke', types: ['agua', 'psiquico'], baseStats: { hp: 90, attack: 65, defense: 65, spAtk: 40, spDef: 40, speed: 15 }, evolution: { type: 'level', level: 37, into: 80 }, catchRate: 190, baseExp: 63, description: 'Increíblemente perezoso y distraído, tarda un día entero en sentir dolor en su cola.' },
  { id: 80, name: 'Slowbro', types: ['agua', 'psiquico'], baseStats: { hp: 95, attack: 75, defense: 110, spAtk: 100, spDef: 80, speed: 30 }, catchRate: 75, baseExp: 172, description: 'Un Shellder mordió su cola y desató una curiosa simbiosis evolutiva.' },

  // 81-82 Imanes
  { id: 81, name: 'Magnemite', types: ['electrico'], baseStats: { hp: 25, attack: 35, defense: 70, spAtk: 95, spDef: 55, speed: 45 }, evolution: { type: 'level', level: 30, into: 82 }, catchRate: 190, baseExp: 65, description: 'Levita mediante ondas electromagnéticas generadas por sus dos imanes laterales.' },
  { id: 82, name: 'Magneton', types: ['electrico'], baseStats: { hp: 50, attack: 60, defense: 95, spAtk: 120, spDef: 70, speed: 70 }, catchRate: 60, baseExp: 163, description: 'Unión magnética de tres Magnemite que genera potentes interferencias de radio.' },

  // 83 Pato puerro
  { id: 83, name: "Farfetch'd", types: ['normal', 'volador'], baseStats: { hp: 52, attack: 90, defense: 55, spAtk: 58, spDef: 62, speed: 60 }, catchRate: 45, baseExp: 132, description: 'Siempre lleva consigo un tallo de puerro que blande como una diestra espada.' },

  // 84-85 Pájaros de dos cabezas
  { id: 84, name: 'Doduo', types: ['normal', 'volador'], baseStats: { hp: 35, attack: 85, defense: 45, spAtk: 35, spDef: 35, speed: 75 }, evolution: { type: 'level', level: 31, into: 85 }, catchRate: 190, baseExp: 62, description: 'Sus dos cabezas se turnan para dormir y montar guardia ante los depredadores.' },
  { id: 85, name: 'Dodrio', types: ['normal', 'volador'], baseStats: { hp: 60, attack: 110, defense: 70, spAtk: 60, spDef: 60, speed: 100 }, catchRate: 45, baseExp: 165, description: 'Posee tres cabezas que expresan alegría, tristeza e ira respectivamente.' },

  // 86-87 Focas
  { id: 86, name: 'Seel', types: ['agua'], baseStats: { hp: 65, attack: 45, defense: 55, spAtk: 45, spDef: 70, speed: 45 }, evolution: { type: 'level', level: 34, into: 87 }, catchRate: 190, baseExp: 65, description: 'Cubierto de una piel gruesa y cálida, nada felizmente entre témpanos de hielo.' },
  { id: 87, name: 'Dewgong', types: ['agua', 'hielo'], baseStats: { hp: 90, attack: 70, defense: 80, spAtk: 70, spDef: 95, speed: 70 }, catchRate: 75, baseExp: 166, description: 'Cuerpo hidrodinámico blanco puro que le permite surcar mares a temperaturas gélidas.' },

  // 88-89 Lodos
  { id: 88, name: 'Grimer', types: ['veneno'], baseStats: { hp: 80, attack: 80, defense: 50, spAtk: 40, spDef: 50, speed: 25 }, evolution: { type: 'level', level: 38, into: 89 }, catchRate: 190, baseExp: 65, description: 'Nacido en lodo tóxico contaminado, se alimenta de residuos industriales en alcantarillas.' },
  { id: 89, name: 'Muk', types: ['veneno'], baseStats: { hp: 105, attack: 105, defense: 75, spAtk: 65, spDef: 100, speed: 50 }, catchRate: 75, baseExp: 175, description: 'Tan pestilente y tóxico que cualquier planta que roce se marchita al instante.' },

  // 90-91 Ostras
  { id: 90, name: 'Shellder', types: ['agua'], baseStats: { hp: 30, attack: 65, defense: 100, spAtk: 45, spDef: 25, speed: 40 }, evolution: { type: 'stone', stone: 'water', into: 91 }, catchRate: 190, baseExp: 61, description: 'Su concha dura resiste cualquier impacto; asoma su lengua cuando está relajado.' },
  { id: 91, name: 'Cloyster', types: ['agua', 'hielo'], baseStats: { hp: 50, attack: 95, defense: 180, spAtk: 85, spDef: 45, speed: 70 }, catchRate: 60, baseExp: 184, description: 'Su caparazón exterior es indestructible ante proyectiles y misiles balísticos.' },

  // 92-94 Fantasmas
  { id: 92, name: 'Gastly', types: ['fantasma', 'veneno'], baseStats: { hp: 30, attack: 35, defense: 30, spAtk: 100, spDef: 35, speed: 80 }, evolution: { type: 'level', level: 25, into: 93 }, catchRate: 190, baseExp: 62, description: 'Cuerpo gaseoso etéreo que se filtra a través de cualquier ranura o ventana.' },
  { id: 93, name: 'Haunter', types: ['fantasma', 'veneno'], baseStats: { hp: 45, attack: 50, defense: 45, spAtk: 115, spDef: 55, speed: 95 }, evolution: { type: 'item', item: 'cable_link', into: 94 }, catchRate: 90, baseExp: 142, description: 'Se oculta en las sombras esperando a su víctima para lamerla y robar su energía.' },
  { id: 94, name: 'Gengar', types: ['fantasma', 'veneno'], baseStats: { hp: 60, attack: 65, defense: 60, spAtk: 130, spDef: 75, speed: 110 }, catchRate: 45, baseExp: 225, description: 'Sonríe maliciosamente en la oscuridad y hace bajar la temperatura de la habitación.' },

  // 95 Serpiente de roca
  { id: 95, name: 'Onix', types: ['roca', 'tierra'], baseStats: { hp: 35, attack: 45, defense: 160, spAtk: 30, spDef: 45, speed: 70 }, catchRate: 45, baseExp: 77, description: 'Serpiente gigante de rocas que horada túneles a más de 80 km/h bajo tierra.' },

  // 96-97 Hipnosis
  { id: 96, name: 'Drowzee', types: ['psiquico'], baseStats: { hp: 60, attack: 48, defense: 45, spAtk: 43, spDef: 90, speed: 42 }, evolution: { type: 'level', level: 26, into: 97 }, catchRate: 190, baseExp: 66, description: 'Duerme a la gente con hipnosis y devora sus sueños a través de la nariz.' },
  { id: 97, name: 'Hypno', types: ['psiquico'], baseStats: { hp: 85, attack: 73, defense: 70, spAtk: 73, spDef: 115, speed: 67 }, catchRate: 75, baseExp: 169, description: 'Lleva un péndulo que balancea rítmicamente para sumergir a su rival en trance.' },

  // 98-99 Cangrejos
  { id: 98, name: 'Krabby', types: ['agua'], baseStats: { hp: 30, attack: 105, defense: 90, spAtk: 25, spDef: 25, speed: 50 }, evolution: { type: 'level', level: 28, into: 99 }, catchRate: 225, baseExp: 65, description: 'Habita en playas y orillas rocosas; sus pinzas son tenazas de corte formidables.' },
  { id: 99, name: 'Kingler', types: ['agua'], baseStats: { hp: 55, attack: 130, defense: 115, spAtk: 50, spDef: 50, speed: 75 }, catchRate: 60, baseExp: 166, description: 'Una de sus pinzas creció de forma descomunal con una fuerza aplastante de 10.000 CV.' },

  // 100-101 Bombas
  { id: 100, name: 'Voltorb', types: ['electrico'], baseStats: { hp: 40, attack: 30, defense: 50, spAtk: 55, spDef: 55, speed: 100 }, evolution: { type: 'level', level: 30, into: 101 }, catchRate: 190, baseExp: 66, description: 'Se camufla como una Pokéball común y detona violentamente si es manipulado.' },
  { id: 101, name: 'Electrode', types: ['electrico'], baseStats: { hp: 60, attack: 50, defense: 70, spAtk: 80, spDef: 80, speed: 150 }, catchRate: 60, baseExp: 172, description: 'El más veloz de Kanto; absorbe tanta electricidad que explota ante el menor roce.' },

  // 102-103 Palmeras
  { id: 102, name: 'Exeggcute', types: ['planta', 'psiquico'], baseStats: { hp: 60, attack: 40, defense: 80, spAtk: 60, spDef: 45, speed: 40 }, evolution: { type: 'stone', stone: 'leaf', into: 103 }, catchRate: 90, baseExp: 65, description: 'Grupo de seis huevos conectados telepáticamente que se comunican entre sí.' },
  { id: 103, name: 'Exeggutor', types: ['planta', 'psiquico'], baseStats: { hp: 95, attack: 95, defense: 85, spAtk: 125, spDef: 75, speed: 55 }, catchRate: 45, baseExp: 186, description: 'Cada una de sus tres cabezas piensa de forma independiente con gran sabiduría.' },

  // 104-105 Huesudos
  { id: 104, name: 'Cubone', types: ['tierra'], baseStats: { hp: 50, attack: 50, defense: 95, spAtk: 40, spDef: 50, speed: 35 }, evolution: { type: 'level', level: 28, into: 105 }, catchRate: 190, baseExp: 64, description: 'Lleva el cráneo de su difunta madre y llora amargamente bajo la luz de la luna llena.' },
  { id: 105, name: 'Marowak', types: ['tierra'], baseStats: { hp: 60, attack: 80, defense: 110, spAtk: 50, spDef: 80, speed: 45 }, catchRate: 75, baseExp: 149, description: 'Superó su pena y endureció su carácter; blande su hueso como un experto bumerán.' },

  // 106-107 Luchadores del dojo
  { id: 106, name: 'Hitmonlee', types: ['lucha'], baseStats: { hp: 50, attack: 120, defense: 53, spAtk: 35, spDef: 110, speed: 87 }, catchRate: 45, baseExp: 159, description: 'Sus piernas elásticas se estiran como resortes asestando patadas devastadoras.' },
  { id: 107, name: 'Hitmonchan', types: ['lucha'], baseStats: { hp: 50, attack: 105, defense: 79, spAtk: 35, spDef: 110, speed: 76 }, catchRate: 45, baseExp: 159, description: 'Posee el espíritu de un boxeador profesional y corta el aire con sus puñetazos.' },

  // 108 Lengua
  { id: 108, name: 'Lickitung', types: ['normal'], baseStats: { hp: 90, attack: 55, defense: 75, spAtk: 60, spDef: 75, speed: 30 }, catchRate: 45, baseExp: 77, description: 'Su lengua mide más de dos metros y la usa para limpiarse o paralizar a su presa.' },

  // 109-110 Gases tóxicos
  { id: 109, name: 'Koffing', types: ['veneno'], baseStats: { hp: 40, attack: 65, defense: 95, spAtk: 60, spDef: 45, speed: 35 }, evolution: { type: 'level', level: 35, into: 110 }, catchRate: 190, baseExp: 68, description: 'Su cuerpo inflado contiene gases corrosivos inflamables que huelen a pólvora.' },
  { id: 110, name: 'Weezing', types: ['veneno'], baseStats: { hp: 65, attack: 90, defense: 120, spAtk: 85, spDef: 70, speed: 60 }, catchRate: 60, baseExp: 172, description: 'Dos cabezas que mezclan gases residuales para crear fragancias mortales.' },

  // 111-112 Rinocerontes
  { id: 111, name: 'Rhyhorn', types: ['tierra', 'roca'], baseStats: { hp: 80, attack: 85, defense: 95, spAtk: 30, spDef: 30, speed: 25 }, evolution: { type: 'level', level: 42, into: 112 }, catchRate: 120, baseExp: 69, description: 'De huesos macizos y cerebro simple, embiste de frente olvidando por qué corría.' },
  { id: 112, name: 'Rhydon', types: ['tierra', 'roca'], baseStats: { hp: 105, attack: 130, defense: 120, spAtk: 45, spDef: 45, speed: 40 }, catchRate: 60, baseExp: 170, description: 'Su cuerno giratorio taladra diamantes; puede caminar sobre lava sin quemarse.' },

  // 113 Enfermera
  { id: 113, name: 'Chansey', types: ['normal'], baseStats: { hp: 250, attack: 5, defense: 5, spAtk: 35, spDef: 105, speed: 50 }, catchRate: 30, baseExp: 395, description: 'Pone huevos deliciosos y muy nutritivos que comparte con personas heridas.' },

  // 114 Enredaderas
  { id: 114, name: 'Tangela', types: ['planta'], baseStats: { hp: 65, attack: 55, defense: 115, spAtk: 100, spDef: 40, speed: 60 }, catchRate: 45, baseExp: 87, description: 'Todo su cuerpo está oculto tras una maraña de lianas azules en continuo movimiento.' },

  // 115 Canguro
  { id: 115, name: 'Kangaskhan', types: ['normal'], baseStats: { hp: 105, attack: 95, defense: 80, spAtk: 40, spDef: 80, speed: 90 }, catchRate: 45, baseExp: 172, description: 'Cría a su pequeño en su marsupio ventral y lo protege con ferocidad sin igual.' },

  // 116-117 Caballitos de mar
  { id: 116, name: 'Horsea', types: ['agua'], baseStats: { hp: 30, attack: 40, defense: 70, spAtk: 70, spDef: 25, speed: 60 }, evolution: { type: 'level', level: 32, into: 117 }, catchRate: 225, baseExp: 59, description: 'Dispara chorros de tinta oscura para ocultarse al menor síntoma de peligro.' },
  { id: 117, name: 'Seadra', types: ['agua'], baseStats: { hp: 55, attack: 65, defense: 95, spAtk: 95, spDef: 45, speed: 85 }, catchRate: 75, baseExp: 154, description: 'Cuerpo armado con púas afiladas; genera remolinos de agua nadando hacia atrás.' },

  // 118-119 Peces dorados
  { id: 118, name: 'Goldeen', types: ['agua'], baseStats: { hp: 45, attack: 67, defense: 60, spAtk: 35, spDef: 50, speed: 63 }, evolution: { type: 'level', level: 33, into: 119 }, catchRate: 225, baseExp: 64, description: 'Conocido como la reina del agua dulce, luce aletas ondulantes como un vestido.' },
  { id: 119, name: 'Seaking', types: ['agua'], baseStats: { hp: 80, attack: 92, defense: 65, spAtk: 65, spDef: 80, speed: 68 }, catchRate: 60, baseExp: 158, description: 'Taladra agujeros en las rocas de los ríos con su cuerno para depositar sus huevos.' },

  // 120-121 Estrellas de mar
  { id: 120, name: 'Staryu', types: ['agua'], baseStats: { hp: 30, attack: 45, defense: 55, spAtk: 70, spDef: 55, speed: 85 }, evolution: { type: 'stone', stone: 'water', into: 121 }, catchRate: 225, baseExp: 68, description: 'Si pierde una de sus puntas en combate, la regenera por completo en poco tiempo.' },
  { id: 121, name: 'Starmie', types: ['agua', 'psiquico'], baseStats: { hp: 60, attack: 75, defense: 85, spAtk: 100, spDef: 85, speed: 115 }, catchRate: 60, baseExp: 182, description: 'El núcleo de su centro destella con los siete colores del arcoíris hacia el cosmos.' },

  // 122 Mimo
  { id: 122, name: 'Mr. Mime', types: ['psiquico'], baseStats: { hp: 40, attack: 45, defense: 65, spAtk: 100, spDef: 120, speed: 90 }, catchRate: 45, baseExp: 161, description: 'Crea muros invisibles en el aire condensando partículas con la punta de sus dedos.' },

  // 123 Mantis
  { id: 123, name: 'Scyther', types: ['bicho', 'volador'], baseStats: { hp: 70, attack: 110, defense: 80, spAtk: 55, spDef: 80, speed: 105 }, catchRate: 45, baseExp: 100, description: 'Corta árboles gruesos de un tajo con sus guadañas afiladas a velocidad ninja.' },

  // 124 Ilusionista
  { id: 124, name: 'Jynx', types: ['hielo', 'psiquico'], baseStats: { hp: 65, attack: 50, defense: 35, spAtk: 115, spDef: 95, speed: 95 }, catchRate: 45, baseExp: 159, description: 'Mueve sus caderas con un ritmo tan contagioso que hace bailar a los transeúntes.' },

  // 125 Eléctrico
  { id: 125, name: 'Electabuzz', types: ['electrico'], baseStats: { hp: 65, attack: 83, defense: 57, spAtk: 95, spDef: 85, speed: 105 }, catchRate: 45, baseExp: 172, description: 'Suele frecuentar plantas de energía absorbiendo kilovatios directamente de los postes.' },

  // 126 Fuego
  { id: 126, name: 'Magmar', types: ['fuego'], baseStats: { hp: 65, attack: 95, defense: 57, spAtk: 100, spDef: 85, speed: 93 }, catchRate: 45, baseExp: 173, description: 'Nacido cerca de volcanes, su piel naranja alcanza temperaturas de 1.200 °C.' },

  // 127 Escarabajo
  { id: 127, name: 'Pinsir', types: ['bicho'], baseStats: { hp: 65, attack: 125, defense: 100, spAtk: 55, spDef: 70, speed: 85 }, catchRate: 45, baseExp: 175, description: 'Atrapa a sus presas con sus temibles pinzas y las parte en dos sin compasión.' },

  // 128 Toro
  { id: 128, name: 'Tauros', types: ['normal'], baseStats: { hp: 75, attack: 100, defense: 95, spAtk: 40, spDef: 70, speed: 110 }, catchRate: 45, baseExp: 172, description: 'Azota sus tres colas para motivarse antes de lanzarse a la carga.' },

  // 129-130 Magikarp - Gyarados
  { id: 129, name: 'Magikarp', types: ['agua'], baseStats: { hp: 20, attack: 10, defense: 55, spAtk: 15, spDef: 20, speed: 80 }, evolution: { type: 'level', level: 20, into: 130 }, catchRate: 255, baseExp: 40, description: 'Famoso por su debilidad e inutilidad, solo sabe salpicar sin causar daño.' },
  { id: 130, name: 'Gyarados', types: ['agua', 'volador'], baseStats: { hp: 95, attack: 125, defense: 79, spAtk: 60, spDef: 100, speed: 81 }, catchRate: 45, baseExp: 189, description: 'Dragón temible que destruye ciudades enteras cuando entra en furia ciega.' },

  // 131 Monstruo de transporte
  { id: 131, name: 'Lapras', types: ['agua', 'hielo'], baseStats: { hp: 130, attack: 85, defense: 80, spAtk: 85, spDef: 95, speed: 60 }, catchRate: 45, baseExp: 187, description: 'De corazón dulce y voz melodiosa, transporta a humanos en su lomo sobre el mar.' },

  // 132 Mimo genético
  { id: 132, name: 'Ditto', types: ['normal'], baseStats: { hp: 48, attack: 48, defense: 48, spAtk: 48, spDef: 48, speed: 48 }, catchRate: 35, baseExp: 101, description: 'Reorganiza su estructura celular para transformarse en cualquier oponente.' },

  // 133-136 Eevee y evoluciones
  { id: 133, name: 'Eevee', types: ['normal'], baseStats: { hp: 55, attack: 55, defense: 50, spAtk: 45, spDef: 65, speed: 55 }, catchRate: 45, baseExp: 65, description: 'Su código genético inestable le permite evolucionar en múltiples formas elementales.' },
  { id: 134, name: 'Vaporeon', types: ['agua'], baseStats: { hp: 130, attack: 65, defense: 60, spAtk: 110, spDef: 95, speed: 65 }, catchRate: 45, baseExp: 184, description: 'Sus células son idénticas al agua; puede fundirse con ella haciéndose invisible.' },
  { id: 135, name: 'Jolteon', types: ['electrico'], baseStats: { hp: 65, attack: 65, defense: 60, spAtk: 110, spDef: 95, speed: 130 }, catchRate: 45, baseExp: 184, description: 'Eriza su pelaje como agujas cargadas de 10.000 voltios que dispara a voluntad.' },
  { id: 136, name: 'Flareon', types: ['fuego'], baseStats: { hp: 65, attack: 130, defense: 60, spAtk: 95, spDef: 110, speed: 65 }, catchRate: 45, baseExp: 184, description: 'Almacena fuego ardiente en su bolsa interna expulsando llamas a 1.700 °C.' },

  // 137 Porygon digital
  { id: 137, name: 'Porygon', types: ['normal'], baseStats: { hp: 65, attack: 60, defense: 70, spAtk: 85, spDef: 75, speed: 40 }, catchRate: 45, baseExp: 79, description: 'Primer Pokémon artificial creado mediante código de programación informática.' },

  // 138-141 Fósiles
  { id: 138, name: 'Omanyte', types: ['roca', 'agua'], baseStats: { hp: 35, attack: 40, defense: 100, spAtk: 90, spDef: 55, speed: 35 }, evolution: { type: 'level', level: 40, into: 139 }, catchRate: 45, baseExp: 71, description: 'Pokémon prehistórico revivido de un fósil hélix; nadaba en mares antiguos.' },
  { id: 139, name: 'Omastar', types: ['roca', 'agua'], baseStats: { hp: 70, attack: 60, defense: 125, spAtk: 115, spDef: 70, speed: 55 }, catchRate: 45, baseExp: 173, description: 'Sus afilados tentáculos y pico triturador rompían las conchas de sus presas.' },
  { id: 140, name: 'Kabuto', types: ['roca', 'agua'], baseStats: { hp: 30, attack: 80, defense: 90, spAtk: 55, spDef: 45, speed: 55 }, evolution: { type: 'level', level: 40, into: 141 }, catchRate: 45, baseExp: 71, description: 'Resucitado del fósil domo, se oculta en el lecho marino con su caparazón blindado.' },
  { id: 141, name: 'Kabutops', types: ['roca', 'agua'], baseStats: { hp: 60, attack: 115, defense: 105, spAtk: 65, spDef: 70, speed: 80 }, catchRate: 45, baseExp: 173, description: 'Depredador ágil que desgarraba a sus víctimas submarinas con guadañas curvas.' },
  { id: 142, name: 'Aerodactyl', types: ['roca', 'volador'], baseStats: { hp: 80, attack: 105, defense: 65, spAtk: 60, spDef: 75, speed: 130 }, catchRate: 45, baseExp: 180, description: 'Pterosaurio feroz revivido del ámbar viejo; surcaba los cielos del jurásico.' },

  // 143 Oso durmiente
  { id: 143, name: 'Snorlax', types: ['normal'], baseStats: { hp: 160, attack: 110, defense: 65, spAtk: 65, spDef: 110, speed: 30 }, catchRate: 25, baseExp: 189, description: 'Solo se despierta para comer 400 kg de comida al día y vuelve a dormirse.' },

  // 144-146 Trío de Aves Legendarias
  { id: 144, name: 'Articuno', types: ['hielo', 'volador'], baseStats: { hp: 90, attack: 85, defense: 100, spAtk: 95, spDef: 125, speed: 85 }, catchRate: 3, baseExp: 261, description: 'Ave legendaria de las nieves; el aleteo de sus alas congela el aire a su paso.' },
  { id: 145, name: 'Zapdos', types: ['electrico', 'volador'], baseStats: { hp: 90, attack: 90, defense: 85, spAtk: 125, spDef: 90, speed: 100 }, catchRate: 3, baseExp: 261, description: 'Ave legendaria del rayo; aparece entre nubes de tormenta descargando centellas.' },
  { id: 146, name: 'Moltres', types: ['fuego', 'volador'], baseStats: { hp: 90, attack: 100, defense: 90, spAtk: 125, spDef: 85, speed: 90 }, catchRate: 3, baseExp: 261, description: 'Ave legendaria del fuego; sus alas envueltas en llamas traen la primavera.' },

  // 147-149 Familia Dragón
  { id: 147, name: 'Dratini', types: ['dragon'], baseStats: { hp: 41, attack: 64, defense: 45, spAtk: 50, spDef: 50, speed: 50 }, evolution: { type: 'level', level: 30, into: 148 }, catchRate: 45, baseExp: 60, description: 'Durante siglos fue considerado un mito; muda continuamente su piel azulada.' },
  { id: 148, name: 'Dragonair', types: ['dragon'], baseStats: { hp: 61, attack: 84, defense: 65, spAtk: 70, spDef: 70, speed: 70 }, evolution: { type: 'level', level: 55, into: 149 }, catchRate: 45, baseExp: 147, description: 'Habita en lagos cristalinos y cambia el clima a su alrededor con sus perlas orbes.' },
  { id: 149, name: 'Dragonite', types: ['dragon', 'volador'], baseStats: { hp: 91, attack: 134, defense: 95, spAtk: 100, spDef: 100, speed: 80 }, catchRate: 45, baseExp: 270, description: 'Bondadoso titán volador que rescata a marineros perdidos en alta mar.' },

  // 150-151 Míticos y Legendarios
  { id: 150, name: 'Mewtwo', types: ['psiquico'], baseStats: { hp: 106, attack: 110, defense: 90, spAtk: 154, spDef: 90, speed: 130 }, catchRate: 3, baseExp: 306, description: 'Creado mediante ingeniería genética a partir de Mew; posee el corazón más despiadado.' },
  { id: 151, name: 'Mew', types: ['psiquico'], baseStats: { hp: 100, attack: 100, defense: 100, spAtk: 100, spDef: 100, speed: 100 }, catchRate: 45, baseExp: 270, description: 'Se dice que posee el mapa genético de todos los Pokémon del mundo.' },
];

/**
 * Diccionario de Pokémon por ID para acceso O(1)
 */
export const POKEMON_BY_ID: Record<number, PokemonSpecies> = POKEMON_151.reduce(
  (acc, p) => {
    acc[p.id] = p;
    return acc;
  },
  {} as Record<number, PokemonSpecies>
);

/**
 * Helper para obtener URL de sprite confiable y fallback
 */
export function getPokemonSpriteUrl(id: number): string {
  return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png`;
}
