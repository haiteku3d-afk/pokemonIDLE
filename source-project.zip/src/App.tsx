/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { GameSave, OwnedPokemon, ZoneData, StatKey, PendingMoveLearning } from './types/pokemon';
import { KANTO_ZONES, ZONES_BY_ID, evaluateAllUnlockedZones } from './data/zones';
import { POKEMON_BY_ID } from './data/pokemon151';
import { GymLeader, StoryMission } from './data/gymsAndMissions';
import {
  loadGame,
  saveGame,
  getDefaultSave,
  createOwnedPokemon,
  rollFromEncounterTable,
  recalculatePokemonStats,
  getNextIvCost,
} from './utils/pokemonHelpers';
import { getLevelCap } from './utils/levelCaps';
import { SPECIES_LEARNSETS } from './data/speciesLearnsets';
import { retroAudio } from './utils/audio';

import { Navbar, ScreenTab } from './components/Navbar';
import { StarterModal } from './components/StarterModal';
import { ExpeditionScreen } from './components/ExpeditionScreen';
import { PacksScreen } from './components/PacksScreen';
import { PackOpeningModal, DrawnCardResult } from './components/PackOpeningModal';
import { PokedexScreen } from './components/PokedexScreen';
import { TeamScreen } from './components/TeamScreen';
import { GymsScreen } from './components/GymsScreen';
import { MapScreen } from './components/MapScreen';
import { SettingsModal } from './components/SettingsModal';
import { PokemonCardModal } from './components/PokemonCardModal';
import { MoveLearningModal } from './components/MoveLearningModal';
import { TrainersScreen } from './components/TrainersScreen';
import { ShopScreen } from './components/ShopScreen';
import { ShopItem } from './data/items';
import { KantoObjectives } from './components/KantoObjectives';
import { Swords } from 'lucide-react';

function autoImproveIvs(pokemon: OwnedPokemon): OwnedPokemon {
  const stats: StatKey[] = ['hp', 'attack', 'defense', 'spAtk', 'spDef', 'speed'];
  const ivs = { ...pokemon.ivs };
  let copies = pokemon.upgradeCopies;
  while (true) {
    const next = stats.filter(stat => ivs[stat] < 31).sort((a, b) => ivs[a] - ivs[b])[0];
    if (!next) break;
    const cost = getNextIvCost(ivs[next]);
    if (copies < cost) break;
    copies -= cost;
    ivs[next]++;
  }
  if (copies === pokemon.upgradeCopies) return pokemon;
  const improved = recalculatePokemonStats({ ...pokemon, ivs, upgradeCopies: copies });
  // Mejorar IV no cura ni revive al Pokémon.
  return { ...improved, currentHp: Math.min(pokemon.currentHp, improved.maxHp) };
}

export default function App() {
  const [gameState, setGameState] = useState<GameSave>(() => loadGame());
  useEffect(() => {
    setGameState(previous => {
      const team = previous.team.map(autoImproveIvs);
      const pcBox = previous.pcBox.map(autoImproveIvs);
      if (team.every((p, i) => p === previous.team[i]) && pcBox.every((p, i) => p === previous.pcBox[i])) return previous;
      return { ...previous, team, pcBox };
    });
  }, [gameState.team, gameState.pcBox]);
  const [currentTab, setCurrentTab] = useState<ScreenTab>('expedition');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isMoveLearningOpen, setIsMoveLearningOpen] = useState(false);

  // Ficha de Pokémon seleccionada para ver estadísticas y entrenar IVs
  const [selectedCardPokemonUid, setSelectedCardPokemonUid] = useState<string | null>(null);

  // Estado para la animación de apertura de sobre
  const [activePackOpening, setActivePackOpening] = useState<{
    isOpen: boolean;
    packName: string;
    cards: DrawnCardResult[];
  }>({
    isOpen: false,
    packName: '',
    cards: [],
  });

  // Guardado automático en localStorage al cambiar el estado
  useEffect(() => {
    saveGame(gameState);
  }, [gameState]);

  // Sincronizar audio con los ajustes del usuario
  useEffect(() => {
    retroAudio.enabled = gameState.settings.sound;
  }, [gameState.settings.sound]);

  // Obtener el Pokémon actualmente inspeccionado en la Ficha de Pokémon
  const currentCardPokemon = useMemo(() => {
    if (!selectedCardPokemonUid) return null;
    return (
      gameState.team.find((p) => p.uid === selectedCardPokemonUid) ||
      gameState.pcBox.find((p) => p.uid === selectedCardPokemonUid) ||
      null
    );
  }, [selectedCardPokemonUid, gameState.team, gameState.pcBox]);

  // Movimiento pendiente actual en la cola
  const currentPendingMove = useMemo(() => {
    return gameState.pendingMoves && gameState.pendingMoves.length > 0
      ? gameState.pendingMoves[0]
      : null;
  }, [gameState.pendingMoves]);

  // Pokémon al que pertenece el movimiento pendiente
  const pendingTargetPokemon = useMemo(() => {
    if (!currentPendingMove) return null;
    return (
      gameState.team.find((p) => p.uid === currentPendingMove.pokemonUid) ||
      gameState.pcBox.find((p) => p.uid === currentPendingMove.pokemonUid) ||
      null
    );
  }, [currentPendingMove, gameState.team, gameState.pcBox]);

  // Selección de inicial al comenzar nueva partida (0 puntos y curación gratis sin bloqueo)
  const handleChooseStarter = (speciesId: number) => {
    const starterPokemon = createOwnedPokemon(speciesId, 5);

    const updatedPokedex = { ...gameState.pokedex };

    // Registrar inicial en Pokédex
    updatedPokedex[speciesId] = {
      seen: true,
      caught: true,
      count: 1,
      duplicates: 0,
    };

    setGameState((prev) => ({
      ...prev,
      player: {
        ...prev.player,
        starterChosen: true,
        starterId: speciesId,
      },
      team: [starterPokemon],
      pcBox: [],
      pokedex: updatedPokedex,
      zonePoints: {
        ...(prev.zonePoints || {}),
        'route-1': 0,
      },
      zoneVictories: {
        ...(prev.zoneVictories || {}),
        'route-1': 0,
      },
    }));
  };

  // Zonas desbloqueadas
  const unlockedZonesList = useMemo(() => {
    return KANTO_ZONES.filter((z) => gameState.unlockedZones.includes(z.id));
  }, [gameState.unlockedZones]);

  // Zona activa actual
  const activeZone = useMemo(() => {
    return ZONES_BY_ID[gameState.activeZoneId] || KANTO_ZONES[0];
  }, [gameState.activeZoneId]);

  // Manejo de victorias en expedición: incremento atómico de victorias de zona, puntos de ruta y EXP
  const handleEnemyDefeated = useCallback(
    (
      zoneId: string,
      expAwarded: number,
      updatedTeam: OwnedPokemon[],
      newPendingMoves?: PendingMoveLearning[]
    ) => {
      setGameState((prev) => {
        const currentZonePoints = prev.zonePoints[zoneId] || 0;
        const newPoints = currentZonePoints + 1; // +1 punto garantizado por enemigo
        const currentVictories = prev.zoneVictories[zoneId] || 0;
        const newVictories = currentVictories + 1; // Exactamente +1 victoria en contador de progreso de ruta

        const updatedVictories = {
          ...prev.zoneVictories,
          [zoneId]: newVictories,
        };

        // Evaluar desbloqueo de siguientes zonas respetando el árbol de rutas y requisitos
        const newlyUnlockedZones = evaluateAllUnlockedZones(
          prev.unlockedZones,
          updatedVictories,
          prev.badges
        );

        // Actualizar Pokédex si hubo evoluciones en el equipo
        const newPokedex = { ...prev.pokedex };
        let newEvolutionsCount = prev.stats.totalEvolutions;

        updatedTeam.forEach((member) => {
          if (!newPokedex[member.speciesId]) {
            newPokedex[member.speciesId] = {
              seen: true,
              caught: true,
              count: 1,
              duplicates: 0,
            };
            newEvolutionsCount += 1;
          }
        });

        // Cola de movimientos pendientes sin duplicaciones
        const existingPending = prev.pendingMoves || [];
        const toAdd = (newPendingMoves || []).filter(
          (npm) =>
            !existingPending.some(
              (ep) => ep.pokemonUid === npm.pokemonUid && ep.moveId === npm.moveId
            )
        );

        return {
          ...prev,
          zonePoints: {
            ...prev.zonePoints,
            [zoneId]: newPoints,
          },
          zoneVictories: updatedVictories,
          unlockedZones: newlyUnlockedZones,
          team: updatedTeam,
          pokedex: newPokedex,
          pendingMoves: [...existingPending, ...toAdd],
          stats: {
            ...prev.stats,
            totalVictories: prev.stats.totalVictories + 1,
            totalEvolutions: newEvolutionsCount,
          },
        };
      });
    },
    []
  );

  // Apertura de Sobres (3 o 5 cartas) con Colección Única por Especie y Repetidos como Copias
  // Comprar sobres descuenta zonePoints pero NUNCA reduce zoneVictories
  const handleOpenPack = (
    zone: ZoneData,
    count: 3 | 5,
    cost: number,
    tableType: 'standard' | 'blue' | 'fishing' | 'surf'
  ) => {
    const currentPoints = gameState.zonePoints[zone.id] || 0;
    if (![3, 5].includes(count) || cost !== count * 10 || currentPoints < cost) return;

    const cap = getLevelCap(gameState.badges).cap;

    // Determinar tabla a sortear
    let table = zone.encounterTable;
    let packTitle = `Sobre Rojo · ${zone.name}`;

    if (tableType === 'blue' && zone.blueAlternateTable) {
      table = zone.blueAlternateTable;
      packTitle = `Sobre Azul · ${zone.name}`;
    } else if (tableType === 'fishing' && zone.fishingTable) {
      table =
        zone.fishingTable.superRod ||
        zone.fishingTable.goodRod ||
        zone.fishingTable.oldRod ||
        zone.encounterTable;
      packTitle = `Sobre de Pesca · ${zone.name}`;
    } else if (tableType === 'surf' && zone.surfTable) {
      table = zone.surfTable;
      packTitle = `Sobre de Surf · ${zone.name}`;
    }

    // Sorteo independiente para cada carta
    const drawnResults: DrawnCardResult[] = [];

    setGameState((prev) => {
      const updatedTeam = prev.team.map((p) => ({ ...p }));
      const updatedBox = prev.pcBox.map((p) => ({ ...p }));
      const updatedPokedex = { ...prev.pokedex };

      for (let i = 0; i < count; i++) {
        const rolled = rollFromEncounterTable(table);
        const speciesId = rolled.speciesId;
        const shinyRoll = Math.random() < 1 / 1024;
        // Limitar nivel inicial al tope por medallas
        const initialLevel = Math.min(rolled.level, cap);

        // Buscar si ya existe un ejemplar de esta especie en el equipo o en la caja
        const existingInTeam = updatedTeam.find((p) => p.speciesId === speciesId);
        const existingInBox = updatedBox.find((p) => p.speciesId === speciesId);
        const existing = existingInTeam || existingInBox;

        if (existing) {
          // REPETIDO: Nunca crea un nuevo ejemplar. Se acumula como copia de mejora sin reiniciar movimientos.
          existing.isShiny = existing.isShiny || shinyRoll;
          existing.upgradeCopies += 1;
          existing.totalDuplicates += 1;

          if (updatedPokedex[speciesId]) {
            updatedPokedex[speciesId] = {
              ...updatedPokedex[speciesId],
              count: updatedPokedex[speciesId].count + 1,
              duplicates: updatedPokedex[speciesId].duplicates + 1,
            };
          }

          drawnResults.push({
            speciesId,
            level: initialLevel,
            isNew: false,
            newBalance: existing.upgradeCopies,
            isShiny: existing.isShiny,
          });
        } else {
          // NUEVO: Crea el único ejemplar de esta especie con IVs en 0 y copias en 0
          const newPoke = { ...createOwnedPokemon(speciesId, initialLevel), isShiny: shinyRoll };
          updatedBox.push(newPoke);

          updatedPokedex[speciesId] = {
            seen: true,
            caught: true,
            count: 1,
            duplicates: 0,
          };

          drawnResults.push({
            speciesId,
            level: initialLevel,
            isNew: true,
            newBalance: 0,
            newPokemon: newPoke,
            isShiny: newPoke.isShiny,
          });
        }
      }

      return {
        ...prev,
        zonePoints: {
          ...prev.zonePoints,
          [zone.id]: (prev.zonePoints[zone.id] || 0) - cost,
        },
        team: updatedTeam,
        pcBox: updatedBox,
        pokedex: updatedPokedex,
        stats: {
          ...prev.stats,
          totalPacksOpened: prev.stats.totalPacksOpened + 1,
          totalCardsDrawn: prev.stats.totalCardsDrawn + count,
        },
      };
    });

    // Abrir modal animado con revelación
    setActivePackOpening({
      isOpen: true,
      packName: packTitle,
      cards: drawnResults,
    });
  };

  // Añadir al equipo directamente desde la apertura de sobres
  const handleAddToTeamFromPack = (poke: OwnedPokemon) => {
    if (gameState.team.length >= 6) return;
    if (gameState.team.some((p) => p.speciesId === poke.speciesId)) return;

    setGameState((prev) => ({
      ...prev,
      team: [...prev.team, poke],
      pcBox: prev.pcBox.filter((p) => p.uid !== poke.uid),
    }));
  };

  // Mejora manual de IV individual: coste incremental = 2 * IVactual + 1 (Tope: 31)
  const handleUpgradeIv = (pokemonUid: string, statKey: StatKey) => {
    setGameState((prev) => {
      let found = false;

      const updatePokemon = (p: OwnedPokemon): OwnedPokemon => {
        if (p.uid !== pokemonUid) return p;

        const currentIv = p.ivs[statKey];
        if (currentIv >= 31) return p;

        const cost = getNextIvCost(currentIv);
        if (p.upgradeCopies < cost) return p;

        found = true;

        const newIvs = {
          ...p.ivs,
          [statKey]: currentIv + 1,
        };

        const updated = recalculatePokemonStats({
          ...p,
          ivs: newIvs,
          upgradeCopies: p.upgradeCopies - cost,
        });

        return updated;
      };

      const newTeam = prev.team.map(updatePokemon);
      const newBox = prev.pcBox.map(updatePokemon);

      if (!found) return prev;

      return {
        ...prev,
        team: newTeam,
        pcBox: newBox,
        stats: {
          ...prev.stats,
          totalIvUpgrades: (prev.stats.totalIvUpgrades || 0) + 1,
        },
      };
    });
  };

  // Evolución manual (nivel, piedra o cable link)
  const handleEvolvePokemon = (
    pokemonUid: string,
    targetSpeciesId: number,
    consumedItem?: string
  ) => {
    const targetSpecies = POKEMON_BY_ID[targetSpeciesId];
    if (!targetSpecies) return;

    retroAudio.playFanfare();

    setGameState((prev) => {
      const updatedItems = { ...prev.items };
      const updatedInventory = { ...(prev.inventory || {}) };

      if (consumedItem) {
        if (updatedInventory[consumedItem] && updatedInventory[consumedItem] > 0) {
          updatedInventory[consumedItem] -= 1;
        } else if (updatedItems[consumedItem] && updatedItems[consumedItem] > 0) {
          updatedItems[consumedItem] -= 1;
        }
      }

      // Buscar el Pokémon origen
      const sourcePoke =
        prev.team.find((p) => p.uid === pokemonUid) ||
        prev.pcBox.find((p) => p.uid === pokemonUid);

      if (!sourcePoke) return prev;

      // Comprobar si ya existe un ejemplar de la especie destino
      const existingTarget =
        prev.team.find((p) => p.speciesId === targetSpeciesId) ||
        prev.pcBox.find((p) => p.speciesId === targetSpeciesId);

      let finalTeam = [...prev.team];
      let finalBox = [...prev.pcBox];

      if (existingTarget) {
        // CONSOLIDAR
        const consolidatedIvs = {
          hp: Math.max(sourcePoke.ivs.hp, existingTarget.ivs.hp),
          attack: Math.max(sourcePoke.ivs.attack, existingTarget.ivs.attack),
          defense: Math.max(sourcePoke.ivs.defense, existingTarget.ivs.defense),
          spAtk: Math.max(sourcePoke.ivs.spAtk, existingTarget.ivs.spAtk),
          spDef: Math.max(sourcePoke.ivs.spDef, existingTarget.ivs.spDef),
          speed: Math.max(sourcePoke.ivs.speed, existingTarget.ivs.speed),
        };

        const bestLevel = Math.max(sourcePoke.level, existingTarget.level);
        const bestExp = Math.max(sourcePoke.exp, existingTarget.exp);
        const combinedCopies = sourcePoke.upgradeCopies + existingTarget.upgradeCopies;
        const combinedDuplicates = sourcePoke.totalDuplicates + existingTarget.totalDuplicates;

        // Equipamiento: Si el destino no tiene objeto y el origen sí, mantenerlo.
        // Si ambos tenían objeto, devolver el del origen al inventario.
        let finalHeldItem = existingTarget.heldItem;
        if (!finalHeldItem && sourcePoke.heldItem) {
          finalHeldItem = sourcePoke.heldItem;
        } else if (finalHeldItem && sourcePoke.heldItem) {
          updatedInventory[sourcePoke.heldItem] =
            (updatedInventory[sourcePoke.heldItem] || 0) + 1;
        }

        const consolidated = recalculatePokemonStats({
          ...existingTarget,
          level: bestLevel,
          exp: bestExp,
          ivs: consolidatedIvs,
          isShiny: sourcePoke.isShiny || existingTarget.isShiny,
          taughtMoves: [...new Set([...(sourcePoke.taughtMoves || []), ...(existingTarget.taughtMoves || [])])],
          upgradeCopies: combinedCopies,
          totalDuplicates: combinedDuplicates,
          heldItem: finalHeldItem,
        });

        finalTeam = finalTeam.filter((p) => p.uid !== sourcePoke.uid);
        finalBox = finalBox.filter((p) => p.uid !== sourcePoke.uid);

        finalTeam = finalTeam.map((p) => (p.uid === existingTarget.uid ? consolidated : p));
        finalBox = finalBox.map((p) => (p.uid === existingTarget.uid ? consolidated : p));
      } else {
        // TRANSFORMAR DIRECTO
        const evolvedPoke = recalculatePokemonStats({
          ...sourcePoke,
          speciesId: targetSpeciesId,
          nickname: targetSpecies.name,
        });

        finalTeam = finalTeam.map((p) => (p.uid === sourcePoke.uid ? evolvedPoke : p));
        finalBox = finalBox.map((p) => (p.uid === sourcePoke.uid ? evolvedPoke : p));
      }

      // Registrar especie destino en Pokédex
      const updatedPokedex = { ...prev.pokedex };
      if (!updatedPokedex[targetSpeciesId]) {
        updatedPokedex[targetSpeciesId] = {
          seen: true,
          caught: true,
          count: 1,
          duplicates: 0,
        };
      } else {
        updatedPokedex[targetSpeciesId].caught = true;
      }

      return {
        ...prev,
        items: updatedItems,
        inventory: updatedInventory,
        team: finalTeam,
        pcBox: finalBox,
        pokedex: updatedPokedex,
        stats: {
          ...prev.stats,
          totalEvolutions: prev.stats.totalEvolutions + 1,
        },
      };
    });
  };

  // Alias para evolución desde ficha modal con objeto de tienda/inventario
  const handleEvolveWithItem = (
    pokemonUid: string,
    targetSpeciesId: number,
    itemId: string
  ) => {
    handleEvolvePokemon(pokemonUid, targetSpeciesId, itemId);
  };

  // Comprar objeto en la Tienda de Fichas (compra atómica sin saldo negativo)
  const handleBuyShopItem = (item: ShopItem) => {
    setGameState((prev) => {
      const currentTokens = prev.trainerTokens || 0;
      if (currentTokens < item.cost) return prev;

      const currentInventory = { ...(prev.inventory || {}) };
      currentInventory[item.id] = (currentInventory[item.id] || 0) + 1;

      return {
        ...prev,
        trainerTokens: currentTokens - item.cost,
        inventory: currentInventory,
      };
    });
  };

  // Equipar objeto de combate (1 objeto por Pokémon, desequipar devuelve unidad al inventario)
  const handleEquipItem = (pokemonUid: string, itemId: string) => {
    setGameState((prev) => {
      const currentInventory = { ...(prev.inventory || {}) };
      const count = currentInventory[itemId] || 0;
      if (count <= 0) return prev;

      const updatePoke = (p: OwnedPokemon) => {
        if (p.uid !== pokemonUid) return p;
        if (p.heldItem) {
          // Devolver el objeto anterior al inventario
          currentInventory[p.heldItem] = (currentInventory[p.heldItem] || 0) + 1;
        }
        return {
          ...p,
          heldItem: itemId,
        };
      };

      const newTeam = prev.team.map(updatePoke);
      const newBox = prev.pcBox.map(updatePoke);
      currentInventory[itemId] = count - 1;

      return {
        ...prev,
        team: newTeam,
        pcBox: newBox,
        inventory: currentInventory,
      };
    });
  };

  // Desequipar objeto de combate (devuelve unidad al inventario)
  const handleUnequipItem = (pokemonUid: string) => {
    setGameState((prev) => {
      const target =
        prev.team.find((p) => p.uid === pokemonUid) ||
        prev.pcBox.find((p) => p.uid === pokemonUid);
      if (!target || !target.heldItem) return prev;

      const heldId = target.heldItem;
      const currentInventory = { ...(prev.inventory || {}) };
      currentInventory[heldId] = (currentInventory[heldId] || 0) + 1;

      const updatePoke = (p: OwnedPokemon) => {
        if (p.uid !== pokemonUid) return p;
        return {
          ...p,
          heldItem: null,
        };
      };

      return {
        ...prev,
        team: prev.team.map(updatePoke),
        pcBox: prev.pcBox.map(updatePoke),
        inventory: currentInventory,
      };
    });
  };

  // Derrotar a un entrenador rival (Fichas de entrenador)
  const handleDefeatTrainer = (trainerId: string, tokens: number) => {
    setGameState((prev) => {
      const alreadyDefeated = prev.completedTrainers?.includes(trainerId);
      const newCompleted = alreadyDefeated
        ? prev.completedTrainers
        : [...(prev.completedTrainers || []), trainerId];
      // Recompensa 1 vez por intento sin duplicados; repeticiones no dan premio gratis
      const tokenReward = tokens;

      return {
        ...prev,
        trainerTokens: (prev.trainerTokens || 0) + tokenReward,
        completedTrainers: newCompleted,
      };
    });
  };

  // Superar reto especial (Doble tras Brock, Triple tras Surge)
  const handleCompleteTrial = (trialId: 'double_trial' | 'triple_trial') => {
    setGameState((prev) => {
      const completedTrials = prev.completedTrials || [];
      if (completedTrials.includes(trialId)) return prev;

      const newTrials = [...completedTrials, trialId];
      const isDouble = trialId === 'double_trial';
      const isTriple = trialId === 'triple_trial';

      return {
        ...prev,
        completedTrials: newTrials,
        unlockedDoubleBattle: isDouble ? true : prev.unlockedDoubleBattle,
        unlockedTripleBattle: isTriple ? true : prev.unlockedTripleBattle,
        activeLaneCount:
          isDouble && prev.activeLaneCount < 2
            ? 2
            : isTriple && prev.activeLaneCount < 3
            ? 3
            : prev.activeLaneCount,
      };
    });
  };

  // Usar Caramelo Raro universal (+1 Nivel). Bloqueado si el Pokémon ya está en el tope de medallas
  const handleUseRareCandy = (uid: string) => {
    if (gameState.oakCandies < 1) return;
    const cap = getLevelCap(gameState.badges).cap;

    const targetPoke =
      gameState.team.find((p) => p.uid === uid) ||
      gameState.pcBox.find((p) => p.uid === uid);

    if (!targetPoke || targetPoke.level >= cap || targetPoke.level >= 100) {
      retroAudio.playClick();
      return; // Bloqueado por tope de medallas: el caramelo NO se consume
    }

    retroAudio.playLevelUp();

    setGameState((prev) => {
      const pendingMovesToAdd: PendingMoveLearning[] = [];

      const updatePoke = (p: OwnedPokemon) => {
        if (p.uid !== uid || p.level >= cap || p.level >= 100) return p;
        const newLvl = p.level + 1;

        // Comprobar si aprende nuevo movimiento en este nivel
        const speciesLearnset = SPECIES_LEARNSETS[p.speciesId] || [];
        const learned = speciesLearnset.filter((m) => m.level === newLvl);
        for (const lm of learned) {
          if (!p.equippedMoves?.includes(lm.moveId)) {
            pendingMovesToAdd.push({
              pokemonUid: p.uid,
              pokemonName: p.nickname || POKEMON_BY_ID[p.speciesId]?.name || 'Pokémon',
              speciesId: p.speciesId,
              moveId: lm.moveId,
            });
          }
        }

        return recalculatePokemonStats({
          ...p,
          level: newLvl,
          exp: 0,
        });
      };

      const newTeam = prev.team.map(updatePoke);
      const newBox = prev.pcBox.map(updatePoke);
      const currentPending = prev.pendingMoves || [];

      return {
        ...prev,
        oakCandies: prev.oakCandies - 1,
        team: newTeam,
        pcBox: newBox,
        pendingMoves: [...currentPending, ...pendingMovesToAdd],
      };
    });
  };

  // Derrotar a un líder de gimnasio
  const handleDefeatGym = (gym: GymLeader) => {
    setGameState((prev) => {
      const newDefeated = prev.defeatedGyms.includes(gym.id)
        ? prev.defeatedGyms
        : [...prev.defeatedGyms, gym.id];
      const newBadges = prev.badges.includes(gym.badge)
        ? prev.badges
        : [...prev.badges, gym.badge];

      // Evaluar nuevas rutas desbloqueadas con la nueva medalla
      const newUnlockedZones = evaluateAllUnlockedZones(
        prev.unlockedZones,
        prev.zoneVictories,
        newBadges
      );

      const newItems = { ...prev.items };
      if (gym.rewardItem) {
        newItems[gym.rewardItem.id] = (newItems[gym.rewardItem.id] || 0) + gym.rewardItem.count;
      }

      return {
        ...prev,
        defeatedGyms: newDefeated,
        badges: newBadges,
        unlockedZones: newUnlockedZones,
        items: newItems,
      };
    });
  };

  // Reclamar recompensa de misión de historia
  const handleClaimMissionReward = (mission: StoryMission) => {
    if (gameState.completedMissions.includes(mission.id)) return;
    if (mission.requiresNoSpecies && [...gameState.team, ...gameState.pcBox].some(p => p.speciesId === mission.requiresNoSpecies)) return;
    if (mission.badgeRequired && !gameState.badges.includes(mission.badgeRequired)) return;
    if (mission.zoneRequired && !gameState.unlockedZones.includes(mission.zoneRequired)) return;
    if (mission.pointsRequired && (gameState.zonePoints[mission.pointsRequired.zoneId] || 0) < mission.pointsRequired.amount) return;

    retroAudio.playFanfare();
    const cap = getLevelCap(gameState.badges).cap;

    setGameState((prev) => {
      const newCompleted = [...prev.completedMissions, mission.id];
      const updatedPokedex = { ...prev.pokedex };
      const updatedTeam = [...prev.team];
      const updatedBox = [...prev.pcBox];

      if (mission.reward.speciesId) {
        const specId = mission.reward.speciesId;
        const existing =
          updatedTeam.find((p) => p.speciesId === specId) ||
          updatedBox.find((p) => p.speciesId === specId);

        if (existing) {

          existing.upgradeCopies += 1;
          existing.totalDuplicates += 1;
        } else {
          const rewardLevel = Math.min(mission.reward.level || 15, cap);
          const giftPoke = createOwnedPokemon(specId, rewardLevel);
          if (updatedTeam.length < 6) {
            updatedTeam.push(giftPoke);
          } else {
            updatedBox.push(giftPoke);
          }
        }

        if (!updatedPokedex[specId]) {
          updatedPokedex[specId] = {
            seen: true,
            caught: true,
            count: 1,
            duplicates: 0,
          };
        } else {
          updatedPokedex[specId].count += 1;
        }
      }

      return {
        ...prev,
        completedMissions: newCompleted,
        team: updatedTeam,
        pcBox: updatedBox,
        pokedex: updatedPokedex,
      };
    });
  };

  // Curar equipo completamente (restaura PS y limpia estados alterados)
  const handleHealTeam = () => {
    setGameState((prev) => ({
      ...prev,
      team: prev.team.map((p) => ({ ...p, currentHp: p.maxHp, status: null, sleepTurns: 0 })),
    }));
  };

  // Actualizar movimientos equipados de un Pokémon
  const handleUpdateMoves = (pokemonUid: string, moves: string[]) => {
    setGameState((prev) => {
      const updatePoke = (p: OwnedPokemon) =>
        p.uid === pokemonUid ? { ...p, equippedMoves: moves } : p;
      return {
        ...prev,
        team: prev.team.map(updatePoke),
        pcBox: prev.pcBox.map(updatePoke),
      };
    });
  };

  // Gestión de cola de movimientos pendientes (Regla C)
  const handleEquipInFreeSlot = (pokemonUid: string, moveId: string) => {
    setGameState((prev) => {
      const updatePoke = (p: OwnedPokemon) => {
        if (p.uid !== pokemonUid) return p;
        const currentEquipped = p.equippedMoves || ['placaje'];
        if (currentEquipped.includes(moveId) || currentEquipped.length >= 4) return p;
        return {
          ...p,
          equippedMoves: [...currentEquipped, moveId],
        };
      };

      const remainingPending = (prev.pendingMoves || []).filter(
        (pm) => !(pm.pokemonUid === pokemonUid && pm.moveId === moveId)
      );

      return {
        ...prev,
        team: prev.team.map(updatePoke),
        pcBox: prev.pcBox.map(updatePoke),
        pendingMoves: remainingPending,
      };
    });

    // Si no quedan más movimientos pendientes, cerrar modal
    if ((gameState.pendingMoves?.length || 0) <= 1) {
      setIsMoveLearningOpen(false);
    }
  };

  const handleReplacePendingMove = (pokemonUid: string, slotIndex: number, newMoveId: string) => {
    setGameState((prev) => {
      const updatePoke = (p: OwnedPokemon) => {
        if (p.uid !== pokemonUid) return p;
        const currentEquipped = [...(p.equippedMoves || ['placaje'])];
        currentEquipped[slotIndex] = newMoveId;
        return {
          ...p,
          equippedMoves: currentEquipped,
        };
      };

      const remainingPending = (prev.pendingMoves || []).filter(
        (pm, idx) => idx !== 0
      );

      return {
        ...prev,
        team: prev.team.map(updatePoke),
        pcBox: prev.pcBox.map(updatePoke),
        pendingMoves: remainingPending,
      };
    });

    if ((gameState.pendingMoves?.length || 0) <= 1) {
      setIsMoveLearningOpen(false);
    }
  };

  const handleDismissPendingMove = () => {
    setGameState((prev) => ({
      ...prev,
      pendingMoves: (prev.pendingMoves || []).slice(1),
    }));

    if ((gameState.pendingMoves?.length || 0) <= 1) {
      setIsMoveLearningOpen(false);
    }
  };

  // Reiniciar partida
  const handleResetGame = () => {
    retroAudio.playClick();
    const fresh = getDefaultSave();
    setGameState(fresh);
    saveGame(fresh);
  };

  return (
    <div className="min-h-screen bg-[#f6f2e8] flex flex-col font-['Plus_Jakarta_Sans']">
      {/* Barra de Navegación */}
      <Navbar
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        activeZoneId={gameState.activeZoneId}
        activeZonePoints={gameState.zonePoints[gameState.activeZoneId] || 0}
        trainerTokens={gameState.trainerTokens || 0}
        soundEnabled={gameState.settings.sound}
        onToggleSound={() => {
          setGameState((prev) => ({
            ...prev,
            settings: { ...prev.settings, sound: !prev.settings.sound },
          }));
        }}
        onOpenSettings={() => setIsSettingsOpen(true)}
        teamCount={gameState.team.length}
      />

      {/* Indicador no intrusivo si hay movimientos pendientes por aprender */}
      {gameState.pendingMoves && gameState.pendingMoves.length > 0 && (
        <div className="bg-[#fef5e7] border-b border-[#d89b25]/40 px-3 sm:px-6 py-2 flex items-center justify-between text-xs shadow-2xs">
          <div className="flex items-center gap-2">
            <Swords className="w-4 h-4 text-[#d89b25] shrink-0" />
            <span className="text-[#1a3d2f] font-medium">
              Hay <strong>{gameState.pendingMoves.length}</strong> movimiento(s) nuevo(s) por
              aprender en tu equipo.
            </span>
          </div>
          <button
            type="button"
            onClick={() => setIsMoveLearningOpen(true)}
            className="px-3 py-1 bg-[#d89b25] hover:bg-[#be861e] active:bg-[#a67417] text-white font-bold rounded-lg text-xs transition-colors cursor-pointer shrink-0"
          >
            Gestionar
          </button>
        </div>
      )}

      {/* Pantalla Principal según Pestaña Activa */}
      <main className="flex-1 pb-12">
        {currentTab === 'expedition' && (
          <ExpeditionScreen
            zone={activeZone}
            team={gameState.team}
            zonePoints={gameState.zonePoints[activeZone.id] || 0}
            zoneVictories={gameState.zoneVictories[activeZone.id] || 0}
            badges={gameState.badges}
            battlePaused={gameState.settings.battlePaused}
            unlockedDoubleBattle={gameState.unlockedDoubleBattle}
            unlockedTripleBattle={gameState.unlockedTripleBattle}
            activeLaneCount={gameState.activeLaneCount || 1}
            onSetLaneCount={(count) => {
              setGameState((prev) => ({ ...prev, activeLaneCount: count }));
            }}
            onTogglePause={() => {
              retroAudio.playClick();
              setGameState((prev) => ({
                ...prev,
                settings: {
                  ...prev.settings,
                  battlePaused: !prev.settings.battlePaused,
                },
              }));
            }}
            onEnemyDefeated={handleEnemyDefeated}
            onUpdateTeam={(updatedTeam) => {
              setGameState((prev) => ({ ...prev, team: updatedTeam }));
            }}
            onGoToPacks={() => setCurrentTab('packs')}
            onGoToMap={() => setCurrentTab('map')}
          />
        )}

        {currentTab === 'packs' && (
          <PacksScreen
            unlockedZones={unlockedZonesList}
            zonePoints={gameState.zonePoints}
            activeZoneId={gameState.activeZoneId}
            items={gameState.items}
            onOpenPack={handleOpenPack}
            onSelectZoneToExplore={(zoneId) => {
              setGameState((prev) => ({ ...prev, activeZoneId: zoneId }));
              setCurrentTab('expedition');
            }}
          />
        )}

        {currentTab === 'pokedex' && (
          <PokedexScreen
            pokedex={gameState.pokedex}
            oakCandies={gameState.oakCandies || 0}
            items={{ ...(gameState.items || {}), ...(gameState.inventory || {}) }}
            team={gameState.team}
            pcBox={gameState.pcBox}
            onOpenCardModal={(poke) => setSelectedCardPokemonUid(poke.uid)}
            onEvolvePokemon={handleEvolvePokemon}
          />
        )}

        {currentTab === 'team' && (
          <TeamScreen
            team={gameState.team}
            pcBox={gameState.pcBox}
            oakCandies={gameState.oakCandies || 0}
            badges={gameState.badges}
            pendingMovesCount={gameState.pendingMoves?.length || 0}
            onOpenPendingMoves={() => setIsMoveLearningOpen(true)}
            onReorderTeam={(newTeam) => {
              setGameState((prev) => ({ ...prev, team: newTeam }));
            }}
            onSendToBox={(uid) => {
              retroAudio.playClick();
              setGameState((prev) => {
                const poke = prev.team.find((p) => p.uid === uid);
                if (!poke) return prev;
                return {
                  ...prev,
                  team: prev.team.filter((p) => p.uid !== uid),
                  pcBox: [...prev.pcBox, poke],
                };
              });
            }}
            onAddToTeamFromBox={(uid) => {
              retroAudio.playClick();
              setGameState((prev) => {
                if (prev.team.length >= 6) return prev;
                const poke = prev.pcBox.find((p) => p.uid === uid);
                if (!poke) return prev;
                // Impedir duplicados en el equipo
                if (prev.team.some((t) => t.speciesId === poke.speciesId)) return prev;

                return {
                  ...prev,
                  pcBox: prev.pcBox.filter((p) => p.uid !== uid),
                  team: [...prev.team, poke],
                };
              });
            }}
            onUseRareCandy={handleUseRareCandy}
            onHealTeam={handleHealTeam}
            onOpenCardModal={(poke) => setSelectedCardPokemonUid(poke.uid)}
          />
        )}

        {currentTab === 'gyms' && (
          <GymsScreen
            ownedSpecies={[...gameState.team, ...gameState.pcBox].map(p => p.speciesId)}
            defeatedGyms={gameState.defeatedGyms}
            badges={gameState.badges}
            unlockedZones={gameState.unlockedZones}
            completedMissions={gameState.completedMissions}
            zonePoints={gameState.zonePoints}
            team={gameState.team}
            onDefeatGym={handleDefeatGym}
            onClaimMissionReward={handleClaimMissionReward}
          />
        )}

        {currentTab === 'trainers' && <KantoObjectives save={gameState} update={setGameState} />}
        {currentTab === 'trainers' && (
          <TrainersScreen
            save={gameState}
            team={gameState.team}
            onDefeatTrainer={handleDefeatTrainer}
            onCompleteTrial={handleCompleteTrial}
            onGoToShop={() => setCurrentTab('shop')}
          />
        )}

        {currentTab === 'shop' && (
          <ShopScreen
            trainerTokens={gameState.trainerTokens || 0}
            inventory={gameState.inventory || {}}
            badges={gameState.badges}
            onBuyItem={handleBuyShopItem}
            onGoToTrainers={() => setCurrentTab('trainers')}
          />
        )}

        {currentTab === 'map' && (
          <MapScreen
            unlockedZones={gameState.unlockedZones}
            activeZoneId={gameState.activeZoneId}
            zonePoints={gameState.zonePoints}
            zoneVictories={gameState.zoneVictories}
            badges={gameState.badges}
            onSelectZone={(zoneId) => {
              setGameState((prev) => ({ ...prev, activeZoneId: zoneId }));
              setCurrentTab('expedition');
            }}
            onGoToPacks={() => setCurrentTab('packs')}
            onGoToGyms={() => setCurrentTab('gyms')}
          />
        )}
      </main>

      {/* Modal de Selección de Inicial para Nuevas Partidas */}
      <StarterModal
        isOpen={!gameState.player.starterChosen}
        onChooseStarter={handleChooseStarter}
      />

      {/* Modal de Apertura Animada de Sobres (Distingue NUEVO de REPETIDO) */}
      <PackOpeningModal
        isOpen={activePackOpening.isOpen}
        packName={activePackOpening.packName}
        cards={activePackOpening.cards}
        teamCount={gameState.team.length}
        onAddToTeam={handleAddToTeamFromPack}
        onClose={() => setActivePackOpening({ isOpen: false, packName: '', cards: [] })}
      />

      {/* Modal Ficha de Pokémon (6 Estadísticas, IVs 0-31, Movimientos equipables, Objetos y Evolución) */}
      <PokemonCardModal
        isOpen={Boolean(currentCardPokemon)}
        pokemon={currentCardPokemon}
        badges={gameState.badges}
        inventory={gameState.inventory || {}}
        onClose={() => setSelectedCardPokemonUid(null)}
        onUpgradeIv={handleUpgradeIv}
        onUpdateMoves={handleUpdateMoves}
        onEvolveWithItem={handleEvolveWithItem}
        onEquipItem={handleEquipItem}
        onUnequipItem={handleUnequipItem}
        isCombatActive={currentTab === 'expedition' && !gameState.settings.battlePaused}
      />

      {/* Modal de Aprendizaje / Reemplazo de Movimientos */}
      <MoveLearningModal
        isOpen={isMoveLearningOpen && Boolean(currentPendingMove && pendingTargetPokemon)}
        pendingMove={currentPendingMove}
        totalPendingCount={gameState.pendingMoves?.length || 0}
        pokemon={pendingTargetPokemon}
        onEquipInFreeSlot={handleEquipInFreeSlot}
        onReplaceMove={handleReplacePendingMove}
        onDismiss={handleDismissPendingMove}
      />

      {/* Modal de Ajustes, Guardado y Exportar/Importar */}
      <SettingsModal
        isOpen={isSettingsOpen}
        gameState={gameState}
        onClose={() => setIsSettingsOpen(false)}
        onUpdateState={(newState) => setGameState(newState)}
        onResetGame={handleResetGame}
      />
    </div>
  );
}



