import { ZoneImage } from './ZoneImage';
import React from 'react';
import {
  MapPin,
  Lock,
  CheckCircle,
  Sparkles,
  Compass,
  ChevronRight,
  Award,
  Swords,
  Trophy,
} from 'lucide-react';
import { ZoneData } from '../types/pokemon';
import { KANTO_ZONES, ZONES_BY_ID } from '../data/zones';
import { KANTO_GYMS } from '../data/gymsAndMissions';
import { getLevelCap } from '../utils/levelCaps';
import { retroAudio } from '../utils/audio';

interface MapScreenProps {
  unlockedZones: string[];
  activeZoneId: string;
  zonePoints: Record<string, number>;
  zoneVictories: Record<string, number>;
  badges: string[];
  onSelectZone: (zoneId: string) => void;
  onGoToPacks: () => void;
  onGoToGyms?: () => void;
}

export const MapScreen: React.FC<MapScreenProps> = ({
  unlockedZones,
  activeZoneId,
  zonePoints,
  zoneVictories,
  badges,
  onSelectZone,
  onGoToPacks,
  onGoToGyms,
}) => {
  const capInfo = getLevelCap(badges);

  const handleZoneClick = (zoneId: string) => {
    retroAudio.playClick();
    onSelectZone(zoneId);
  };

  const handleGymClick = () => {
    retroAudio.playClick();
    if (onGoToGyms) {
      onGoToGyms();
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-3 sm:px-6 py-4 flex flex-col gap-5 text-[#1c2e24]">
      {/* Cabecera del Mapa */}
      <div className="bg-[#ede4cf] border-2 border-[#1a3d2f]/30 rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#d44f33]">
            Geografía y Conexiones de Kanto
          </span>
          <h1 className="text-lg sm:text-xl font-bold font-['Plus_Jakarta_Sans'] text-[#1a3d2f]">
            Mapa Regional de Rutas y Ciudades
          </h1>
          <p className="text-xs sm:text-sm text-[#415a4d] mt-1">
            Consigue victorias en cada ruta para desbloquear el paso al siguiente destino y sus
            gimnasios.
          </p>
        </div>

        {/* Resumen de Medallas y Límite de Nivel (Regla D) */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
          <div className="flex items-center gap-1.5 bg-[#f6f2e8] border border-[#2d5a43]/20 px-3 py-1.5 rounded-lg text-xs font-mono">
            <Trophy className="w-3.5 h-3.5 text-[#d89b25]" />
            <span className="text-[#556b5f]">Medallas:</span>
            <span className="font-['Press_Start_2P'] text-[10px] text-[#2d5a43]">
              {badges.filter((b) => b !== 'champion_ribbon').length}/8
            </span>
          </div>

          <div className="flex items-center gap-1.5 bg-[#f6f2e8] border border-[#2d5a43]/20 px-3 py-1.5 rounded-lg text-xs font-mono">
            <Award className="w-3.5 h-3.5 text-[#d89b25]" />
            <span className="text-[#556b5f]">Tope Nivel:</span>
            <strong className="text-[#1a3d2f]">Nv.{capInfo.cap}</strong>
            {!capInfo.isMax && (
              <span className="text-[10px] text-[#556b5f]">({capInfo.nextLeaderName})</span>
            )}
          </div>
        </div>
      </div>

      {/* Cuadrícula de Zonas y Rutas con Línea Temporal Conectada */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {KANTO_ZONES.map((zone) => {
          const isUnlocked = unlockedZones.includes(zone.id);
          const isCurrentActive = activeZoneId === zone.id;
          const currentPoints = zonePoints[zone.id] || 0;
          const currentVictories = zoneVictories[zone.id] || 0;
          const targetVictories = zone.requiredVictories || 10;
          const isCompleted = currentVictories >= targetVictories;
          const nextZone = zone.nextZoneId ? ZONES_BY_ID[zone.nextZoneId] : null;

          // Buscar si hay un gimnasio en esta zona
          const zoneGym = KANTO_GYMS.find((g) => g.cityZoneId === zone.id);

          return (
            <div
              key={zone.id}
              className={`rounded-xl border-2 p-4 flex flex-col justify-between gap-3 transition-all ${
                isCurrentActive
                  ? 'bg-[#f6f2e8] border-[#1a3d2f] ring-2 ring-[#2d5a43]/30 shadow-md'
                  : isUnlocked
                  ? 'bg-[#ede4cf] border-[#1a3d2f]/25 hover:border-[#1a3d2f]/60 hover:bg-[#ede4cf]/90 shadow-2xs'
                  : 'bg-[#ded1b5]/50 border-dashed border-[#c8bc9f] opacity-60'
              }`}
            >
              <div>
                <ZoneImage zone={zone} compact />
              {/* Cabecera de la tarjeta */}
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-md bg-[#1a3d2f] text-[#f4ecd8] text-xs font-bold flex items-center justify-center shrink-0">
                      {zone.order}
                    </span>
                    <div>
                      <h2 className="font-bold text-sm text-[#1a3d2f] leading-snug">{zone.name}</h2>
                      <span className="text-[10px] text-[#556b5f] line-clamp-1">
                        {zone.subtitle}
                      </span>
                    </div>
                  </div>

                  {isCurrentActive ? (
                    <span className="text-[9px] font-['Press_Start_2P'] text-[#2d5a43] bg-[#d8ecd8] px-1.5 py-0.5 rounded">
                      ACTIVA
                    </span>
                  ) : isUnlocked ? (
                    isCompleted ? (
                      <span className="text-[10px] text-[#2d5a43] font-bold flex items-center gap-1 bg-[#d8ecd8] px-2 py-0.5 rounded">
                        <CheckCircle className="w-3 h-3" />
                        <span>Completada</span>
                      </span>
                    ) : (
                      <span className="text-[10px] text-[#2d5a43] font-semibold flex items-center gap-1 bg-[#f6f2e8] px-2 py-0.5 rounded border border-[#2d5a43]/20">
                        <span>Disponible</span>
                      </span>
                    )
                  ) : (
                    <span className="text-[10px] text-[#8a8a79] flex items-center gap-1 bg-[#ded1b5] px-2 py-0.5 rounded">
                      <Lock className="w-3 h-3" />
                      <span>Bloqueada</span>
                    </span>
                  )}
                </div>

                <p className="text-xs text-[#415a4d] mt-2 line-clamp-2">{zone.description}</p>

                {/* Barra de Victorias / Progreso de Ruta (Regla B) */}
                {isUnlocked && (
                  <div className="mt-3 bg-[#f6f2e8] p-2.5 rounded-lg border border-[#1a3d2f]/15">
                    <div className="flex justify-between items-center text-[10px] font-mono text-[#556b5f] mb-1">
                      <span className="font-bold text-[#1a3d2f]">Victorias de ruta:</span>
                      <span>
                        <strong>{currentVictories}</strong>/{targetVictories} vic.
                      </span>
                    </div>
                    <div className="h-2 bg-[#d9d0ba] rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all duration-300 ${
                          isCompleted ? 'bg-[#2d5a43]' : 'bg-[#d89b25]'
                        }`}
                        style={{
                          width: `${Math.min(100, (currentVictories / targetVictories) * 100)}%`,
                        }}
                      />
                    </div>

                    {nextZone && (
                      <div className="text-[10px] text-[#556b5f] mt-1.5 flex items-center gap-1">
                        <ChevronRight className="w-3 h-3 text-[#d89b25]" />
                        <span>
                          {isCompleted ? 'Desbloqueó: ' : 'Próximo destino: '}
                          <strong>{nextZone.name}</strong>
                        </span>
                      </div>
                    )}
                  </div>
                )}

                {/* Si está bloqueada, mostrar el requisito exacto */}
                {!isUnlocked && zone.unlockRequirement && (
                  <div className="mt-2.5 p-2 bg-[#ded1b5] rounded-md text-[10px] text-[#8a8a79] font-medium flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-[#8a8a79] shrink-0" />
                    <span>{zone.unlockRequirement.text}</span>
                  </div>
                )}
              </div>

              {/* Pie de tarjeta con botones funcionales */}
              {isUnlocked && (
                <div className="pt-2 border-t border-[#1a3d2f]/10 flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-1 text-xs font-mono text-[#556b5f]">
                    <Sparkles className="w-3 h-3 text-[#d89b25]" />
                    <span className="font-bold text-[#1a3d2f]">{currentPoints}</span>
                    <span>pts</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {/* Botón de Gimnasio si la zona alberga uno */}
                    {zoneGym && (
                      <button
                        type="button"
                        onClick={handleGymClick}
                        className="px-2.5 py-1 bg-[#d44f33] hover:bg-[#b03d24] text-white text-xs font-bold rounded flex items-center gap-1 transition-colors cursor-pointer shadow-2xs"
                      >
                        <Swords className="w-3 h-3" />
                        <span>Gym {zoneGym.name}</span>
                      </button>
                    )}

                    {!isCurrentActive ? (
                      <button
                        type="button"
                        onClick={() => handleZoneClick(zone.id)}
                        className="px-3 py-1 bg-[#1a3d2f] hover:bg-[#25523f] text-[#f4ecd8] text-xs font-bold rounded flex items-center gap-1 transition-colors cursor-pointer"
                      >
                        <Compass className="w-3 h-3" />
                        <span>Viajar</span>
                      </button>
                    ) : (
                      <span className="text-[10px] text-[#2d5a43] font-bold px-2 py-0.5 bg-[#d8ecd8] rounded">
                        Explorando aquí
                      </span>
                    )}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
