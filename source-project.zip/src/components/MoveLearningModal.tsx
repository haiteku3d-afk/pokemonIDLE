import React from 'react';
import { Sparkles, Swords, Shield, Zap, ChevronRight, X, ArrowRight, Check } from 'lucide-react';
import { PendingMoveLearning, OwnedPokemon } from '../types/pokemon';
import { POKEMON_BY_ID, TYPE_COLORS } from '../data/pokemon151';
import { MOVES_DATA } from '../data/moves';
import { PokemonSprite } from './PokemonSprite';
import { retroAudio } from '../utils/audio';

interface MoveLearningModalProps {
  isOpen: boolean;
  pendingMove: PendingMoveLearning | null;
  totalPendingCount: number;
  pokemon: OwnedPokemon | null;
  onEquipInFreeSlot: (pokemonUid: string, moveId: string) => void;
  onReplaceMove: (pokemonUid: string, slotIndex: number, newMoveId: string) => void;
  onDismiss: () => void; // Mantener actuales / decidir después
}

export const MoveLearningModal: React.FC<MoveLearningModalProps> = ({
  isOpen,
  pendingMove,
  totalPendingCount,
  pokemon,
  onEquipInFreeSlot,
  onReplaceMove,
  onDismiss,
}) => {
  if (!isOpen || !pendingMove || !pokemon) return null;

  const species = POKEMON_BY_ID[pokemon.speciesId];
  const newMove = MOVES_DATA[pendingMove.moveId];
  if (!newMove) return null;

  const equipped = pokemon.equippedMoves || ['placaje'];
  const hasFreeSlot = equipped.length < 4;

  const handleEquipFree = () => {
    retroAudio.playFanfare();
    onEquipInFreeSlot(pokemon.uid, newMove.id);
  };

  const handleReplace = (slotIdx: number) => {
    retroAudio.playFanfare();
    onReplaceMove(pokemon.uid, slotIdx, newMove.id);
  };

  const handleDecideLater = () => {
    retroAudio.playClick();
    onDismiss();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-xs overscroll-contain">
      <div className="relative w-full max-w-xl bg-[#f6f2e8] border-3 sm:border-4 border-[#1a3d2f] rounded-2xl shadow-2xl flex flex-col text-[#1c2e24] max-h-[92dvh] overflow-hidden">
        {/* Cabecera */}
        <div className="p-3.5 sm:p-4 bg-[#efe7d3] border-b-2 border-[#1a3d2f]/20 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <PokemonSprite speciesId={pokemon.speciesId} size="sm" />
            <div>
              <div className="flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-[#d89b25]" />
                <h2 className="text-sm sm:text-base font-bold text-[#1a3d2f]">
                  ¡Nuevo Movimiento Aprendido!
                </h2>
              </div>
              <p className="text-xs text-[#556b5f]">
                {pokemon.nickname || species?.name} (Nv. {pokemon.level}) quiere aprender un ataque
              </p>
            </div>
          </div>

          {totalPendingCount > 1 && (
            <span className="text-[10px] font-mono font-bold bg-[#ded1b5] text-[#2d5a43] px-2 py-1 rounded">
              +{totalPendingCount - 1} más en cola
            </span>
          )}
        </div>

        {/* Cuerpo con desplazamiento seguro */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 flex flex-col gap-4 text-xs">
          {/* Tarjeta del nuevo movimiento */}
          <div className="bg-[#ede4cf] border-2 border-[#1a3d2f]/30 rounded-xl p-3.5 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold text-[#d44f33] tracking-wide">
                Ataque Desbloqueado
              </span>
              <span
                className="px-2 py-0.5 rounded text-[10px] uppercase font-bold text-white shadow-2xs"
                style={{ backgroundColor: TYPE_COLORS[newMove.type]?.bg || '#777' }}
              >
                {newMove.type}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <h3 className="text-base sm:text-lg font-bold text-[#1a3d2f]">{newMove.name}</h3>
              <div className="flex items-center gap-3 font-mono text-[11px] text-[#2d5a43]">
                <span>
                  Pot: <strong>{newMove.power > 0 ? newMove.power : '—'}</strong>
                </span>
                <span>
                  Prec: <strong>{newMove.accuracy}%</strong>
                </span>
                <span className="uppercase text-[10px] bg-[#d8ecd8] px-1.5 py-0.5 rounded font-bold">
                  {newMove.category}
                </span>
              </div>
            </div>

            <p className="text-[#415a4d] text-xs leading-relaxed">{newMove.effect}</p>
          </div>

          {/* Opciones según ranuras libres */}
          {hasFreeSlot ? (
            <div className="bg-[#d8ecd8]/40 border border-[#2d5a43]/30 rounded-xl p-3.5 flex flex-col gap-2 text-center">
              <p className="text-xs text-[#2d5a43] font-medium">
                {pokemon.nickname || species?.name} tiene ranuras libres ({equipped.length}/4
                equipadas). Puedes equiparlo ahora mismo.
              </p>
              <button
                type="button"
                onClick={handleEquipFree}
                className="w-full py-2.5 bg-[#2d5a43] hover:bg-[#1a3d2f] text-[#f4ecd8] font-bold text-xs rounded-lg transition-colors cursor-pointer shadow-xs flex items-center justify-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>Equipar en ranura libre #{equipped.length + 1}</span>
              </button>
            </div>
          ) : (
            <div className="flex flex-col gap-2.5">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-[#1a3d2f]">
                  4 Movimientos Equipados: Elige cuál sustituir
                </span>
                <span className="text-[10px] text-[#556b5f]">Máximo 4 por Pokémon</span>
              </div>

              {/* Lista de los 4 equipados con botón de sustitución */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {equipped.map((moveId, idx) => {
                  const m = MOVES_DATA[moveId] || MOVES_DATA['placaje'];
                  return (
                    <div
                      key={`${moveId}-${idx}`}
                      className="bg-[#f6f2e8] border border-[#1a3d2f]/25 rounded-lg p-2.5 flex flex-col justify-between gap-2 shadow-2xs hover:border-[#1a3d2f]/50 transition-colors"
                    >
                      <div>
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-xs text-[#1a3d2f]">
                            #{idx + 1} {m.name}
                          </span>
                          <span
                            className="px-1.5 py-0.2 rounded text-[9px] uppercase font-bold text-white"
                            style={{ backgroundColor: TYPE_COLORS[m.type]?.bg || '#777' }}
                          >
                            {m.type}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 mt-1 text-[10px] font-mono text-[#556b5f]">
                          <span>Pot: {m.power > 0 ? m.power : '—'}</span>
                          <span>Prec: {m.accuracy}%</span>
                          <span className="capitalize">{m.category}</span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleReplace(idx)}
                        className="py-1.5 px-2 bg-[#d44f33] hover:bg-[#b03d24] text-white font-bold text-[10px] rounded transition-colors cursor-pointer flex items-center justify-center gap-1 shadow-2xs"
                      >
                        <ArrowRight className="w-3 h-3" />
                        <span>Reemplazar por {newMove.name}</span>
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          <div className="bg-[#efe7d3]/70 border border-[#1a3d2f]/15 rounded-lg p-2.5 text-[11px] text-[#556b5f]">
            💡 <em>Nota:</em> Si decides conservar tus movimientos actuales, este ataque quedará
            guardado permanentemente en la biblioteca de movimientos aprendidos de{' '}
            {pokemon.nickname || species?.name} y podrás equiparlo cuando quieras desde su Ficha en
            el Equipo.
          </div>
        </div>

        {/* Barra Inferior */}
        <div className="p-3 bg-[#ede4cf] border-t border-[#1a3d2f]/20 flex items-center justify-end gap-2 shrink-0">
          <button
            type="button"
            onClick={handleDecideLater}
            className="px-4 py-2 bg-[#ded1b5] hover:bg-[#c8bc9f] active:bg-[#b0a489] text-[#1a3d2f] font-bold text-xs rounded-lg transition-colors cursor-pointer"
          >
            Mantener movimientos / Decidir después
          </button>
        </div>
      </div>
    </div>
  );
};
