import { ExperienceBar } from './ExperienceBar';
import React from 'react';
import {
  ArrowUp,
  ArrowDown,
  LogOut,
  LogIn,
  Heart,
  Sparkles,
  Plus,
  Award,
  Table,
  Lock,
  Swords,
} from 'lucide-react';
import { OwnedPokemon } from '../types/pokemon';
import { POKEMON_BY_ID, TYPE_COLORS } from '../data/pokemon151';
import { PokemonSprite } from './PokemonSprite';
import { getLevelCap, getEffectiveLevel } from '../utils/levelCaps';
import { retroAudio } from '../utils/audio';

interface TeamScreenProps {
  team: OwnedPokemon[];
  pcBox: OwnedPokemon[];
  oakCandies: number;
  badges: string[];
  pendingMovesCount?: number;
  onOpenPendingMoves?: () => void;
  onReorderTeam: (newTeam: OwnedPokemon[]) => void;
  onSendToBox: (uid: string) => void;
  onAddToTeamFromBox: (uid: string) => void;
  onUseRareCandy: (uid: string) => void;
  onHealTeam: () => void;
  onOpenCardModal: (poke: OwnedPokemon) => void;
}

export const TeamScreen: React.FC<TeamScreenProps> = ({
  team,
  pcBox,
  oakCandies,
  badges,
  pendingMovesCount = 0,
  onOpenPendingMoves,
  onReorderTeam,
  onSendToBox,
  onAddToTeamFromBox,
  onUseRareCandy,
  onHealTeam,
  onOpenCardModal,
}) => {
  const capInfo = getLevelCap(badges);

  const handleMoveUp = (index: number) => {
    if (index === 0) return;
    retroAudio.playClick();
    const newTeam = [...team];
    const temp = newTeam[index];
    newTeam[index] = newTeam[index - 1];
    newTeam[index - 1] = temp;
    onReorderTeam(newTeam);
  };

  const handleMoveDown = (index: number) => {
    if (index === team.length - 1) return;
    retroAudio.playClick();
    const newTeam = [...team];
    const temp = newTeam[index];
    newTeam[index] = newTeam[index + 1];
    newTeam[index + 1] = temp;
    onReorderTeam(newTeam);
  };

  return (
    <div className="max-w-6xl mx-auto px-3 sm:px-6 py-4 flex flex-col gap-5 text-[#1c2e24]">
      {/* Cabecera del Equipo con Límite de Medalla */}
      <div className="bg-[#ede4cf] border-2 border-[#1a3d2f]/30 rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#d44f33]">
            Gestión de Escuadrón
          </span>
          <h1 className="text-lg sm:text-xl font-bold font-['Plus_Jakarta_Sans'] text-[#1a3d2f]">
            Equipo Activo ({team.length}/6 Pokémon)
          </h1>
          <p className="text-xs sm:text-sm text-[#415a4d] mt-1">
            Especies estrictamente únicas en el equipo. Consulta la ficha para entrenar IVs (0-31) y
            gestionar movimientos.
          </p>
        </div>

        <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
          {/* Límite de Nivel por Medallas (Regla D) */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#f6f2e8] border border-[#2d5a43]/20 rounded-lg text-xs font-mono">
            <Award className="w-3.5 h-3.5 text-[#d89b25]" />
            <span className="text-[#556b5f]">Tope de Nivel:</span>
            <strong className="text-[#1a3d2f]">Nv.{capInfo.cap}</strong>
            {!capInfo.isMax && (
              <span className="text-[10px] text-[#556b5f] hidden sm:inline">
                ({capInfo.nextLeaderName})
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#f6f2e8] border border-[#2d5a43]/20 rounded-lg text-xs font-mono">
            <Sparkles className="w-3.5 h-3.5 text-[#d89b25]" />
            <span className="text-[#556b5f]">Caramelos:</span>
            <span className="font-bold text-[#1a3d2f]">{oakCandies}</span>
          </div>

          <button
            onClick={() => {
              retroAudio.playRareChime();
              onHealTeam();
            }}
            className="px-3.5 py-2 bg-[#2d5a43] hover:bg-[#1a3d2f] text-[#f4ecd8] text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Heart className="w-3.5 h-3.5 text-[#d44f33] fill-[#d44f33]" />
            <span>Curar Equipo</span>
          </button>
        </div>
      </div>

      {/* Aviso de Movimientos Pendientes de Aprender (Regla C) */}
      {pendingMovesCount > 0 && onOpenPendingMoves && (
        <div className="bg-[#fef5e7] border-2 border-[#d89b25] rounded-xl p-3 sm:p-4 flex items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-[#d89b25] text-white flex items-center justify-center font-bold shrink-0">
              <Swords className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-[#1a3d2f]">
                ¡Tienes {pendingMovesCount} nuevo(s) movimiento(s) por aprender!
              </h2>
              <p className="text-xs text-[#556b5f]">
                Elige en qué ranura equiparlo o decide sustituir uno existente.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenPendingMoves}
            className="px-4 py-2 bg-[#d89b25] hover:bg-[#be861e] text-white text-xs font-bold rounded-lg transition-colors cursor-pointer shrink-0 shadow-xs"
          >
            Gestionar Ahora
          </button>
        </div>
      )}

      {/* Rejilla de los 6 Pokémon del Equipo Activo */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {team.map((poke, index) => {
          const species = POKEMON_BY_ID[poke.speciesId];
          const isLead = index === 0;
          const effectiveLevel = getEffectiveLevel(poke.level, badges);
          const isCapped = poke.level >= capInfo.cap;
          const hasDifferentLevel = poke.level > effectiveLevel;

          return (
            <div
              key={poke.uid}
              className={`bg-[#f6f2e8] border-2 rounded-xl p-3.5 flex flex-col justify-between gap-3 shadow-xs relative transition-all ${
                isLead ? 'border-[#1a3d2f] ring-2 ring-[#2d5a43]/30' : 'border-[#1a3d2f]/20'
              }`}
            >
              {isLead && (
                <span className="absolute -top-2.5 left-3 px-2 py-0.5 bg-[#1a3d2f] text-[#f4ecd8] text-[9px] font-['Press_Start_2P'] uppercase rounded">
                  LÍDER #1
                </span>
              )}

              {/* Fila Principal: Sprite, Nombre, Tipos, Nivel */}
              <div className="flex items-start gap-3">
                <PokemonSprite speciesId={poke.speciesId} shiny={poke.isShiny} size="md" />

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-sm text-[#1a3d2f] truncate">
                      {poke.nickname || species?.name}
                    </h3>
                    <div className="font-mono text-xs font-bold text-[#2d5a43] flex items-center gap-1">
                      {hasDifferentLevel ? (
                        <span title={`Nivel real: ${poke.level} · Nivel efectivo por medalla: ${effectiveLevel}`}>
                          Nv.{effectiveLevel}{' '}
                          <span className="text-[10px] text-[#8a8a79]">({poke.level})</span>
                        </span>
                      ) : (
                        <span>Nv.{poke.level}</span>
                      )}
                      {isCapped && (
                        <span className="text-[8px] bg-[#d8ecd8] text-[#2d5a43] px-1 rounded uppercase">
                          Cap
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1 mt-1 flex-wrap">
                    {species?.types.map((t) => (
                      <span
                        key={t}
                        className="px-1.5 py-0.2 rounded text-[9px] uppercase font-bold text-white"
                        style={{ backgroundColor: TYPE_COLORS[t].bg }}
                      >
                        {t}
                      </span>
                    ))}
                    {poke.status && (
                      <span
                        className={`px-1.5 py-0.2 rounded text-[9px] font-bold text-white uppercase ${
                          poke.status === 'paralisis'
                            ? 'bg-[#d89b25]'
                            : poke.status === 'quemadura'
                            ? 'bg-[#c54a2a]'
                            : poke.status === 'veneno'
                            ? 'bg-[#89389e]'
                            : 'bg-[#5176b5]'
                        }`}
                      >
                        {poke.status === 'paralisis'
                          ? 'PAR'
                          : poke.status === 'quemadura'
                          ? 'QMD'
                          : poke.status === 'veneno'
                          ? 'PSN'
                          : 'DOR'}
                      </span>
                    )}
                  </div>

                  {/* Barra de PS */}
                  <div className="mt-2">
                    <div className="flex justify-between text-[10px] text-[#556b5f] font-mono">
                      <span>PS</span>
                      <span>
                        {poke.currentHp}/{poke.maxHp}
                      </span>
                    </div>
                    <div className="h-1.5 bg-[#d9d0ba] rounded-full overflow-hidden mt-0.5">
                      <div
                        className={`h-full ${
                          poke.currentHp / poke.maxHp > 0.5
                            ? 'bg-[#589b43]'
                            : poke.currentHp / poke.maxHp > 0.2
                            ? 'bg-[#d89b25]'
                            : 'bg-[#d44f33]'
                        }`}
                        style={{ width: `${Math.max(0, (poke.currentHp / poke.maxHp) * 100)}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>

              <ExperienceBar pokemon={poke} badges={badges} />
              {/* Estadísticas detalladas de 6 valores */}
              <div className="grid grid-cols-6 gap-1 text-center font-mono text-[10px] bg-[#ede4cf] p-2 rounded-lg border border-[#c8bc9f]">
                <div>
                  <span className="text-[8px] text-[#556b5f] block">PS</span>
                  <span className="font-bold text-[#1a3d2f]">{poke.maxHp}</span>
                </div>
                <div>
                  <span className="text-[8px] text-[#556b5f] block">Atk</span>
                  <span className="font-bold text-[#1a3d2f]">{poke.attack}</span>
                </div>
                <div>
                  <span className="text-[8px] text-[#556b5f] block">Def</span>
                  <span className="font-bold text-[#1a3d2f]">{poke.defense}</span>
                </div>
                <div>
                  <span className="text-[8px] text-[#556b5f] block">SpA</span>
                  <span className="font-bold text-[#1a3d2f]">{poke.spAtk}</span>
                </div>
                <div>
                  <span className="text-[8px] text-[#556b5f] block">SpD</span>
                  <span className="font-bold text-[#1a3d2f]">{poke.spDef}</span>
                </div>
                <div>
                  <span className="text-[8px] text-[#556b5f] block">Vel</span>
                  <span className="font-bold text-[#1a3d2f]">{poke.speed}</span>
                </div>
              </div>

              {/* Botón destacado Ficha de Pokémon / Movimientos / IVs */}
              <button
                type="button"
                onClick={() => onOpenCardModal(poke)}
                className="w-full py-1.5 bg-[#ede4cf] hover:bg-[#ded1b5] text-[#1a3d2f] border border-[#c8bc9f] rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Table className="w-3.5 h-3.5 text-[#d89b25]" />
                <span>Ficha: Movimientos ({poke.equippedMoves?.length || 1}/4) & IVs</span>
              </button>

              {/* Botonera de Gestión: Reordenar, Usar Caramelo Raro, Enviar al PC */}
              <div className="flex items-center justify-between pt-1 border-t border-[#1a3d2f]/10 gap-1.5">
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    disabled={index === 0}
                    onClick={() => handleMoveUp(index)}
                    title="Subir de posición en equipo"
                    className="p-1 rounded bg-[#ede4cf] hover:bg-[#ded1b5] disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
                  >
                    <ArrowUp className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    disabled={index === team.length - 1}
                    onClick={() => handleMoveDown(index)}
                    title="Bajar de posición en equipo"
                    className="p-1 rounded bg-[#ede4cf] hover:bg-[#ded1b5] disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
                  >
                    <ArrowDown className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex items-center gap-1.5">
                  {/* Usar Caramelo Raro (Bloqueado si está en el tope por medallas, no gasta el caramelo) */}
                  <button
                    type="button"
                    disabled={oakCandies < 1 || isCapped || poke.level >= 100}
                    onClick={() => onUseRareCandy(poke.uid)}
                    title={
                      isCapped
                        ? `Tope de Medalla alcanzado (Nv.${capInfo.cap}). Vence a ${capInfo.nextLeaderName} para aumentar el tope.`
                        : 'Subir 1 nivel con Caramelo Raro'
                    }
                    className={`px-2 py-1 text-[11px] font-bold rounded flex items-center gap-1 transition-colors ${
                      isCapped
                        ? 'bg-[#ded1b5] text-[#8a8a79] opacity-60 cursor-not-allowed'
                        : oakCandies >= 1
                        ? 'bg-[#ede4cf] hover:bg-[#ded1b5] text-[#2d5a43] cursor-pointer'
                        : 'bg-[#ede4cf] text-[#8a8a79] opacity-40 cursor-not-allowed'
                    }`}
                  >
                    {isCapped ? (
                      <>
                        <Lock className="w-3 h-3 text-[#8a8a79]" />
                        <span>Tope Nv.{capInfo.cap}</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3 h-3 text-[#d89b25]" />
                        <span>+1 Nivel</span>
                      </>
                    )}
                  </button>

                  {/* Enviar al PC Box */}
                  {team.length > 1 && (
                    <button
                      type="button"
                      onClick={() => onSendToBox(poke.uid)}
                      title="Enviar a la Caja del PC"
                      className="p-1 rounded bg-[#ede4cf] hover:bg-[#fbdcd5] text-[#d44f33] text-[11px] font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">A Caja</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Caja del PC (Ejemplares únicos almacenados) */}
      {pcBox.length > 0 && (
        <div className="bg-[#ede4cf] border-2 border-[#1a3d2f]/30 rounded-xl p-4 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-[#1a3d2f]">Caja del PC ({pcBox.length} Pokémon)</h2>
              <p className="text-xs text-[#556b5f]">
                Pokémon en reserva. Pulsa en uno para pasarlo a tu equipo activo (máx 6 especies únicas).
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2.5">
            {pcBox.map((poke) => {
              const spec = POKEMON_BY_ID[poke.speciesId];
              const isInTeam = team.some((t) => t.speciesId === poke.speciesId);
              const isTeamFull = team.length >= 6;

              return (
                <div
                  key={poke.uid}
                  className="bg-[#f6f2e8] border border-[#c8bc9f] rounded-lg p-2 flex flex-col justify-between gap-1.5 shadow-2xs hover:border-[#1a3d2f]/60 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <PokemonSprite speciesId={poke.speciesId} shiny={poke.isShiny} size="xs" />
                    <div className="min-w-0 flex-1 truncate">
                      <span className="font-bold text-xs text-[#1a3d2f] truncate block">
                        {poke.nickname || spec?.name}
                      </span>
                      <span className="text-[10px] text-[#556b5f]">Nv.{poke.level}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-[#c8bc9f]/40">
                    <button
                      type="button"
                      onClick={() => onOpenCardModal(poke)}
                      className="text-[10px] text-[#556b5f] hover:text-[#1a3d2f] font-semibold cursor-pointer"
                    >
                      Ficha
                    </button>

                    <button
                      type="button"
                      disabled={isTeamFull || isInTeam}
                      onClick={() => onAddToTeamFromBox(poke.uid)}
                      title={
                        isInTeam
                          ? 'Ya tienes un ejemplar en el equipo'
                          : isTeamFull
                          ? 'Equipo completo (máx 6)'
                          : 'Añadir al equipo'
                      }
                      className="px-2 py-0.5 bg-[#1a3d2f] hover:bg-[#25523f] disabled:opacity-30 disabled:cursor-not-allowed text-[#f4ecd8] text-[10px] font-bold rounded flex items-center gap-1 cursor-pointer"
                    >
                      <LogIn className="w-2.5 h-2.5" />
                      <span>Al Equipo</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

