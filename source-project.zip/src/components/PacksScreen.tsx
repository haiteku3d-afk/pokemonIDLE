import React, { useState } from 'react';
import { Sparkles, Eye, Package, Compass, Fish, Waves } from 'lucide-react';
import { ZoneData, EncounterRate } from '../types/pokemon';
import { POKEMON_BY_ID, TYPE_COLORS } from '../data/pokemon151';
import { PokemonSprite } from './PokemonSprite';
import { retroAudio } from '../utils/audio';

interface PacksScreenProps {
  unlockedZones: ZoneData[];
  zonePoints: Record<string, number>;
  activeZoneId: string;
  items: Record<string, number>;
  onOpenPack: (
    zone: ZoneData,
    count: 3 | 5,
    cost: number,
    tableType: 'standard' | 'blue' | 'fishing' | 'surf'
  ) => void;
  onSelectZoneToExplore: (zoneId: string) => void;
}

interface ProbabilitiesModalData {
  title: string;
  table: EncounterRate[];
}

export const PacksScreen: React.FC<PacksScreenProps> = ({
  unlockedZones,
  zonePoints,
  activeZoneId,
  items,
  onOpenPack,
  onSelectZoneToExplore,
}) => {
  const [probModalData, setProbModalData] = useState<ProbabilitiesModalData | null>(null);

  const handleOpenPackClick = (
    zone: ZoneData,
    count: 3 | 5,
    cost: number,
    tableType: 'standard' | 'blue' | 'fishing' | 'surf'
  ) => {
    retroAudio.playPackRip();
    onOpenPack(zone, count, cost, tableType);
  };

  const handleShowProbabilities = (title: string, table: EncounterRate[]) => {
    retroAudio.playClick();
    setProbModalData({ title, table });
  };

  return (
    <div className="max-w-6xl mx-auto px-3 sm:px-6 py-4 flex flex-col gap-5 text-[#1c2e24]">
      {/* Cabecera de la Pantalla */}
      <div className="bg-[#ede4cf] border-2 border-[#1a3d2f]/30 rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#d44f33]">
            Tienda de Sobres Coleccionables
          </span>
          <h1 className="text-lg sm:text-xl font-bold font-['Plus_Jakarta_Sans'] text-[#1a3d2f]">
            Sobres de Encuentros de Kanto
          </h1>
          <p className="text-xs sm:text-sm text-[#415a4d] mt-1">
            Cada enemigo derrotado otorga 1 punto en esa zona. Los sobres se sortean con las{' '}
            <strong>probabilidades originales de Pokémon Rojo</strong> de Game Boy.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-[#f6f2e8] border border-[#2d5a43]/20 px-3 py-2 rounded-lg text-xs font-mono">
          <Package className="w-4 h-4 text-[#2d5a43]" />
          <span className="text-[#556b5f]">Zonas desbloqueadas:</span>
          <span className="font-bold text-[#1a3d2f]">{unlockedZones.length}</span>
        </div>
      </div>

      {/* Listado de Zonas Desbloqueadas y sus Sobres */}
      <div className="flex flex-col gap-6">
        {unlockedZones.map((zone) => {
          const currentPoints = zonePoints[zone.id] || 0;
          const isCurrentActive = activeZoneId === zone.id;

          return (
            <div
              key={zone.id}
              className={`bg-[#f6f2e8] border-2 rounded-xl p-4 sm:p-5 shadow-xs transition-all ${
                isCurrentActive
                  ? 'border-[#1a3d2f] ring-2 ring-[#2d5a43]/20'
                  : 'border-[#1a3d2f]/20'
              }`}
            >
              {/* Encabezado de la Zona */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 mb-4 border-b border-[#1a3d2f]/15 gap-2">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-[#1a3d2f] text-[#f4ecd8] flex items-center justify-center font-bold text-xs shrink-0">
                    #{zone.order}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 className="text-base sm:text-lg font-bold font-['Plus_Jakarta_Sans'] text-[#1a3d2f]">
                        {zone.name}
                      </h2>
                      {isCurrentActive && (
                        <span className="text-[10px] font-['Press_Start_2P'] text-[#2d5a43] bg-[#d8ecd8] px-1.5 py-0.5 rounded">
                          ACTIVA
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-[#556b5f]">{zone.subtitle}</p>
                  </div>
                </div>

                {/* Saldo de Puntos locales y Botón de Explorar */}
                <div className="flex items-center gap-2 sm:gap-3">
                  <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#ede4cf] border border-[#2d5a43]/20 rounded-lg text-xs font-mono">
                    <Sparkles className="w-3.5 h-3.5 text-[#d89b25]" />
                    <span className="text-[#556b5f]">Puntos locales:</span>
                    <span className="font-bold text-sm text-[#1a3d2f] tabular-nums">
                      {currentPoints}
                    </span>
                  </div>

                  {!isCurrentActive && (
                    <button
                      onClick={() => {
                        retroAudio.playClick();
                        onSelectZoneToExplore(zone.id);
                      }}
                      className="px-3 py-1.5 bg-[#ded1b5] hover:bg-[#c8bc9f] text-[#1a3d2f] text-xs font-bold rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      <Compass className="w-3.5 h-3.5" />
                      <span>Explorar aquí</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Secciones de Sobres Disponibles en esta Zona */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {/* 1. Sobre Estándar Rojo */}
                <div className="bg-[#ede4cf] border border-[#c8bc9f] rounded-xl p-3.5 flex flex-col justify-between gap-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-[#d44f33]" />
                        <h3 className="font-bold text-sm text-[#1a3d2f]">
                          Sobre Edición Rojo · {zone.name}
                        </h3>
                      </div>
                      <p className="text-[11px] text-[#556b5f] mt-0.5">
                        Probabilidades de encuentros salvajes oficiales de Pokémon Rojo (GB).
                      </p>
                    </div>

                    <button
                      onClick={() =>
                        handleShowProbabilities(
                          `Probabilidades Rojo · ${zone.name}`,
                          zone.encounterTable
                        )
                      }
                      className="px-2 py-1 text-[11px] text-[#2d5a43] hover:text-[#1a3d2f] font-semibold flex items-center gap-1 hover:underline cursor-pointer shrink-0"
                    >
                      <Eye className="w-3 h-3" />
                      <span>Ver %</span>
                    </button>
                  </div>

                  {/* Opciones de 3 y 5 cartas */}
                  <div className="grid grid-cols-2 gap-2">
                    {([
                      { count: 3 as const, cost: 30, label: '3 Pokémon' },
                      { count: 5 as const, cost: 50, label: '5 Pokémon' },
                    ]).map((opt) => {
                      const canAfford = currentPoints >= opt.cost;
                      return (
                        <button
                          key={opt.count}
                          disabled={!canAfford}
                          onClick={() =>
                            handleOpenPackClick(zone, opt.count, opt.cost, 'standard')
                          }
                          className={`p-2.5 rounded-lg border flex flex-col items-center justify-center text-center transition-all ${
                            canAfford
                              ? 'bg-[#f6f2e8] border-[#1a3d2f] hover:bg-[#ffffff] hover:scale-102 shadow-xs cursor-pointer'
                              : 'bg-[#ded1b5]/60 border-[#c8bc9f] opacity-50 cursor-not-allowed'
                          }`}
                        >
                          <span className="font-bold text-xs text-[#1a3d2f]">{opt.label}</span>
                          <span className="text-[11px] font-mono text-[#d89b25] font-bold mt-0.5">
                            {opt.cost} pts
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* 2. Sobre Alternativo Edición Azul (si la zona tiene tabla alternativa) */}
                {zone.blueAlternateTable && zone.blueAlternateTable.length > 0 && (
                  <div className="bg-[#ede4cf] border border-[#c8bc9f] rounded-xl p-3.5 flex flex-col justify-between gap-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-[#3a72b8]" />
                          <h3 className="font-bold text-sm text-[#1a3d2f]">
                            Sobre Edición Azul · Exclusivos
                          </h3>
                        </div>
                        <p className="text-[11px] text-[#556b5f] mt-0.5">
                          Variantes exclusivas de la Edición Azul para completar los 151.
                        </p>
                      </div>

                      <button
                        onClick={() =>
                          handleShowProbabilities(
                            `Probabilidades Azul · ${zone.name}`,
                            zone.blueAlternateTable!
                          )
                        }
                        className="px-2 py-1 text-[11px] text-[#3a72b8] hover:text-[#254d7d] font-semibold flex items-center gap-1 hover:underline cursor-pointer shrink-0"
                      >
                        <Eye className="w-3 h-3" />
                        <span>Ver %</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      {([
                        { count: 3 as const, cost: 30, label: '3 Pokémon' },
                        { count: 5 as const, cost: 50, label: '5 Pokémon' },
                      ]).map((opt) => {
                        const canAfford = currentPoints >= opt.cost;
                        return (
                          <button
                            key={opt.count}
                            disabled={!canAfford}
                            onClick={() =>
                              handleOpenPackClick(zone, opt.count, opt.cost, 'blue')
                            }
                            className={`p-2.5 rounded-lg border flex flex-col items-center justify-center text-center transition-all ${
                              canAfford
                                ? 'bg-[#f6f2e8] border-[#3a72b8] hover:bg-[#ffffff] hover:scale-102 shadow-xs cursor-pointer'
                                : 'bg-[#ded1b5]/60 border-[#c8bc9f] opacity-50 cursor-not-allowed'
                            }`}
                          >
                            <span className="font-bold text-xs text-[#1a3d2f]">{opt.label}</span>
                            <span className="text-[11px] font-mono text-[#3a72b8] font-bold mt-0.5">
                              {opt.cost} pts
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* 3. Sobre de Pesca (si la zona tiene agua y el jugador tiene caña) */}
                {zone.fishingTable && (
                  <div className="bg-[#ede4cf] border border-[#c8bc9f] rounded-xl p-3.5 flex flex-col justify-between gap-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <Fish className="w-3.5 h-3.5 text-[#3a72b8]" />
                          <h3 className="font-bold text-sm text-[#1a3d2f]">
                            Sobre de Pesca Acuática
                          </h3>
                        </div>
                        <p className="text-[11px] text-[#556b5f] mt-0.5">
                          Encuentros marinos y fluviales de esta zona.
                        </p>
                      </div>

                      <button
                        onClick={() => {
                          const table =
                            zone.fishingTable?.superRod ||
                            zone.fishingTable?.goodRod ||
                            zone.fishingTable?.oldRod ||
                            [];
                          handleShowProbabilities(`Probabilidades de Pesca · ${zone.name}`, table);
                        }}
                        className="px-2 py-1 text-[11px] text-[#2d5a43] hover:text-[#1a3d2f] font-semibold flex items-center gap-1 hover:underline cursor-pointer shrink-0"
                      >
                        <Eye className="w-3 h-3" />
                        <span>Ver %</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      {([
                        { count: 3 as const, cost: 30, label: '3 Pokémon' },
                        { count: 5 as const, cost: 50, label: '5 Pokémon' },
                      ]).map((opt) => {
                        const canAfford = currentPoints >= opt.cost;
                        return (
                          <button
                            key={opt.count}
                            disabled={!canAfford}
                            onClick={() =>
                              handleOpenPackClick(zone, opt.count, opt.cost, 'fishing')
                            }
                            className={`p-2.5 rounded-lg border flex flex-col items-center justify-center text-center transition-all ${
                              canAfford
                                ? 'bg-[#f6f2e8] border-[#3a72b8] hover:bg-[#ffffff] hover:scale-102 shadow-xs cursor-pointer'
                                : 'bg-[#ded1b5]/60 border-[#c8bc9f] opacity-50 cursor-not-allowed'
                            }`}
                          >
                            <span className="font-bold text-xs text-[#1a3d2f]">{opt.label}</span>
                            <span className="text-[11px] font-mono text-[#3a72b8] font-bold mt-0.5">
                              {opt.cost} pts
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* 4. Sobre de Surf (si la zona tiene tabla de oleaje) */}
                {zone.surfTable && (
                  <div className="bg-[#ede4cf] border border-[#c8bc9f] rounded-xl p-3.5 flex flex-col justify-between gap-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <Waves className="w-3.5 h-3.5 text-[#56a7a5]" />
                          <h3 className="font-bold text-sm text-[#1a3d2f]">
                            Sobre de Oleaje y Surf
                          </h3>
                        </div>
                        <p className="text-[11px] text-[#556b5f] mt-0.5">
                          Especies que habitan sobre el oleaje marino.
                        </p>
                      </div>

                      <button
                        onClick={() =>
                          handleShowProbabilities(
                            `Probabilidades Surf · ${zone.name}`,
                            zone.surfTable!
                          )
                        }
                        className="px-2 py-1 text-[11px] text-[#56a7a5] hover:text-[#387372] font-semibold flex items-center gap-1 hover:underline cursor-pointer shrink-0"
                      >
                        <Eye className="w-3 h-3" />
                        <span>Ver %</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      {([
                        { count: 3 as const, cost: 30, label: '3 Pokémon' },
                        { count: 5 as const, cost: 50, label: '5 Pokémon' },
                      ]).map((opt) => {
                        const canAfford = currentPoints >= opt.cost;
                        return (
                          <button
                            key={opt.count}
                            disabled={!canAfford}
                            onClick={() =>
                              handleOpenPackClick(zone, opt.count, opt.cost, 'surf')
                            }
                            className={`p-2.5 rounded-lg border flex flex-col items-center justify-center text-center transition-all ${
                              canAfford
                                ? 'bg-[#f6f2e8] border-[#56a7a5] hover:bg-[#ffffff] hover:scale-102 shadow-xs cursor-pointer'
                                : 'bg-[#ded1b5]/60 border-[#c8bc9f] opacity-50 cursor-not-allowed'
                            }`}
                          >
                            <span className="font-bold text-xs text-[#1a3d2f]">{opt.label}</span>
                            <span className="text-[11px] font-mono text-[#56a7a5] font-bold mt-0.5">
                              {opt.cost} pts
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal de Detalle de Probabilidades Reales */}
      {probModalData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative w-full max-w-lg bg-[#f6f2e8] border-3 border-[#1a3d2f] rounded-xl shadow-xl p-4 sm:p-5 flex flex-col gap-3 text-[#1c2e24]">
            <div className="flex items-center justify-between pb-2 border-b border-[#1a3d2f]/20">
              <h3 className="font-bold text-sm sm:text-base text-[#1a3d2f]">
                {probModalData.title}
              </h3>
              <button
                onClick={() => setProbModalData(null)}
                className="w-7 h-7 rounded-md bg-[#ded1b5] hover:bg-[#c8bc9f] flex items-center justify-center font-bold text-xs cursor-pointer"
              >
                ✕
              </button>
            </div>

            <p className="text-[11px] text-[#556b5f]">
              Cada tirada es un evento estadístico independiente. Sin manipulaciones de rareza ficticia.
            </p>

            <div className="flex flex-col gap-2 max-h-80 overflow-y-auto pr-1">
              {probModalData.table.map((row, idx) => {
                const spec = POKEMON_BY_ID[row.speciesId];
                return (
                  <div
                    key={`${row.speciesId}-${idx}`}
                    className="flex items-center justify-between p-2 rounded-lg bg-[#ede4cf] border border-[#c8bc9f]"
                  >
                    <div className="flex items-center gap-2.5">
                      <PokemonSprite speciesId={row.speciesId} size="xs" />
                      <div>
                        <div className="text-xs font-bold text-[#1a3d2f]">{spec?.name}</div>
                        <div className="text-[10px] text-[#556b5f] font-mono">
                          Niveles {row.minLevel} - {row.maxLevel}
                        </div>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="font-mono font-bold text-xs sm:text-sm text-[#2d5a43] tabular-nums">
                        {row.rate}%
                      </span>
                      <div className="text-[9px] text-[#556b5f]">probabilidad</div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="pt-2 border-t border-[#1a3d2f]/10 flex justify-end">
              <button
                onClick={() => setProbModalData(null)}
                className="px-4 py-1.5 bg-[#1a3d2f] hover:bg-[#25523f] text-[#f4ecd8] text-xs font-bold rounded-lg cursor-pointer"
              >
                Entendido
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
