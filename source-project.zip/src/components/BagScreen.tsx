import React, { useState } from 'react';
import { Backpack, Disc3, Gem, Shield } from 'lucide-react';
import { GameSave } from '../types/pokemon';
import { SHOP_ITEMS } from '../data/items';
import { KantoObjectives } from './KantoObjectives';
import { POKEMON_BY_ID } from '../data/pokemon151';

export function BagScreen({ save, update, onSelectPokemon }: { save: GameSave; update: React.Dispatch<React.SetStateAction<GameSave>>; onSelectPokemon: (uid: string) => void }) {
  const [pocket, setPocket] = useState<'objects' | 'tms'>('objects');
  const inventory = { ...save.items, ...save.inventory };
  const objects = Object.entries(inventory).filter(([id, count]) => count > 0 && !id.startsWith('tm:'));
  return <div className="max-w-5xl mx-auto px-3 sm:px-6 py-4 space-y-4 text-[#1c2e24]">
    <div className="rounded-2xl bg-[#ede4cf] border-2 border-[#1a3d2f]/25 p-5 flex gap-3 items-center"><Backpack className="w-9 h-9 text-[#2d5a43]" /><div><h1 className="text-xl font-bold">Tu mochila</h1><p className="text-xs text-[#556b5f]">Objetos y máquinas técnicas para preparar tu equipo.</p></div></div>
    <div className="flex gap-2" role="tablist" aria-label="Bolsillos de la mochila">
      {(['objects', 'tms'] as const).map(id => <button key={id} role="tab" aria-selected={pocket === id} onClick={() => setPocket(id)} className={`px-4 py-3 rounded-xl font-bold text-sm flex gap-2 items-center ${pocket === id ? 'bg-[#1a3d2f] text-white' : 'bg-[#e7ddc4] text-[#1a3d2f]'}`}>{id === 'objects' ? <Backpack size={16} /> : <Disc3 size={16} />}{id === 'objects' ? 'Objetos' : 'MT'}</button>)}
    </div>
    {pocket === 'tms' ? <KantoObjectives save={save} update={update} mode="tms" /> : <>
      <div className="grid sm:grid-cols-2 gap-3">{objects.map(([id, count]) => {
        const item = SHOP_ITEMS.find(item => item.id === id);
        return <div key={id} className="border border-[#c8bc9f] bg-[#fffaf0] rounded-xl p-4 flex gap-3"><div className="rounded-xl bg-[#ede4cf] p-3 h-fit">{item?.category === 'combat' ? <Shield size={22} /> : <Gem size={22} />}</div><div className="flex-1"><div className="flex justify-between gap-2"><h2 className="font-bold text-sm">{item?.name || id.replace(/_/g, ' ')}</h2><span className="font-bold">×{count}</span></div><p className="text-xs text-[#556b5f] mt-1">{item?.effectText || 'Objeto de exploración de Kanto.'}</p></div></div>;
      })}</div>
      {objects.length === 0 && <p className="p-8 text-center bg-[#fffaf0] border border-dashed border-[#c8bc9f] rounded-xl text-sm text-[#556b5f]">Tu bolsillo de objetos está vacío. Consigue objetos en la tienda o al completar eventos.</p>}
      <section className="rounded-xl border border-[#c8bc9f] p-4 bg-[#ede4cf]"><h2 className="font-bold text-sm">Usar o equipar un objeto</h2><p className="text-xs text-[#556b5f] mt-1">Elige un Pokémon para abrir su ficha, equipar objetos o revisar sus evoluciones.</p><div className="flex flex-wrap gap-2 mt-3">{[...save.team, ...save.pcBox].map(p => <button key={p.uid} onClick={() => onSelectPokemon(p.uid)} className="px-3 py-2 bg-[#fffaf0] border border-[#c8bc9f] rounded-lg text-xs font-bold">{p.nickname || POKEMON_BY_ID[p.speciesId].name}</button>)}</div></section>
    </>}
  </div>;
}
