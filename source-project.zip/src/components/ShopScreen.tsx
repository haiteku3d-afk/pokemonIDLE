import React from 'react';
import { Sparkles, Shield, Swords, Zap, Check, Lock, ShoppingBag, ArrowRight } from 'lucide-react';
import { SHOP_ITEMS, ShopItem } from '../data/items';
import { retroAudio } from '../utils/audio';

interface ShopScreenProps {
  trainerTokens: number;
  inventory: Record<string, number>;
  badges: string[];
  onBuyItem: (item: ShopItem) => void;
  onGoToTrainers: () => void;
}

export const ShopScreen: React.FC<ShopScreenProps> = ({
  trainerTokens,
  inventory,
  badges,
  onBuyItem,
  onGoToTrainers,
}) => {
  const isItemUnlocked = (item: ShopItem): boolean => {
    if (!item.requiredBadge) return true;
    return badges.includes(item.requiredBadge);
  };

  const handlePurchase = (item: ShopItem) => {
    if (trainerTokens < item.cost || !isItemUnlocked(item)) {
      return;
    }
    retroAudio.playRareChime();
    onBuyItem(item);
  };

  const evolutionItems = SHOP_ITEMS.filter((i) => i.category === 'evolution');
  const combatItems = SHOP_ITEMS.filter((i) => i.category === 'combat');

  return (
    <div className="max-w-5xl mx-auto px-3 sm:px-6 py-4 flex flex-col gap-4 text-[#1c2e24]">
      {/* Cabecera de la Tienda de Fichas */}
      <div className="bg-[#ede4cf] border-2 border-[#1a3d2f]/30 rounded-xl p-3 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#2d5a43]">
            Bazar Oficial de Kanto
          </span>
          <h1 className="text-base sm:text-xl font-bold font-['Plus_Jakarta_Sans'] text-[#1a3d2f]">
            Tienda de Fichas de Entrenador
          </h1>
          <p className="text-xs text-[#556b5f] mt-0.5">
            Intercambia tus fichas ganadas en combates de entrenador por piedras evolutivas, Cable Link y objetos de combate.
          </p>
        </div>

        {/* Saldo de Fichas y Acceso a Desafíos */}
        <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
          <div className="flex items-center gap-2 px-3 py-2 bg-[#f6f2e8] border-2 border-[#d89b25] rounded-xl text-xs font-mono shadow-xs">
            <Sparkles className="w-4 h-4 text-[#d89b25] fill-[#d89b25]" />
            <div className="flex flex-col">
              <span className="text-[10px] text-[#556b5f] leading-none">Tus Fichas:</span>
              <span className="font-bold text-base text-[#1a3d2f] tabular-nums leading-tight">
                {trainerTokens}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onGoToTrainers}
            className="px-3.5 py-2 bg-[#2d5a43] hover:bg-[#1a3d2f] text-[#f4ecd8] text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Swords className="w-3.5 h-3.5" />
            <span>Ganar Fichas</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Sección 1: Piedras Evolutivas y Cable Link */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-[#1a3d2f] uppercase tracking-wide flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#d89b25]" />
            <span>Objetos de Evolución (Desbloqueados tras Brock)</span>
          </h2>
          <span className="text-xs text-[#556b5f] font-mono">Consumo único al evolucionar</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {evolutionItems.map((item) => {
            const unlocked = isItemUnlocked(item);
            const canAfford = trainerTokens >= item.cost;
            const countOwned = inventory[item.id] || 0;

            return (
              <div
                key={item.id}
                className={`p-3.5 rounded-xl border-2 flex flex-col justify-between transition-all ${
                  unlocked
                    ? 'bg-[#f6f2e8] border-[#c8bc9f] shadow-xs'
                    : 'bg-[#ede4cf]/60 border-[#c8bc9f]/40 opacity-75'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="font-bold text-sm text-[#1a3d2f] block">{item.name}</span>
                      <span className="text-[10px] text-[#2d5a43] font-semibold bg-[#d8ecd8] px-1.5 py-0.2 rounded">
                        Evolución
                      </span>
                    </div>

                    <div className="flex items-center gap-1 font-mono font-bold text-xs px-2 py-0.5 rounded bg-[#ede4cf] text-[#1a3d2f] border border-[#c8bc9f]">
                      <Sparkles className="w-3 h-3 text-[#d89b25]" />
                      <span>{item.cost}</span>
                    </div>
                  </div>

                  <p className="text-xs text-[#415a4d] mt-2 leading-relaxed">{item.description}</p>
                  <p className="text-[11px] font-semibold text-[#1a3d2f] mt-1 bg-[#ede4cf] p-1.5 rounded border border-[#c8bc9f]/60">
                    {item.effectText}
                  </p>
                </div>

                <div className="mt-3 pt-2.5 border-t border-[#c8bc9f]/60 flex items-center justify-between">
                  <div className="text-[11px] font-mono text-[#556b5f]">
                    En reserva: <strong className="text-[#1a3d2f]">{countOwned}</strong>
                  </div>

                  {unlocked ? (
                    <button
                      type="button"
                      disabled={!canAfford}
                      onClick={() => handlePurchase(item)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
                        canAfford
                          ? 'bg-[#1a3d2f] hover:bg-[#25523f] active:bg-[#122b21] text-[#f4ecd8] cursor-pointer shadow-xs'
                          : 'bg-[#d9d0ba] text-[#7a8c80] cursor-not-allowed'
                      }`}
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>Comprar</span>
                    </button>
                  ) : (
                    <div className="flex items-center gap-1 text-[10px] font-bold text-[#9b3a2b] bg-[#f8e4e4] px-2 py-1 rounded border border-[#d44f33]/30">
                      <Lock className="w-3 h-3" />
                      <span>{item.badgeName}</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Sección 2: Objetos de Combate para Equipar */}
      <div className="space-y-3 mt-2">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-[#1a3d2f] uppercase tracking-wide flex items-center gap-2">
            <Shield className="w-4 h-4 text-[#3a72b8]" />
            <span>Objetos de Combate Equipables</span>
          </h2>
          <span className="text-xs text-[#556b5f] font-mono">1 por Pokémon · Reutilizable</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {combatItems.map((item) => {
            const unlocked = isItemUnlocked(item);
            const canAfford = trainerTokens >= item.cost;
            const countOwned = inventory[item.id] || 0;

            return (
              <div
                key={item.id}
                className={`p-3.5 rounded-xl border-2 flex flex-col justify-between transition-all ${
                  unlocked
                    ? 'bg-[#f6f2e8] border-[#c8bc9f] shadow-xs'
                    : 'bg-[#ede4cf]/60 border-[#c8bc9f]/40 opacity-75'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="font-bold text-sm text-[#1a3d2f] block">{item.name}</span>
                      <span className="text-[10px] text-[#3a72b8] font-semibold bg-[#d8e6f8] px-1.5 py-0.2 rounded">
                        Combate Equipable
                      </span>
                    </div>

                    <div className="flex items-center gap-1 font-mono font-bold text-xs px-2 py-0.5 rounded bg-[#ede4cf] text-[#1a3d2f] border border-[#c8bc9f]">
                      <Sparkles className="w-3 h-3 text-[#d89b25]" />
                      <span>{item.cost}</span>
                    </div>
                  </div>

                  <p className="text-xs text-[#415a4d] mt-2 leading-relaxed">{item.description}</p>
                  <p className="text-[11px] font-semibold text-[#1a3d2f] mt-1 bg-[#ede4cf] p-1.5 rounded border border-[#c8bc9f]/60">
                    {item.effectText}
                  </p>
                </div>

                <div className="mt-3 pt-2.5 border-t border-[#c8bc9f]/60 flex items-center justify-between">
                  <div className="text-[11px] font-mono text-[#556b5f]">
                    Disponibles: <strong className="text-[#1a3d2f]">{countOwned}</strong>
                  </div>

                  {unlocked ? (
                    <button
                      type="button"
                      disabled={!canAfford}
                      onClick={() => handlePurchase(item)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
                        canAfford
                          ? 'bg-[#1a3d2f] hover:bg-[#25523f] active:bg-[#122b21] text-[#f4ecd8] cursor-pointer shadow-xs'
                          : 'bg-[#d9d0ba] text-[#7a8c80] cursor-not-allowed'
                      }`}
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>Comprar</span>
                    </button>
                  ) : (
                    <div className="flex items-center gap-1 text-[10px] font-bold text-[#9b3a2b] bg-[#f8e4e4] px-2 py-1 rounded border border-[#d44f33]/30">
                      <Lock className="w-3 h-3" />
                      <span>{item.badgeName}</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
