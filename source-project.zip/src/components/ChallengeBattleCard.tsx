import React from 'react';
import { CombatantSnapshot, getAttackIntervalMs, getEffectiveSpeed, getCombatMoveId, getNextUsefulMoveIndex } from '../utils/combatEngine';
import { PokemonSprite } from './PokemonSprite';
import { MoveAttackBars, StatChanges, EffectiveStats } from './ExpeditionScreen';

export function ChallengeBattleCard({ pokemon, opponent, elapsed, shiny }: { pokemon: CombatantSnapshot; opponent?: CombatantSnapshot | null; elapsed: number; shiny?: boolean }) {
  const speed = getEffectiveSpeed(pokemon.speed, pokemon.stages.speed, pokemon.status);
  const nextIndex = opponent ? getNextUsefulMoveIndex(pokemon.equippedMoves, pokemon.currentMoveIndex, pokemon, opponent) : pokemon.currentMoveIndex;
  const interval = getAttackIntervalMs(speed, opponent ? getCombatMoveId(pokemon, opponent) : pokemon.equippedMoves[nextIndex]);
  const fallback = !!opponent && getCombatMoveId(pokemon, opponent) === 'forcejeo' && !pokemon.equippedMoves.includes('forcejeo');
  const displayedMoves = fallback ? [...pokemon.equippedMoves, 'forcejeo'] : pokemon.equippedMoves;
  return <div className="bg-[#f6f2e8] border-2 border-[#1a3d2f] rounded-lg p-2.5">
    <div className="flex justify-between text-xs font-bold text-[#1a3d2f]"><span>{pokemon.name}</span><span>Nv. {pokemon.level}</span></div>
    {pokemon.status && <span className="text-[10px] font-bold text-[#9b3a2b]">{pokemon.status}</span>}
    <StatChanges stages={pokemon.stages} />
    <EffectiveStats pokemon={pokemon} stages={pokemon.stages} />
    <div className="flex justify-center py-2 rounded-lg bg-[#e6eddb] mt-2"><PokemonSprite speciesId={pokemon.speciesId} shiny={shiny} size="lg" className={pokemon.currentHp <= 0 ? 'opacity-40 grayscale' : ''} /></div>
    <div className="mt-2 h-2 bg-[#d9d0ba] rounded-full overflow-hidden"><div className="h-full bg-[#589b43]" style={{ width: `${Math.max(0, pokemon.currentHp / pokemon.maxHp * 100)}%` }} /></div>
    <p className="text-[10px] text-[#556b5f] mt-1">{pokemon.currentHp}/{pokemon.maxHp} PS · Vel: {speed}</p>
    {pokemon.currentHp > 0 ? <MoveAttackBars moves={displayedMoves} nextIndex={fallback ? displayedMoves.length - 1 : nextIndex} progress={Math.min(100, elapsed / interval * 100)} remaining={Math.max(0, (interval - elapsed) / 1000).toFixed(1)} /> : <p className="text-xs text-[#9b3a2b]">Debilitado</p>}
  </div>;
}

export function ChallengeTeam({ team }: { team: CombatantSnapshot[] }) {
  return <section className="border-t border-[#c8bc9f] mt-3 pt-3"><h3 className="text-sm font-bold text-[#1a3d2f] mb-2">Tu equipo</h3><div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">{team.map((p, index) => <div key={index} className="text-center bg-[#fffaf0] rounded-lg border border-[#c8bc9f] p-2"><PokemonSprite speciesId={p.speciesId} size="sm" className={p.currentHp <= 0 ? 'opacity-40 grayscale' : ''} /><p className="text-xs font-bold">{p.name}</p><p className="text-[10px]">Nv. {p.level} · {p.currentHp}/{p.maxHp} PS</p></div>)}</div></section>;
}
