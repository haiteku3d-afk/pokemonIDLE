import React from 'react';
import { Volume2, VolumeX, Settings, Sparkles, Award, Map, Swords, PackageOpen, BookOpen, Users, Trophy, ShoppingBag, Backpack, Flag, type LucideIcon } from 'lucide-react';
import { retroAudio } from '../utils/audio';
import { ZONES_BY_ID } from '../data/zones';

export type ScreenTab = 'map' | 'expedition' | 'packs' | 'pokedex' | 'team' | 'gyms' | 'trainers' | 'shop' | 'bag';

interface NavbarProps {
  currentTab: ScreenTab;
  onTabChange: (tab: ScreenTab) => void;
  activeZoneId: string;
  activeZonePoints: number;
  trainerTokens?: number;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onOpenSettings: () => void;
  teamCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onTabChange,
  activeZoneId,
  activeZonePoints,
  trainerTokens = 0,
  soundEnabled,
  onToggleSound,
  onOpenSettings,
  teamCount,
}) => {
  const activeZone = ZONES_BY_ID[activeZoneId];

  const handleTabClick = (tab: ScreenTab) => {
    retroAudio.playClick();
    onTabChange(tab);
  };

  const navLinks: { id: ScreenTab; label: string; icon: LucideIcon; badge?: string }[] = [
    { id: 'map', label: 'Mapa', icon: Map },
    { id: 'expedition', label: 'Expedición', icon: Swords },
    { id: 'packs', label: 'Sobres', icon: PackageOpen },
    { id: 'pokedex', label: 'Pokédex', icon: BookOpen },
    { id: 'team', icon: Users, label: `Equipo (${teamCount}/6)` },
    { id: 'gyms', label: 'Gimnasios', icon: Flag },
    { id: 'trainers', label: 'Desafíos', icon: Trophy },
    { id: 'bag', label: 'Mochila', icon: Backpack },
    { id: 'shop', label: 'Tienda', icon: ShoppingBag },
  ];

  return (
    <header className="sticky top-0 z-30 bg-[#f4ecd8]/95 backdrop-blur-md border-b border-[#2d5a43]/20 px-3 sm:px-6 pt-3 pb-2 shadow-[0_4px_20px_rgba(26,61,47,0.08)]">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 sm:gap-4">
        {/* Zona 1: Brand Wordmark */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => handleTabClick('map')}
            className="flex items-center gap-2 text-left group rounded-lg focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#2d5a43]"
          >
            <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-[#d44f33] border-2 border-[#1c2e24] flex flex-col items-center justify-center relative overflow-hidden shadow-xs group-hover:rotate-12 transition-transform">
              <div className="w-full h-1/2 bg-[#d44f33]" />
              <div className="w-full h-1/2 bg-[#f6f2e8]" />
              <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-[2px] bg-[#1c2e24]" />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2.5 h-2.5 rounded-full bg-[#f6f2e8] border-[2px] border-[#1c2e24]" />
            </div>
            <span className="font-['Press_Start_2P'] text-[11px] sm:text-xs tracking-tight text-[#1a3d2f] font-bold">
              Kanto Sobres
            </span>
          </button>
        </div>

        {/* Zona 3: Indicador de Puntos locales y controles primarios */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Puntos de zona activa */}
          <div
            className="hidden md:flex items-center gap-1.5 px-2.5 py-1 bg-[#e7ddc4] border border-[#2d5a43]/20 rounded-md text-xs font-mono text-[#1a3d2f]"
            title={`Puntos acumulados en ${activeZone?.name || 'Zona'}`}
          >
            <Sparkles className="w-3.5 h-3.5 text-[#d89b25]" />
            <span className="truncate max-w-[120px] font-medium text-[11px]">
              {activeZone?.name || 'Kanto'}:
            </span>
            <span className="font-bold tabular-nums text-xs text-[#2d5a43]">
              {activeZonePoints} pts
            </span>
          </div>

          {/* Fichas de Entrenador (Moneda de Desafíos/Tienda) */}
          <button
            type="button"
            onClick={() => handleTabClick('shop')}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-[#ede4cf] hover:bg-[#ded1b5] border border-[#1a3d2f]/30 rounded-md text-xs font-mono text-[#1a3d2f] cursor-pointer transition-colors shadow-2xs"
            title="Fichas de Entrenador disponibles para la Tienda"
          >
            <Award className="w-3.5 h-3.5 text-[#d89b25]" />
            <span className="font-bold tabular-nums text-xs text-[#1a3d2f]">
              {trainerTokens}
            </span>
            <span className="text-[10px] text-[#556b5f] hidden sm:inline">fichas</span>
          </button>

          {/* Botón de Sonido */}
          <button
            onClick={() => {
              onToggleSound();
              retroAudio.playClick();
            }}
            aria-label={soundEnabled ? 'Silenciar efectos' : 'Activar sonido retro'}
            title={soundEnabled ? 'Silenciar efectos' : 'Activar sonido retro'}
            className="min-w-10 min-h-10 flex items-center justify-center p-2 text-[#2d5a43] hover:text-[#1a3d2f] hover:bg-[#e7ddc4] rounded-md transition-colors"
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
            ) : (
              <VolumeX className="w-4 h-4 sm:w-4.5 sm:h-4.5 text-[#8a8a79]" />
            )}
          </button>

          {/* Botón de Guardado / Ajustes */}
          <button
            onClick={() => {
              retroAudio.playClick();
              onOpenSettings();
            }}
            aria-label="Ajustes y Guardado" title="Ajustes y Guardado"
            className="min-w-10 min-h-10 flex items-center justify-center p-2 text-[#2d5a43] hover:text-[#1a3d2f] hover:bg-[#e7ddc4] rounded-md transition-colors"
          >
            <Settings className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
          </button>
        </div>
      </div>
      <nav aria-label="Menú principal" className="max-w-7xl mx-auto mt-3 grid grid-cols-3 md:grid-cols-9 gap-1.5 sm:gap-2">
        {navLinks.map((link) => {
          const isActive = currentTab === link.id;
          const Icon = link.icon;
          return (
            <button
              key={link.id}
              type="button"
              aria-current={isActive ? 'page' : undefined}
              onClick={() => handleTabClick(link.id)}
              className={`group min-h-14 sm:min-h-16 flex flex-col items-center justify-center gap-1 rounded-xl border text-[10px] sm:text-xs font-semibold transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#2d5a43] ${isActive
                ? 'bg-[#1a3d2f] border-[#1a3d2f] text-[#fff6de] shadow-[0_3px_0_#d89b25] -translate-y-0.5'
                : 'bg-[#fffaf0]/70 border-[#2d5a43]/10 text-[#556b5f] hover:bg-[#e6eddb] hover:border-[#2d5a43]/30 hover:text-[#1a3d2f]'
              }`}
            >
              <Icon aria-hidden="true" className={`w-5 h-5 ${isActive ? 'text-[#e9bd61]' : 'text-[#2d5a43]'}`} strokeWidth={1.7} />
              <span>{link.label}</span>
            </button>
          );
        })}
      </nav>
    </header>
  );
};

