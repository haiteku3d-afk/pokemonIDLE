import { ChallengeBattleCard, ChallengeTeam } from './ChallengeBattleCard';
import React, { useState, useEffect, useRef } from 'react';
import {
  Swords,
  Sparkles,
  Trophy,
  CheckCircle,
  Lock,
  Play,
  Pause,
  RotateCcw,
  Zap,
  ShieldAlert,
  Award,
  AlertTriangle,
  ChevronRight,
  Flame,
} from 'lucide-react';
import { GameSave, OwnedPokemon } from '../types/pokemon';
import { KANTO_TRAINERS, TrainerRival } from '../data/trainers';
import { SPECIAL_TRIALS, SpecialTrial } from '../data/specialTrials';
import { POKEMON_BY_ID, TYPE_COLORS } from '../data/pokemon151';
import { PokemonSprite } from './PokemonSprite';
import { calculateMaxHp, calculateStat } from '../utils/pokemonHelpers';
import { getDefaultEquippedMoves } from '../data/speciesLearnsets';
import {
  executeMoveInCombat,
  CombatantSnapshot,
  getAttackIntervalMs,
  getEffectiveSpeed,
  applyStatusTickDamage,
} from '../utils/combatEngine';
import { retroAudio } from '../utils/audio';

interface TrainersScreenProps {
  save: GameSave;
  team: OwnedPokemon[];
  onDefeatTrainer: (trainerId: string, tokens: number) => void;
  onCompleteTrial: (trialId: 'double_trial' | 'triple_trial') => void;
  onGoToShop: () => void;
}

interface BattleCombatant extends CombatantSnapshot {
  realLevel?: number;
}

export const TrainersScreen: React.FC<TrainersScreenProps> = ({
  save,
  team,
  onDefeatTrainer,
  onCompleteTrial,
  onGoToShop,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'trainers' | 'trials'>('trainers');
  const trainerRewardGrantedRef = useRef(false);

  // --- MODO ENTRENADORES ---
  const [selectedTrainer, setSelectedTrainer] = useState<TrainerRival | null>(null);
  const [trainerCombatState, setTrainerCombatState] = useState<'preview' | 'fighting' | 'won' | 'lost'>('preview');
  const [playerTeamSnapshot, setPlayerTeamSnapshot] = useState<BattleCombatant[]>([]);
  const [rivalTeamSnapshot, setRivalTeamSnapshot] = useState<BattleCombatant[]>([]);
  const [playerActiveIdx, setPlayerActiveIdx] = useState(0);
  const [rivalActiveIdx, setRivalActiveIdx] = useState(0);
  const [combatLogs, setCombatLogs] = useState<string[]>([]);
  const [isCombatPaused, setIsCombatPaused] = useState(false);

  const playerElapsedRef = useRef(0);
  const rivalElapsedRef = useRef(0);
  const [playerElapsedMs, setPlayerElapsedMs] = useState(0);
  const [rivalElapsedMs, setRivalElapsedMs] = useState(0);
  const lastTickRef = useRef<number>(Date.now());
  const isExecutingRef = useRef(false);

  // --- MODO RETOS ESPECIALES ---
  const [selectedTrial, setSelectedTrial] = useState<SpecialTrial | null>(null);
  const [trialCombatState, setTrialCombatState] = useState<'idle' | 'running' | 'failed' | 'completed'>('idle');
  const [currentStreak, setCurrentStreak] = useState(0);
  const [trialFailureReason, setTrialFailureReason] = useState<string | null>(null);
  const [trialLogs, setTrialLogs] = useState<string[]>([]);
  const [isTrialPaused, setIsTrialPaused] = useState(false);

  // Estados de carriles para retos (1 carril para doble_trial, 2 carriles para triple_trial)
  const [trialLane1Enemy, setTrialLane1Enemy] = useState<BattleCombatant | null>(null);
  const [trialLane2Enemy, setTrialLane2Enemy] = useState<BattleCombatant | null>(null);
  const [trialLane1Elapsed, setTrialLane1Elapsed] = useState({ player: 0, enemy: 0 });
  const [trialLane2Elapsed, setTrialLane2Elapsed] = useState({ player: 0, enemy: 0 });
  const trialLanesElapsedRef = useRef([
    { player: 0, enemy: 0 },
    { player: 0, enemy: 0 },
  ]);

  // =========================================================================
  // GESTIÓN DE COMBATE CONTRA ENTRENADOR
  // =========================================================================
  const handleOpenTrainerPreview = (trainer: TrainerRival) => {
    setSelectedTrainer(trainer);
    setTrainerCombatState('preview');

    const challengeLevel = trainer.challengeLevel;
    // Snapshot del equipo del jugador a Nivel Igualado
    const pSnapshot: BattleCombatant[] = team.map((p) => {
      const spec = POKEMON_BY_ID[p.speciesId];
      const maxHp = calculateMaxHp(spec?.baseStats.hp || 50, challengeLevel, p.ivs.hp);
      const attack = calculateStat(spec?.baseStats.attack || 50, challengeLevel, p.ivs.attack);
      const defense = calculateStat(spec?.baseStats.defense || 50, challengeLevel, p.ivs.defense);
      const spAtk = calculateStat(spec?.baseStats.spAtk || 50, challengeLevel, p.ivs.spAtk);
      const spDef = calculateStat(spec?.baseStats.spDef || 50, challengeLevel, p.ivs.spDef);
      const speed = calculateStat(spec?.baseStats.speed || 50, challengeLevel, p.ivs.speed);

      return {
        name: p.nickname || spec?.name || 'Pokémon',
        speciesId: p.speciesId,
        level: challengeLevel,
        realLevel: p.level,
        types: spec?.types || ['normal'],
        currentHp: maxHp,
        maxHp,
        attack,
        defense,
        spAtk,
        spDef,
        speed,
        stages: { attack: 0, defense: 0, spAtk: 0, spDef: 0, speed: 0 },
        equippedMoves: p.equippedMoves || ['placaje'],
        currentMoveIndex: 0,
        status: null,
        sleepTurns: 0,
        heldItem: p.heldItem || null,
      };
    });

    // Snapshot del equipo del rival a Nivel Igualado
    const rSnapshot: BattleCombatant[] = trainer.team.map((m) => {
      const spec = POKEMON_BY_ID[m.speciesId];
      const maxHp = calculateMaxHp(spec?.baseStats.hp || 50, challengeLevel, 15);
      const attack = calculateStat(spec?.baseStats.attack || 50, challengeLevel, 15);
      const defense = calculateStat(spec?.baseStats.defense || 50, challengeLevel, 15);
      const spAtk = calculateStat(spec?.baseStats.spAtk || 50, challengeLevel, 15);
      const spDef = calculateStat(spec?.baseStats.spDef || 50, challengeLevel, 15);
      const speed = calculateStat(spec?.baseStats.speed || 50, challengeLevel, 15);
      const moves = getDefaultEquippedMoves(m.speciesId, challengeLevel);

      return {
        name: m.name,
        speciesId: m.speciesId,
        level: challengeLevel,
        realLevel: m.level,
        types: spec?.types || ['normal'],
        currentHp: maxHp,
        maxHp,
        attack,
        defense,
        spAtk,
        spDef,
        speed,
        stages: { attack: 0, defense: 0, spAtk: 0, spDef: 0, speed: 0 },
        equippedMoves: moves,
        currentMoveIndex: 0,
        status: null,
        sleepTurns: 0,
      };
    });

    setPlayerTeamSnapshot(pSnapshot);
    setRivalTeamSnapshot(rSnapshot);
    setPlayerActiveIdx(0);
    setRivalActiveIdx(0);
    playerElapsedRef.current = 0;
    rivalElapsedRef.current = 0;
    setPlayerElapsedMs(0);
    setRivalElapsedMs(0);
    lastTickRef.current = Date.now();
    setCombatLogs([trainer.dialogue.intro]);
  };

  const handleStartTrainerBattle = () => {
    trainerRewardGrantedRef.current = false;
    if (playerTeamSnapshot.length === 0) return;
    retroAudio.playHit();
    setTrainerCombatState('fighting');
    playerElapsedRef.current = 0;
    rivalElapsedRef.current = 0;
    setPlayerElapsedMs(0);
    setRivalElapsedMs(0);
    lastTickRef.current = Date.now();
    setCombatLogs((prev) => [
      `¡Comienza el combate contra ${selectedTrainer?.name}!`,
      `Regla aplicada: Niveles igualados a Nv. ${selectedTrainer?.challengeLevel}.`,
      ...prev,
    ]);
  };

  const activePlayerPoke = playerTeamSnapshot[playerActiveIdx];
  const activeRivalPoke = rivalTeamSnapshot[rivalActiveIdx];

  const playerEffectiveSpeed = activePlayerPoke
    ? getEffectiveSpeed(activePlayerPoke.speed, activePlayerPoke.stages.speed, activePlayerPoke.status)
    : 50;
  const playerIntervalMs = getAttackIntervalMs(playerEffectiveSpeed, activePlayerPoke?.equippedMoves[activePlayerPoke.currentMoveIndex % Math.max(1, activePlayerPoke.equippedMoves.length)]);

  const rivalEffectiveSpeed = activeRivalPoke
    ? getEffectiveSpeed(activeRivalPoke.speed, activeRivalPoke.stages.speed, activeRivalPoke.status)
    : 50;
  const rivalIntervalMs = getAttackIntervalMs(rivalEffectiveSpeed, activeRivalPoke?.equippedMoves[activeRivalPoke.currentMoveIndex % Math.max(1, activeRivalPoke.equippedMoves.length)]);

  // Bucle de combate contra entrenador
  useEffect(() => {
    if (
      trainerCombatState !== 'fighting' ||
      isCombatPaused ||
      !selectedTrainer ||
      !activePlayerPoke ||
      !activeRivalPoke ||
      activePlayerPoke.currentHp <= 0 ||
      activeRivalPoke.currentHp <= 0
    ) {
      lastTickRef.current = Date.now();
      return;
    }

    lastTickRef.current = Date.now();

    const intervalId = window.setInterval(() => {
      if (isExecutingRef.current) return;

      const now = Date.now();
      const delta = Math.min(100, Math.max(0, now - lastTickRef.current));
      lastTickRef.current = now;

      if (delta <= 0 || document.hidden) return;

      playerElapsedRef.current += delta;
      rivalElapsedRef.current += delta;

      setPlayerElapsedMs(playerElapsedRef.current);
      setRivalElapsedMs(rivalElapsedRef.current);

      const playerReady = playerElapsedRef.current >= playerIntervalMs;
      const rivalReady = rivalElapsedRef.current >= rivalIntervalMs;

      if (!playerReady && !rivalReady) return;

      isExecutingRef.current = true;

      try {
        setPlayerTeamSnapshot((prevPlayerTeam) => {
          setRivalTeamSnapshot((prevRivalTeam) => {
            const playerPoke = prevPlayerTeam[playerActiveIdx];
            const rivalPoke = prevRivalTeam[rivalActiveIdx];

            if (!playerPoke || !rivalPoke || playerPoke.currentHp <= 0 || rivalPoke.currentHp <= 0) {
              return prevRivalTeam;
            }

            const playerActsFirst =
              playerReady && rivalReady
                ? playerEffectiveSpeed >= rivalEffectiveSpeed
                : playerReady;

            if (playerActsFirst && playerReady) {
              // ACCIÓN DEL JUGADOR
              playerElapsedRef.current = 0;
              setPlayerElapsedMs(0);

              const result = executeMoveInCombat(playerPoke, rivalPoke);
              retroAudio.playHit();

              const nextMoveIdx =
                (playerPoke.currentMoveIndex + 1) % Math.max(1, playerPoke.equippedMoves.length);
              playerPoke.currentMoveIndex = nextMoveIdx;

              rivalPoke.currentHp = Math.max(0, rivalPoke.currentHp - result.damage);
              if (result.recoilDamage) {
                playerPoke.currentHp = Math.max(0, playerPoke.currentHp - result.recoilDamage);
              }

              const playerTick = applyStatusTickDamage(playerPoke);
              if (playerTick.damage > 0) {
                playerPoke.currentHp = Math.max(0, playerPoke.currentHp - playerTick.damage);
              }

              setCombatLogs((logs) => [
                ...(playerTick.logMessage ? [playerTick.logMessage] : []),
                result.logMessage,
                ...logs.slice(0, 6),
              ]);

              if (rivalPoke.currentHp <= 0) {
                rivalPoke.status = null;
                rivalPoke.sleepTurns = 0;
                playerElapsedRef.current = 0;
                rivalElapsedRef.current = 0;
                setPlayerElapsedMs(0);
                setRivalElapsedMs(0);

                setCombatLogs((logs) => [
                  `¡El ${rivalPoke.name} de ${selectedTrainer.name} se ha debilitado!`,
                  ...logs.slice(0, 6),
                ]);

                const nextRivalIdx = rivalActiveIdx + 1;
                if (nextRivalIdx >= prevRivalTeam.length) {
                  // VICTORIA TOTAL
                  prevPlayerTeam.forEach((p) => {
                    p.status = null;
                    p.sleepTurns = 0;
                  });
                  retroAudio.playFanfare();
                  setTrainerCombatState('won');
                  setCombatLogs((logs) => [
                    `¡Has derrotado a ${selectedTrainer.name}!`,
                    selectedTrainer.dialogue.defeat,
                    `¡Recompensa obtenida: +${selectedTrainer.rewardTokens} Fichas de Entrenador!`,
                    ...logs,
                  ]);
                  if (!trainerRewardGrantedRef.current) {
                    trainerRewardGrantedRef.current = true;
                    onDefeatTrainer(selectedTrainer.id, selectedTrainer.rewardTokens);
                  }
                } else {
                  setRivalActiveIdx(nextRivalIdx);
                  setCombatLogs((logs) => [
                    `¡${selectedTrainer.name} envía a ${prevRivalTeam[nextRivalIdx].name} (Nv. ${prevRivalTeam[nextRivalIdx].level})!`,
                    ...logs.slice(0, 6),
                  ]);
                }
                return [...prevRivalTeam];
              }
            } else if (rivalReady) {
              // ACCIÓN DEL RIVAL
              rivalElapsedRef.current = 0;
              setRivalElapsedMs(0);

              const result = executeMoveInCombat(rivalPoke, playerPoke);
              retroAudio.playHit();

              const nextRivalMoveIdx =
                (rivalPoke.currentMoveIndex + 1) % Math.max(1, rivalPoke.equippedMoves.length);
              rivalPoke.currentMoveIndex = nextRivalMoveIdx;

              playerPoke.currentHp = Math.max(0, playerPoke.currentHp - result.damage);
              if (result.recoilDamage) {
                rivalPoke.currentHp = Math.max(0, rivalPoke.currentHp - result.recoilDamage);
              }

              const rivalTick = applyStatusTickDamage(rivalPoke);
              if (rivalTick.damage > 0) {
                rivalPoke.currentHp = Math.max(0, rivalPoke.currentHp - rivalTick.damage);
              }

              setCombatLogs((logs) => [
                ...(rivalTick.logMessage ? [rivalTick.logMessage] : []),
                result.logMessage,
                ...logs.slice(0, 6),
              ]);

              if (playerPoke.currentHp <= 0) {
                playerPoke.status = null;
                playerPoke.sleepTurns = 0;
                playerElapsedRef.current = 0;
                rivalElapsedRef.current = 0;
                setPlayerElapsedMs(0);
                setRivalElapsedMs(0);

                setCombatLogs((logs) => [
                  `¡Tu ${playerPoke.name} se ha debilitado!`,
                  ...logs.slice(0, 6),
                ]);

                const nextPlayerIdx = playerActiveIdx + 1;
                if (nextPlayerIdx >= prevPlayerTeam.length) {
                  // DERROTA
                  prevPlayerTeam.forEach((p) => {
                    p.status = null;
                    p.sleepTurns = 0;
                  });
                  setTrainerCombatState('lost');
                  setCombatLogs((logs) => [
                    `¡Todo tu equipo ha caído ante ${selectedTrainer.name}!`,
                    'Consejo: Ajusta tipos, equipa objetos de combate o entrena los IVs de tu equipo.',
                    ...logs,
                  ]);
                } else {
                  setPlayerActiveIdx(nextPlayerIdx);
                  setCombatLogs((logs) => [
                    `¡Entra al combate ${prevPlayerTeam[nextPlayerIdx].name} (Nv. ${prevPlayerTeam[nextPlayerIdx].level})!`,
                    ...logs.slice(0, 6),
                  ]);
                }
              }
            }

            return [...prevRivalTeam];
          });

          return [...prevPlayerTeam];
        });
      } finally {
        isExecutingRef.current = false;
      }
    }, 50);

    return () => clearInterval(intervalId);
  }, [
    trainerCombatState,
    isCombatPaused,
    selectedTrainer,
    playerActiveIdx,
    rivalActiveIdx,
    activePlayerPoke,
    activeRivalPoke,
    playerIntervalMs,
    rivalIntervalMs,
    playerEffectiveSpeed,
    rivalEffectiveSpeed,
    onDefeatTrainer,
    save.completedTrainers,
  ]);

  // =========================================================================
  // GESTIÓN DE RETOS ESPECIALES (DOBLE TRAS BROCK, TRIPLE TRAS SURGE)
  // =========================================================================
  const spawnTrialEnemy = (trial: SpecialTrial, laneIdx: number): BattleCombatant => {
    const rolled = trial.poolRivals[Math.floor(Math.random() * trial.poolRivals.length)];
    const spec = POKEMON_BY_ID[rolled.speciesId];
    const maxHp = calculateMaxHp(spec?.baseStats.hp || 50, trial.challengeLevel, 15);
    const attack = calculateStat(spec?.baseStats.attack || 50, trial.challengeLevel, 15);
    const defense = calculateStat(spec?.baseStats.defense || 50, trial.challengeLevel, 15);
    const spAtk = calculateStat(spec?.baseStats.spAtk || 50, trial.challengeLevel, 15);
    const spDef = calculateStat(spec?.baseStats.spDef || 50, trial.challengeLevel, 15);
    const speed = calculateStat(spec?.baseStats.speed || 50, trial.challengeLevel, 15);
    const moves = getDefaultEquippedMoves(rolled.speciesId, trial.challengeLevel);

    return {
      name: rolled.name,
      speciesId: rolled.speciesId,
      level: trial.challengeLevel,
      types: spec?.types || ['normal'],
      currentHp: maxHp,
      maxHp,
      attack,
      defense,
      spAtk,
      spDef,
      speed,
      stages: { attack: 0, defense: 0, spAtk: 0, spDef: 0, speed: 0 },
      equippedMoves: moves,
      currentMoveIndex: 0,
      status: null,
      sleepTurns: 0,
    };
  };

  const handleStartTrial = (trial: SpecialTrial) => {
    if (!trial.isUnlocked(save) || trial.isCompleted(save) || new Set(team.map(p => p.speciesId)).size < trial.laneCount) return;
    setSelectedTrial(trial);
    setCurrentStreak(0);
    setTrialFailureReason(null);
    setTrialCombatState('running');
    setIsTrialPaused(false);

    // Preparar snapshot de equipo a PS llenos y nivel igualado
    const pSnapshot: BattleCombatant[] = team.map((p) => {
      const spec = POKEMON_BY_ID[p.speciesId];
      const maxHp = calculateMaxHp(spec?.baseStats.hp || 50, trial.challengeLevel, p.ivs.hp);
      const attack = calculateStat(spec?.baseStats.attack || 50, trial.challengeLevel, p.ivs.attack);
      const defense = calculateStat(spec?.baseStats.defense || 50, trial.challengeLevel, p.ivs.defense);
      const spAtk = calculateStat(spec?.baseStats.spAtk || 50, trial.challengeLevel, p.ivs.spAtk);
      const spDef = calculateStat(spec?.baseStats.spDef || 50, trial.challengeLevel, p.ivs.spDef);
      const speed = calculateStat(spec?.baseStats.speed || 50, trial.challengeLevel, p.ivs.speed);

      return {
        name: p.nickname || spec?.name || 'Pokémon',
        speciesId: p.speciesId,
        level: trial.challengeLevel,
        realLevel: p.level,
        types: spec?.types || ['normal'],
        currentHp: maxHp,
        maxHp,
        attack,
        defense,
        spAtk,
        spDef,
        speed,
        stages: { attack: 0, defense: 0, spAtk: 0, spDef: 0, speed: 0 },
        equippedMoves: p.equippedMoves || ['placaje'],
        currentMoveIndex: 0,
        status: null,
        sleepTurns: 0,
        heldItem: p.heldItem || null,
      };
    });

    setPlayerTeamSnapshot(pSnapshot);
    setPlayerActiveIdx(0);

    const enemy1 = spawnTrialEnemy(trial, 0);
    setTrialLane1Enemy(enemy1);

    if (trial.laneCount >= 2) {
      const enemy2 = spawnTrialEnemy(trial, 1);
      setTrialLane2Enemy(enemy2);
    } else {
      setTrialLane2Enemy(null);
    }

    trialLanesElapsedRef.current = [
      { player: 0, enemy: 0 },
      { player: 0, enemy: 0 },
    ];
    setTrialLane1Elapsed({ player: 0, enemy: 0 });
    setTrialLane2Elapsed({ player: 0, enemy: 0 });
    lastTickRef.current = Date.now();
    setTrialLogs([
      `¡Comienza el ${trial.title}!`,
      `Objetivo: Racha de ${trial.targetStreak} victorias seguidas sin debilitaciones.`,
      `Cualquier Pokémon debilitado causará el reinicio inmediato de la racha.`,
    ]);
  };

  // Bucle de simulación para Retos Especiales
  useEffect(() => {
    if (trialCombatState !== 'running' || isTrialPaused || !selectedTrial) {
      lastTickRef.current = Date.now();
      return;
    }

    lastTickRef.current = Date.now();

    const intervalId = window.setInterval(() => {
      const now = Date.now();
      const delta = Math.min(100, Math.max(0, now - lastTickRef.current));
      lastTickRef.current = now;

      if (delta <= 0 || document.hidden) return;

      let victories = 0;
      const enemies = [trialLane1Enemy, trialLane2Enemy];
      for (let lane = 0; lane < selectedTrial.laneCount; lane++) {
        const player = playerTeamSnapshot[lane];
        const enemy = enemies[lane];
        if (!player || !enemy) continue;
        const elapsed = trialLanesElapsedRef.current[lane];
        elapsed.player += delta;
        elapsed.enemy += delta;
        const playerSpeed = getEffectiveSpeed(player.speed, player.stages.speed, player.status);
        const enemySpeed = getEffectiveSpeed(enemy.speed, enemy.stages.speed, enemy.status);
        const playerReady = elapsed.player >= getAttackIntervalMs(playerSpeed, player.equippedMoves[player.currentMoveIndex % Math.max(1, player.equippedMoves.length)]);
        const enemyReady = elapsed.enemy >= getAttackIntervalMs(enemySpeed, enemy.equippedMoves[enemy.currentMoveIndex % Math.max(1, enemy.equippedMoves.length)]);
        const playerFirst = playerReady && (!enemyReady || playerSpeed >= enemySpeed);
        const order = playerFirst ? ['player', 'enemy'] : ['enemy', 'player'];
        for (const side of order) {
          if (player.currentHp <= 0 || enemy.currentHp <= 0) break;
          if (side === 'player' ? !playerReady : !enemyReady) continue;
          const attacker = side === 'player' ? player : enemy;
          const defender = side === 'player' ? enemy : player;
          if (side === 'player') elapsed.player = 0;
          else elapsed.enemy = 0;
          const result = executeMoveInCombat(attacker, defender);
          attacker.currentMoveIndex = (attacker.currentMoveIndex + 1) % Math.max(1, attacker.equippedMoves.length);
          defender.currentHp = Math.max(0, defender.currentHp - result.damage);
          attacker.currentHp = Math.max(0, attacker.currentHp - (result.recoilDamage || 0));
          const tick = applyStatusTickDamage(attacker);
          attacker.currentHp = Math.max(0, attacker.currentHp - tick.damage);
          setTrialLogs(logs => [result.logMessage, ...(tick.logMessage ? [tick.logMessage] : []), ...logs].slice(0, 8));
        }
        if (player.currentHp <= 0) {
          setTrialCombatState('failed');
          setCurrentStreak(0);
          setTrialFailureReason('Tu ' + player.name + ' se debilitó en el combate ' + (lane + 1) + '. Racha reiniciada a 0.');
          return;
        }
        if (enemy.currentHp <= 0) {
          victories++;
          player.status = null;
          player.sleepTurns = 0;
          player.stages = { attack: 0, defense: 0, spAtk: 0, spDef: 0, speed: 0 };
          const nextEnemy = spawnTrialEnemy(selectedTrial, lane);
          if (lane === 0) setTrialLane1Enemy(nextEnemy);
          else setTrialLane2Enemy(nextEnemy);
          elapsed.player = 0;
          elapsed.enemy = 0;
        }
        if (lane === 0) setTrialLane1Elapsed({ ...elapsed });
        else setTrialLane2Elapsed({ ...elapsed });
      }
      // Evaluar todas las bajas antes de conceder victorias o el desbloqueo.
      if (victories > 0) {
        const nextStreak = Math.min(selectedTrial.targetStreak, currentStreak + victories);
        setCurrentStreak(nextStreak);
        setTrialLogs(logs => ['Racha: ' + nextStreak + '/' + selectedTrial.targetStreak, ...logs].slice(0, 8));
        if (nextStreak >= selectedTrial.targetStreak) {
          setTrialCombatState('completed');
          retroAudio.playFanfare();
          onCompleteTrial(selectedTrial.id);
        }
      }
    }, 50);

    return () => clearInterval(intervalId);
  }, [
    trialCombatState,
    isTrialPaused,
    selectedTrial,
    currentStreak,
    playerTeamSnapshot,
    trialLane1Enemy,
    trialLane2Enemy,
    onCompleteTrial,
  ]);

  return (
    <div className="max-w-6xl mx-auto px-3 sm:px-6 py-4 flex flex-col gap-4 text-[#1c2e24]">
      {/* Cabecera Principal y Saldo */}
      <div className="bg-[#ede4cf] border-2 border-[#1a3d2f]/30 rounded-xl p-3 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#d44f33]">
            Desafíos Tácticos de Kanto
          </span>
          <h1 className="text-base sm:text-xl font-bold font-['Plus_Jakarta_Sans'] text-[#1a3d2f]">
            Entrenadores y Retos Especiales
          </h1>
          <p className="text-xs text-[#556b5f] mt-0.5">
            Lucha con niveles igualados temporales para ganar Fichas o desbloquear los modos Doble y Triple.
          </p>
        </div>

        {/* Fichas y Acceso a Tienda */}
        <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
          <div className="flex items-center gap-2 px-3 py-1.5 bg-[#f6f2e8] border border-[#d89b25] rounded-lg text-xs font-mono shadow-xs">
            <Sparkles className="w-3.5 h-3.5 text-[#d89b25] fill-[#d89b25]" />
            <span className="text-[#556b5f]">Fichas:</span>
            <span className="font-bold text-sm text-[#1a3d2f] tabular-nums">{save.trainerTokens || 0}</span>
          </div>

          <button
            type="button"
            onClick={onGoToShop}
            className="px-3 py-1.5 bg-[#2d5a43] hover:bg-[#1a3d2f] text-[#f4ecd8] text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <span>Ir a Tienda</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Selector de Subpestañas: Entrenadores vs Retos Especiales */}
      <div className="flex border-b-2 border-[#1a3d2f]/20 gap-2">
        <button
          type="button"
          onClick={() => {
            setSelectedTrainer(null);
            setSelectedTrial(null);
            setActiveSubTab('trainers');
          }}
          className={`px-4 py-2 text-xs sm:text-sm font-bold border-b-2 -mb-[2px] transition-all cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'trainers'
              ? 'border-[#1a3d2f] text-[#1a3d2f] bg-[#ede4cf] rounded-t-lg'
              : 'border-transparent text-[#556b5f] hover:text-[#1a3d2f]'
          }`}
        >
          <Swords className="w-4 h-4" />
          <span>Entrenadores de Kanto ({KANTO_TRAINERS.length})</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setSelectedTrainer(null);
            setSelectedTrial(null);
            setActiveSubTab('trials');
          }}
          className={`px-4 py-2 text-xs sm:text-sm font-bold border-b-2 -mb-[2px] transition-all cursor-pointer flex items-center gap-2 ${
            activeSubTab === 'trials'
              ? 'border-[#1a3d2f] text-[#1a3d2f] bg-[#ede4cf] rounded-t-lg'
              : 'border-transparent text-[#556b5f] hover:text-[#1a3d2f]'
          }`}
        >
          <Flame className="w-4 h-4 text-[#d44f33]" />
          <span>Retos Especiales (Doble / Triple)</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* PESTAÑA 1: ENTRENADORES DE KANTO */}
      {/* ========================================================================= */}
      {activeSubTab === 'trainers' && !selectedTrainer && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {KANTO_TRAINERS.map((trainer) => {
            const unlocked = trainer.isUnlocked(save);
            const isDefeated = save.completedTrainers?.includes(trainer.id);

            return (
              <div
                key={trainer.id}
                className={`p-3.5 rounded-xl border-2 flex flex-col justify-between transition-all ${
                  unlocked
                    ? 'bg-[#ede4cf] border-[#1a3d2f]/30 shadow-xs'
                    : 'bg-[#ede4cf]/50 border-[#1a3d2f]/10 opacity-70'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-sm text-[#1a3d2f]">{trainer.name}</span>
                        <span
                          className={`text-[9px] font-bold uppercase px-1.5 py-0.2 rounded text-white ${
                            trainer.difficulty === 'elite'
                              ? 'bg-[#89389e]'
                              : trainer.difficulty === 'experto'
                              ? 'bg-[#d89b25]'
                              : 'bg-[#3a72b8]'
                          }`}
                        >
                          {trainer.difficulty}
                        </span>
                        {isDefeated && (
                          <span className="text-[9px] font-bold text-[#2d5a43] bg-[#d8ecd8] px-1.5 py-0.2 rounded flex items-center gap-0.5">
                            <CheckCircle className="w-3 h-3 text-[#2d5a43]" />
                            <span>Vencido</span>
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-[#556b5f]">{trainer.title} · {trainer.location}</span>
                    </div>

                    <div className="flex items-center gap-1 px-2 py-0.5 rounded bg-[#f6f2e8] text-xs font-mono font-bold text-[#1a3d2f] border border-[#c8bc9f]">
                      <Sparkles className="w-3.5 h-3.5 text-[#d89b25]" />
                      <span>+{trainer.rewardTokens} fichas</span>
                    </div>
                  </div>

                  <p className="text-xs text-[#415a4d] italic mt-2">«{trainer.dialogue.intro}»</p>

                  {/* Vista del equipo rival */}
                  <div className="mt-3 pt-2 border-t border-[#1a3d2f]/15">
                    <span className="text-[10px] font-mono text-[#556b5f] uppercase block mb-1">
                      Equipo Rival (Nivel Igualado: Nv.{trainer.challengeLevel}):
                    </span>
                    <div className="flex items-center gap-2 flex-wrap">
                      {trainer.team.map((m, mIdx) => (
                        <div
                          key={`rt-${mIdx}`}
                          className="flex items-center gap-1 px-2 py-1 rounded bg-[#f6f2e8] border border-[#c8bc9f] text-[11px]"
                        >
                          <PokemonSprite speciesId={m.speciesId} size="xs" />
                          <span className="font-bold text-[#1a3d2f]">{m.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="mt-3 pt-2.5 border-t border-[#1a3d2f]/15 flex items-center justify-between">
                  <div className="text-[11px] text-[#556b5f]">
                    {unlocked ? (
                      <span className="text-[#2d5a43] font-semibold">Listo para combatir</span>
                    ) : (
                      <span className="text-[#9b3a2b] font-medium flex items-center gap-1">
                        <Lock className="w-3 h-3" />
                        <span>{trainer.unlockRequirementText}</span>
                      </span>
                    )}
                  </div>

                  {unlocked && (
                    <button
                      type="button"
                      onClick={() => handleOpenTrainerPreview(trainer)}
                      className="px-3.5 py-1.5 bg-[#1a3d2f] hover:bg-[#25523f] active:bg-[#122b21] text-[#f4ecd8] text-xs font-bold rounded-lg transition-all flex items-center gap-1 cursor-pointer"
                    >
                      <Swords className="w-3.5 h-3.5" />
                      <span>{isDefeated ? 'Reintentar Combate' : 'Desafiar'}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ARENA DE COMBATE CONTRA ENTRENADOR */}
      {selectedTrainer && (
        <div className="bg-[#ede4cf] border-3 border-[#1a3d2f] rounded-2xl p-4 sm:p-6 flex flex-col gap-4 shadow-md">
          <div className="flex items-center justify-between border-b-2 border-[#1a3d2f]/20 pb-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 bg-[#3a72b8] text-white text-[10px] font-bold uppercase rounded">
                  Combate de Entrenador
                </span>
                <h2 className="text-base sm:text-xl font-bold text-[#1a3d2f]">
                  {selectedTrainer.name} ({selectedTrainer.title})
                </h2>
              </div>
              <p className="text-xs text-[#415a4d] mt-1">
                Niveles igualados temporalmente a Nv. {selectedTrainer.challengeLevel}. Sin EXP ni victorias de ruta. Recompensa: +{selectedTrainer.rewardTokens} fichas.
              </p>
            </div>

            <button
              type="button"
              onClick={() => {
                setSelectedTrainer(null);
                setTrainerCombatState('preview');
              }}
              className="px-3 py-1.5 bg-[#ded1b5] hover:bg-[#c8bc9f] text-[#1a3d2f] text-xs font-bold rounded-lg transition-colors cursor-pointer"
            >
              Cerrar Desafío
            </button>
          </div>

          {trainerCombatState === 'preview' && (
            <div className="space-y-4">
              <div className="p-3 bg-[#f6f2e8] rounded-xl border border-[#c8bc9f] text-xs">
                <p className="italic text-[#415a4d]">«{selectedTrainer.dialogue.intro}»</p>
              </div>

              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={handleStartTrainerBattle}
                  className="px-6 py-2.5 bg-[#1a3d2f] hover:bg-[#25523f] text-[#f4ecd8] text-sm font-bold rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer"
                >
                  <Swords className="w-4 h-4" />
                  <span>Comenzar Combate a Nv. {selectedTrainer.challengeLevel}</span>
                </button>
              </div>
            </div>
          )}

          {trainerCombatState !== 'preview' && (
            <div className="space-y-4">
              <div className="bg-[#e9f0e4] border-4 border-[#1a3d2f] rounded-xl p-3 grid grid-cols-1 sm:grid-cols-2 gap-3">
                {activePlayerPoke && <ChallengeBattleCard pokemon={activePlayerPoke} elapsed={playerElapsedMs} shiny={team.find(p => p.speciesId === activePlayerPoke.speciesId)?.isShiny} />}
                {activeRivalPoke && <ChallengeBattleCard pokemon={activeRivalPoke} elapsed={rivalElapsedMs} />}
              </div>
              {/* Registro de combate */}
              <div className="bg-[#f6f2e8] p-3 rounded-xl border border-[#c8bc9f]">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-[#1a3d2f] uppercase tracking-wide">
                    Registro de Combate
                  </span>
                  {trainerCombatState === 'fighting' && (
                    <button
                      type="button"
                      onClick={() => setIsCombatPaused(!isCombatPaused)}
                      className="text-xs font-bold px-2 py-0.5 rounded bg-[#ede4cf] hover:bg-[#ded1b5] flex items-center gap-1 cursor-pointer"
                    >
                      {isCombatPaused ? <Play className="w-3 h-3" /> : <Pause className="w-3 h-3" />}
                      <span>{isCombatPaused ? 'Reanudar' : 'Pausar'}</span>
                    </button>
                  )}
                </div>

                <div className="max-h-[120px] overflow-y-auto space-y-1 text-xs font-mono pr-1">
                  {combatLogs.map((log, lIdx) => (
                    <div key={`clog-${lIdx}`} className="p-1 rounded bg-[#ede4cf] text-[#1c2e24]">
                      {log}
                    </div>
                  ))}
                </div>
              </div>
              <ChallengeTeam team={playerTeamSnapshot} />
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* PESTAÑA 2: RETOS ESPECIALES (DOBLE Y TRIPLE) */}
      {/* ========================================================================= */}
      {activeSubTab === 'trials' && !selectedTrial && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {SPECIAL_TRIALS.map((trial) => {
            const unlocked = trial.isUnlocked(save);
            const completed = trial.isCompleted(save);

            return (
              <div
                key={trial.id}
                className={`p-4 rounded-xl border-2 flex flex-col justify-between transition-all ${
                  completed
                    ? 'bg-[#eef8ee] border-[#2d5a43]'
                    : unlocked
                    ? 'bg-[#ede4cf] border-[#1a3d2f]/30'
                    : 'bg-[#ede4cf]/50 border-[#1a3d2f]/10 opacity-70'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="font-bold text-sm sm:text-base text-[#1a3d2f] block">{trial.title}</span>
                      <span className="text-xs text-[#556b5f]">{trial.subtitle}</span>
                    </div>

                    {completed ? (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold text-white bg-[#2d5a43] flex items-center gap-1 shrink-0">
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>Completado</span>
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold text-[#1a3d2f] bg-[#f6f2e8] border border-[#c8bc9f] shrink-0">
                        Racha: 0/{trial.targetStreak}
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-[#415a4d] mt-2.5 leading-relaxed">{trial.description}</p>

                  <div className="mt-3 p-2 bg-[#f6f2e8] rounded-lg border border-[#c8bc9f]/60 text-xs">
                    <strong className="text-[#1a3d2f]">Premio Permanente: </strong>
                    <span className="text-[#2d5a43] font-semibold">{trial.rewardText}</span>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-[#1a3d2f]/15 flex items-center justify-between">
                  <div className="text-[11px]">
                    {completed ? (
                      <span className="text-[#2d5a43] font-bold">Modo activo en rutas completadas</span>
                    ) : unlocked ? (
                      <span className="text-[#2d5a43] font-semibold">Desbloqueado para intentar</span>
                    ) : (
                      <span className="text-[#9b3a2b] font-medium flex items-center gap-1">
                        <Lock className="w-3 h-3" />
                        <span>Requiere {trial.badgeName}{trial.requiresTrialId ? ' y Reto Doble' : ''}</span>
                      </span>
                    )}
                  </div>

                  {unlocked && (
                    <button
                      type="button"
                      onClick={() => handleStartTrial(trial)}
                      className="px-4 py-2 bg-[#1a3d2f] hover:bg-[#25523f] active:bg-[#122b21] text-[#f4ecd8] text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <Flame className="w-3.5 h-3.5 text-[#d44f33]" />
                      <span>{completed ? 'Repetir Reto' : 'Iniciar Desafío'}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* PANTALLA ACTIVA DE RETO ESPECIAL */}
      {selectedTrial && (
        <div className="bg-[#ede4cf] border-3 border-[#1a3d2f] rounded-2xl p-4 sm:p-6 flex flex-col gap-4 shadow-md">
          <div className="flex items-center justify-between border-b-2 border-[#1a3d2f]/20 pb-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 bg-[#d44f33] text-white text-[10px] font-bold uppercase rounded">
                  Reto Especial
                </span>
                <h2 className="text-base sm:text-xl font-bold text-[#1a3d2f]">
                  {selectedTrial.title}
                </h2>
              </div>
              <p className="text-xs text-[#415a4d] mt-1">
                Nivel Igualado {selectedTrial.challengeLevel}. ¡Cualquier Pokémon debilitado en tu equipo causará el reinicio inmediato de la racha!
              </p>
            </div>

            <button
              type="button"
              onClick={() => {
                setSelectedTrial(null);
                setTrialCombatState('idle');
                setCurrentStreak(0);
              }}
              className="px-3 py-1.5 bg-[#ded1b5] hover:bg-[#c8bc9f] text-[#1a3d2f] text-xs font-bold rounded-lg transition-colors cursor-pointer"
            >
              Salir del Reto
            </button>
          </div>

          {/* Racha y Estado */}
          <div className="bg-[#f6f2e8] p-3 rounded-xl border border-[#c8bc9f] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-[#d44f33]" />
              <div>
                <span className="text-xs text-[#556b5f] font-mono block">Racha Actual de Victorias:</span>
                <strong className="text-base sm:text-lg text-[#1a3d2f] font-mono">
                  {currentStreak} / {selectedTrial.targetStreak}
                </strong>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {trialCombatState === 'running' && (
                <button
                  type="button"
                  onClick={() => setIsTrialPaused(!isTrialPaused)}
                  className="px-3 py-1.5 rounded-lg bg-[#ede4cf] hover:bg-[#ded1b5] text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  {isTrialPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
                  <span>{isTrialPaused ? 'Reanudar' : 'Pausar'}</span>
                </button>
              )}
            </div>
          </div>

          {/* Aviso de fallo si ocurrió */}
          {trialCombatState === 'failed' && trialFailureReason && (
            <div className="p-3 bg-[#f8e4e4] border-2 border-[#d44f33] rounded-xl text-xs flex items-center justify-between">
              <div className="flex items-center gap-2 text-[#9b3a2b]">
                <AlertTriangle className="w-5 h-5 shrink-0" />
                <span className="font-semibold">{trialFailureReason}</span>
              </div>
              <button
                type="button"
                onClick={() => handleStartTrial(selectedTrial)}
                className="px-3 py-1.5 bg-[#d44f33] hover:bg-[#b03e26] text-white font-bold rounded-lg text-xs cursor-pointer"
              >
                Reintentar desde 0
              </button>
            </div>
          )}

          {trialCombatState === 'completed' && (
            <div className="p-3.5 bg-[#d8ecd8] border-2 border-[#2d5a43] rounded-xl text-xs text-[#2d5a43]">
              <div className="flex items-center gap-2 font-bold text-sm">
                <CheckCircle className="w-5 h-5" />
                <span>¡Reto superado con éxito!</span>
              </div>
              <p className="mt-1">Has desbloqueado permanentemente: {selectedTrial.rewardText}</p>
            </div>
          )}

          <div className="space-y-3">
            {Array.from({ length: selectedTrial.laneCount }).map((_, lane) => {
              const player = playerTeamSnapshot[lane];
              const enemy = lane === 0 ? trialLane1Enemy : trialLane2Enemy;
              const elapsed = lane === 0 ? trialLane1Elapsed : trialLane2Elapsed;
              return <div key={lane} className="bg-[#e9f0e4] border-4 border-[#1a3d2f] rounded-xl p-3">
                <p className="text-xs font-bold mb-2">Combate {lane + 1} · Individual independiente</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {player && <ChallengeBattleCard pokemon={player} elapsed={elapsed.player} />}
                  {enemy && <ChallengeBattleCard pokemon={enemy} elapsed={elapsed.enemy} />}
                </div>
              </div>;
            })}
          </div>
          {/* Registro del Reto */}
          <div className="bg-[#f6f2e8] p-3 rounded-xl border border-[#c8bc9f]">
            <span className="text-xs font-bold text-[#1a3d2f] uppercase tracking-wide block mb-1.5">
              Registro del Reto
            </span>
            <div className="max-h-[100px] overflow-y-auto space-y-1 text-xs font-mono pr-1">
              {trialLogs.map((log, idx) => (
                <div key={`tlog-${idx}`} className="p-1 rounded bg-[#ede4cf] text-[#1c2e24]">
                  {log}
                </div>
              ))}
            </div>
          </div>
          <ChallengeTeam team={playerTeamSnapshot} />
        </div>
      )}
    </div>
  );
};



