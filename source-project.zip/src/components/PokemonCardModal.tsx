import React, { useState } from 'react';
import {
  Sparkles,
  ArrowUp,
  ArrowDown,
  Info,
  Shield,
  Swords,
  Zap,
  Heart,
  Plus,
  Trash2,
  Lock,
  Check,
  RotateCw,
  RefreshCw,
  X,
} from 'lucide-react';
import { OwnedPokemon, StatKey } from '../types/pokemon';
import { POKEMON_BY_ID, TYPE_COLORS } from '../data/pokemon151';
import { PokemonSprite } from './PokemonSprite';
import { getNextIvCost } from '../utils/pokemonHelpers';
import { MOVES_DATA } from '../data/moves';
import { SPECIES_LEARNSETS, getUnlockedMovesForSpecies } from '../data/speciesLearnsets';
import { getLevelCap, getEffectiveLevel } from '../utils/levelCaps';
import { getAvailableItemEvolutions, SHOP_ITEMS_BY_ID, SHOP_ITEMS } from '../data/items';
import { retroAudio } from '../utils/audio';

interface PokemonCardModalProps {
  isOpen: boolean;
  pokemon: OwnedPokemon | null;
  badges?: string[];
  inventory?: Record<string, number>;
  onClose: () => void;
  onUpgradeIv: (pokemonUid: string, statKey: StatKey) => void;
  onUpdateMoves: (pokemonUid: string, moves: string[]) => void;
  onEvolveWithItem?: (pokemonUid: string, targetSpeciesId: number, itemId: string) => void;
  onEquipItem?: (pokemonUid: string, itemId: string) => void;
  onUnequipItem?: (pokemonUid: string) => void;
  isGymBattleActive?: boolean;
  isCombatActive?: boolean;
}

interface StatRowDefinition {
  key: StatKey;
  label: string;
  shortLabel: string;
  baseValue: number;
  currentIv: number;
  currentCalculated: number;
}

export const PokemonCardModal: React.FC<PokemonCardModalProps> = ({
  isOpen,
  pokemon,
  badges = [],
  inventory = {},
  onClose,
  onUpgradeIv,
  onUpdateMoves,
  onEvolveWithItem,
  onEquipItem,
  onUnequipItem,
  isGymBattleActive = false,
  isCombatActive = false,
}) => {
  const disableInCombat = isGymBattleActive || isCombatActive;
  const [activeTab, setActiveTab] = useState<'stats' | 'moves' | 'items'>('stats');

  // Estado para confirmación segura de evolución por objeto
  const [confirmingEvolution, setConfirmingEvolution] = useState<{
    targetSpeciesId: number;
    requiredItemId: string;
    targetName: string;
    itemName: string;
  } | null>(null);

  // Estado para reemplazo explícito de ranura cuando hay 4 movimientos equipados
  const [replacingSlotTarget, setReplacingSlotTarget] = useState<number | null>(null);
  const [pickingSlotForMoveId, setPickingSlotForMoveId] = useState<string | null>(null);

  if (!isOpen || !pokemon) return null;

  const species = POKEMON_BY_ID[pokemon.speciesId];
  if (!species) return null;

  const capInfo = getLevelCap(badges);
  const effectiveLevel = getEffectiveLevel(pokemon.level, badges);
  const isCapped = pokemon.level > effectiveLevel;

  const statsList: StatRowDefinition[] = [
    {
      key: 'hp',
      label: 'Puntos de Salud (PS)',
      shortLabel: 'PS',
      baseValue: species.baseStats.hp,
      currentIv: pokemon.ivs.hp,
      currentCalculated: pokemon.maxHp,
    },
    {
      key: 'attack',
      label: 'Ataque Físico',
      shortLabel: 'Ataque',
      baseValue: species.baseStats.attack,
      currentIv: pokemon.ivs.attack,
      currentCalculated: pokemon.attack,
    },
    {
      key: 'defense',
      label: 'Defensa Física',
      shortLabel: 'Defensa',
      baseValue: species.baseStats.defense,
      currentIv: pokemon.ivs.defense,
      currentCalculated: pokemon.defense,
    },
    {
      key: 'spAtk',
      label: 'Ataque Especial',
      shortLabel: 'Atq. Esp',
      baseValue: species.baseStats.spAtk,
      currentIv: pokemon.ivs.spAtk,
      currentCalculated: pokemon.spAtk,
    },
    {
      key: 'spDef',
      label: 'Defensa Especial',
      shortLabel: 'Def. Esp',
      baseValue: species.baseStats.spDef,
      currentIv: pokemon.ivs.spDef,
      currentCalculated: pokemon.spDef,
    },
    {
      key: 'speed',
      label: 'Velocidad',
      shortLabel: 'Velocidad',
      baseValue: species.baseStats.speed,
      currentIv: pokemon.ivs.speed,
      currentCalculated: pokemon.speed,
    },
  ];

  const handleUpgradeClick = (statKey: StatKey) => {
    const currentIv = pokemon.ivs[statKey];
    const cost = getNextIvCost(currentIv);
    if (pokemon.upgradeCopies < cost || currentIv >= 31) return;

    retroAudio.playRareChime();
    onUpgradeIv(pokemon.uid, statKey);
  };

  // Movimientos equipados actuales (hasta 4)
  const equippedMoves = pokemon.equippedMoves || ['placaje'];

  // Movimientos desbloqueados por nivel real de la especie
  const allUnlockedMoves = [...getUnlockedMovesForSpecies(pokemon.speciesId, pokemon.level), ...(pokemon.taughtMoves || []).map(moveId => ({ moveId, level: 1 }))].filter((move, index, all) => all.findIndex(other => other.moveId === move.moveId) === index);

  // Próximos movimientos por nivel
  const allSpeciesMoves = SPECIES_LEARNSETS[pokemon.speciesId] || [];
  const futureMoves = allSpeciesMoves.filter(
    (m) => m.level > pokemon.level && MOVES_DATA[m.moveId]
  );

  // Reordenar hacia arriba
  const handleMoveUp = (index: number) => {
    if (isGymBattleActive || index <= 0) return;
    retroAudio.playClick();
    const newMoves = [...equippedMoves];
    const temp = newMoves[index - 1];
    newMoves[index - 1] = newMoves[index];
    newMoves[index] = temp;
    onUpdateMoves(pokemon.uid, newMoves);
  };

  // Reordenar hacia abajo
  const handleMoveDown = (index: number) => {
    if (isGymBattleActive || index >= equippedMoves.length - 1) return;
    retroAudio.playClick();
    const newMoves = [...equippedMoves];
    const temp = newMoves[index + 1];
    newMoves[index + 1] = newMoves[index];
    newMoves[index] = temp;
    onUpdateMoves(pokemon.uid, newMoves);
  };

  // Desequipar movimiento (conservando al menos 1)
  const handleUnequip = (index: number) => {
    if (isGymBattleActive || equippedMoves.length <= 1) return;
    retroAudio.playClick();
    const newMoves = equippedMoves.filter((_, i) => i !== index);
    onUpdateMoves(pokemon.uid, newMoves);
    setReplacingSlotTarget(null);
    setPickingSlotForMoveId(null);
  };

  // Equipar nuevo movimiento o abrir selector de reemplazo explícito
  const handleEquipClick = (moveId: string, requiredLevel: number) => {
    if (isGymBattleActive) return;
    if (equippedMoves.includes(moveId)) return;

    // Regla D: no equipar movimientos que superen el tope de medallas actual
    if (requiredLevel > capInfo.cap) {
      retroAudio.playClick();
      return;
    }

    if (equippedMoves.length < 4) {
      retroAudio.playCardFlip();
      onUpdateMoves(pokemon.uid, [...equippedMoves, moveId]);
    } else {
      // 4 ranuras llenas: pedir al usuario elegir explícitamente qué ranura reemplazar
      retroAudio.playClick();
      setPickingSlotForMoveId(moveId);
      setReplacingSlotTarget(null);
    }
  };

  // Confirmar reemplazo atómico en una ranura específica
  const handleConfirmReplace = (slotIdx: number, newMoveId: string) => {
    if (isGymBattleActive) return;
    retroAudio.playCardFlip();
    const newMoves = [...equippedMoves];
    newMoves[slotIdx] = newMoveId;
    onUpdateMoves(pokemon.uid, newMoves);
    setPickingSlotForMoveId(null);
    setReplacingSlotTarget(null);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-2 sm:p-4 bg-black/65 backdrop-blur-xs overscroll-contain">
      <div className="relative w-full max-w-2xl bg-[#f6f2e8] border-3 sm:border-4 border-[#1a3d2f] rounded-2xl shadow-2xl flex flex-col text-[#1c2e24] max-h-[94dvh] sm:max-h-[92vh] overflow-hidden">
        {/* Cabecera de la Ficha */}
        <div className="p-3 sm:p-4 bg-[#efe7d3] border-b-2 border-[#1a3d2f]/20 flex items-start justify-between shrink-0">
          <div className="flex items-center gap-3">
            <PokemonSprite speciesId={pokemon.speciesId} shiny={pokemon.isShiny} size="md" />
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-mono text-xs text-[#556b5f]">
                  #{pokemon.speciesId.toString().padStart(3, '0')}
                </span>
                <h2 className="text-base sm:text-xl font-bold text-[#1a3d2f]">
                  {pokemon.nickname || species.name}
                </h2>
                <div className="flex items-center gap-1 font-mono text-xs font-bold text-[#2d5a43] bg-[#d8ecd8] px-2 py-0.5 rounded">
                  {isCapped ? (
                    <span title={`Nivel real ${pokemon.level}, limitado a ${effectiveLevel} por falta de medalla`}>
                      Nv.{effectiveLevel} <span className="text-[10px] text-[#8a8a79]">({pokemon.level})</span>
                    </span>
                  ) : (
                    <span>Nv.{pokemon.level}</span>
                  )}
                </div>
                {isCapped && (
                  <span className="text-[9px] bg-[#d89b25] text-white font-bold px-1.5 py-0.5 rounded">
                    Tope Medalla
                  </span>
                )}
              </div>

              <div className="flex gap-1.5 mt-1">
                {species.types.map((t) => (
                  <span
                    key={t}
                    className="px-2 py-0.5 rounded text-[10px] uppercase font-bold text-white shadow-2xs"
                    style={{ backgroundColor: TYPE_COLORS[t].bg }}
                  >
                    {t}
                  </span>
                ))}
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-[#ded1b5] hover:bg-[#c8bc9f] active:bg-[#b0a489] flex items-center justify-center font-bold text-sm cursor-pointer transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Pestañas: Estadísticas e IVs vs Movimientos */}
        <div className="flex items-center border-b border-[#1a3d2f]/15 bg-[#ede4cf] px-3 sm:px-5 shrink-0">
          <button
            type="button"
            onClick={() => {
              retroAudio.playClick();
              setActiveTab('stats');
            }}
            className={`py-2.5 px-4 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'stats'
                ? 'border-[#1a3d2f] text-[#1a3d2f] bg-[#f6f2e8]'
                : 'border-transparent text-[#556b5f] hover:text-[#1a3d2f]'
            }`}
          >
            Estadísticas e IVs (0-31)
          </button>

          <button
            type="button"
            onClick={() => {
              retroAudio.playClick();
              setActiveTab('moves');
            }}
            className={`py-2.5 px-4 text-xs font-bold border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'moves'
                ? 'border-[#1a3d2f] text-[#1a3d2f] bg-[#f6f2e8]'
                : 'border-transparent text-[#556b5f] hover:text-[#1a3d2f]'
            }`}
          >
            <Swords className="w-3.5 h-3.5 text-[#2d5a43]" />
            <span>Movimientos ({equippedMoves.length}/4)</span>
          </button>

          <button
            type="button"
            onClick={() => {
              retroAudio.playClick();
              setActiveTab('items');
            }}
            className={`py-2.5 px-4 text-xs font-bold border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'items'
                ? 'border-[#1a3d2f] text-[#1a3d2f] bg-[#f6f2e8]'
                : 'border-transparent text-[#556b5f] hover:text-[#1a3d2f]'
            }`}
          >
            <Shield className="w-3.5 h-3.5 text-[#3a72b8]" />
            <span>Objetos y Evolución</span>
            {pokemon.heldItem && (
              <span className="w-2 h-2 rounded-full bg-[#3a72b8]" title="Objeto equipado" />
            )}
          </button>
        </div>

        {/* Cuerpo del Diálogo con Desplazamiento */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-5 space-y-4">
          {/* ======================================================== */}
          {/* PESTAÑA 1: ESTADÍSTICAS E IVS                           */}
          {/* ======================================================== */}
          {activeTab === 'stats' && (
            <div className="space-y-4">
              {/* Panel de Saldo de Copias y Explicación */}
              <div className="bg-[#ede4cf] border border-[#c8bc9f] rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#1a3d2f] text-[#d89b25] flex items-center justify-center shrink-0">
                    <Sparkles className="w-5 h-5 fill-current" />
                  </div>
                  <div>
                    <span className="text-[11px] text-[#556b5f] uppercase font-bold block">
                      Saldo de Copias Repetidas
                    </span>
                    <div className="flex items-baseline gap-2">
                      <span className="text-xl font-bold font-mono text-[#1a3d2f] tabular-nums">
                        {pokemon.upgradeCopies}
                      </span>
                      <span className="text-xs text-[#2d5a43] font-semibold">
                        copias guardadas para la próxima mejora automática
                      </span>
                    </div>
                  </div>
                </div>

                <div className="text-[11px] font-mono text-[#556b5f] bg-[#f6f2e8] px-3 py-1.5 rounded-lg border border-[#c8bc9f] shrink-0">
                  Total repetidos obtenidos:{' '}
                  <strong className="text-[#1a3d2f]">{pokemon.totalDuplicates}</strong>
                </div>
              </div>

              {/* Guía Explicativa del Sistema de IVs */}
              <div className="bg-[#eaf0e6] border border-[#2d5a43]/30 rounded-xl p-3 text-xs text-[#2d5a43] flex items-start gap-2.5">
                <Info className="w-4 h-4 text-[#2d5a43] shrink-0 mt-0.5" />
                <div className="leading-relaxed">
                  <strong>Entrenamiento de IVs (0 a 31):</strong> Las estadísticas base son inmutables
                  y dependen de la especie. Al obtener ejemplares repetidos en sobres, acumulas
                  copias de mejora. Se mejora primero el IV más bajo. El coste por subir un IV es incremental:{' '}
                  <strong>Coste = 2 × IVactual + 1</strong>.
                </div>
              </div>

              {/* Tabla de Estadísticas e IVs */}
              <div className="border-2 border-[#1a3d2f]/30 rounded-xl overflow-hidden bg-[#ede4cf] shadow-2xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-[#1a3d2f] text-[#f4ecd8] border-b border-[#1a3d2f]/40 font-mono text-[11px]">
                        <th className="py-2.5 px-3 font-semibold">Estadística</th>
                        <th className="py-2.5 px-2 text-center font-semibold">Base</th>
                        <th className="py-2.5 px-2 text-center font-semibold">IV (0-31)</th>
                        <th className="py-2.5 px-2 text-center font-semibold">Valor Actual</th>
                        <th className="py-2.5 px-3 text-right font-semibold">Mejora automática</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#c8bc9f]/60 font-mono">
                      {statsList.map((stat) => {
                        const cost = getNextIvCost(stat.currentIv);
                        const isMax = stat.currentIv >= 31;
                        const canAfford = !isMax && pokemon.upgradeCopies >= cost;

                        return (
                          <tr key={stat.key} className="hover:bg-[#f4ecd8]/60 transition-colors">
                            <td className="py-2.5 px-3 font-sans">
                              <span className="font-bold text-[#1a3d2f] block">{stat.label}</span>
                            </td>

                            <td className="py-2.5 px-2 text-center text-[#556b5f] font-semibold">
                              {stat.baseValue}
                            </td>

                            <td className="py-2.5 px-2 text-center">
                              <span
                                className={`px-2 py-0.5 rounded font-bold ${
                                  stat.currentIv === 31
                                    ? 'bg-[#d89b25] text-white'
                                    : stat.currentIv > 0
                                    ? 'bg-[#d8ecd8] text-[#2d5a43]'
                                    : 'bg-[#e0d6bd] text-[#556b5f]'
                                }`}
                              >
                                {stat.currentIv}/31
                              </span>
                            </td>

                            <td className="py-2.5 px-2 text-center font-bold text-sm text-[#1a3d2f]">
                              {stat.currentCalculated}
                            </td>

                            <td className="py-2.5 px-3 text-right">
                              {isMax ? (
                                <span className="text-[11px] font-bold text-[#d89b25] uppercase">
                                  ¡Al Tope!
                                </span>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => handleUpgradeClick(stat.key)}
                                  disabled={true}
                                  className={`px-3 py-1.5 rounded-lg font-bold text-xs inline-flex items-center gap-1.5 transition-all ${
                                    canAfford
                                      ? 'bg-[#1a3d2f] hover:bg-[#25523f] active:bg-[#122b21] text-[#f4ecd8] shadow-xs cursor-pointer active:scale-98'
                                      : 'bg-[#ded1b5] text-[#8a8a79] border border-[#c8bc9f] cursor-not-allowed opacity-70'
                                  }`}
                                >
                                  <span>Automático</span>
                                  <span className="text-[10px] opacity-85">({cost} copias)</span>
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* PESTAÑA 2: MOVIMIENTOS EQUIPABLES (HASTA 4)             */}
          {/* ======================================================== */}
          {activeTab === 'moves' && (
            <div className="space-y-4">
              {/* Explicación del Orden Cíclico Automático */}
              <div className="bg-[#ede4cf] border border-[#c8bc9f] rounded-xl p-3.5 text-xs text-[#1c2e24] space-y-1.5 shadow-2xs">
                <div className="flex items-center gap-2 font-bold text-[#1a3d2f]">
                  <RotateCw className="w-4 h-4 text-[#2d5a43]" />
                  <span>Combate Automático por Orden Cíclico:</span>
                </div>
                <p className="text-[11px] sm:text-xs text-[#415a4d] leading-relaxed">
                  En los combates, tu Pokémon ejecuta sus movimientos en orden secuencial (
                  <strong>Ranura 1 → 2 → 3 → 4</strong>). El tiempo entre ataques depende de su
                  Velocidad. Los ataques de estado aplican modificaciones reales a estadísticas y
                  nunca generan daño ficticio.
                </p>
                {isGymBattleActive && (
                  <div className="mt-1 text-[11px] text-[#9b3a2b] font-semibold bg-[#faebd7] p-2 rounded-lg border border-[#d44f33]/30">
                    Nota: Los movimientos no se pueden cambiar en mitad de un desafío de gimnasio
                    para no alterar el combate.
                  </div>
                )}
              </div>

              {/* Selector emergente para reemplazar explícitamente una ranura */}
              {pickingSlotForMoveId && (
                <div className="bg-[#fef5e7] border-2 border-[#d89b25] rounded-xl p-3 sm:p-4 space-y-2 shadow-sm animate-in fade-in duration-150">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-[#1a3d2f]">
                      Elige qué ranura deseas reemplazar por{' '}
                      <strong>{MOVES_DATA[pickingSlotForMoveId]?.name}</strong>:
                    </span>
                    <button
                      type="button"
                      onClick={() => setPickingSlotForMoveId(null)}
                      className="p-1 rounded hover:bg-[#ded1b5] text-[#556b5f] cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {equippedMoves.map((mId, slotIdx) => {
                      const m = MOVES_DATA[mId] || MOVES_DATA['placaje'];
                      return (
                        <button
                          key={`pick-slot-${slotIdx}`}
                          type="button"
                          onClick={() => handleConfirmReplace(slotIdx, pickingSlotForMoveId)}
                          className="p-2 rounded-lg bg-[#f6f2e8] border-2 border-[#1a3d2f]/30 hover:border-[#1a3d2f] text-left transition-colors cursor-pointer shadow-2xs"
                        >
                          <span className="text-[10px] font-bold text-[#d44f33] block">
                            Ranura #{slotIdx + 1}
                          </span>
                          <span className="text-xs font-bold text-[#1a3d2f] truncate block">
                            {m.name}
                          </span>
                          <span className="text-[10px] text-[#556b5f] font-mono">
                            {m.power > 0 ? `Pot ${m.power}` : m.category}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Las 4 Ranuras Equipadas */}
              <div>
                <span className="text-xs font-bold text-[#1a3d2f] uppercase tracking-wide block mb-2">
                  Movimientos Equipados ({equippedMoves.length}/4 Ranuras):
                </span>

                <div className="space-y-2">
                  {[0, 1, 2, 3].map((slotIdx) => {
                    const moveId = equippedMoves[slotIdx];
                    const move = moveId ? MOVES_DATA[moveId] : null;

                    if (move) {
                      return (
                        <div
                          key={`equipped-${move.id}-${slotIdx}`}
                          className="bg-[#f6f2e8] border-2 border-[#1a3d2f] rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-2xs"
                        >
                          <div className="flex items-center gap-2.5">
                            <span className="w-6 h-6 rounded-full bg-[#1a3d2f] text-[#f4ecd8] font-bold font-mono text-xs flex items-center justify-center shrink-0">
                              {slotIdx + 1}
                            </span>
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-bold text-sm text-[#1a3d2f]">{move.name}</span>
                                <span
                                  className="px-1.5 py-0.2 rounded text-[9px] uppercase font-bold text-white"
                                  style={{ backgroundColor: TYPE_COLORS[move.type]?.bg || '#777' }}
                                >
                                  {move.type}
                                </span>
                                <span className="text-[10px] font-mono font-semibold px-1.5 py-0.2 rounded bg-[#ede4cf] text-[#556b5f]">
                                  {move.category === 'fisico'
                                    ? 'Físico'
                                    : move.category === 'especial'
                                    ? 'Especial'
                                    : 'Estado'}
                                </span>
                              </div>
                              <p className="text-[11px] text-[#556b5f] mt-0.5">{move.effect}</p>
                            </div>
                          </div>

                          <div className="flex items-center justify-between sm:justify-end gap-3 pt-1 sm:pt-0 border-t sm:border-t-0 border-[#c8bc9f]/40">
                            <div className="font-mono text-[11px] text-[#2d5a43] flex gap-2">
                              <span>
                                Pot: <strong>{move.category === 'estado' ? '-' : move.power}</strong>
                              </span>
                              <span>
                                Prec: <strong>{move.accuracy}%</strong>
                              </span>
                            </div>

                            <div className="flex items-center gap-1">
                              {/* Reordenar */}
                              <button
                                type="button"
                                onClick={() => handleMoveUp(slotIdx)}
                                disabled={slotIdx === 0 || isGymBattleActive}
                                title="Subir en el orden de combate"
                                className="p-1 rounded bg-[#ded1b5] hover:bg-[#c8bc9f] disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
                              >
                                <ArrowUp className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleMoveDown(slotIdx)}
                                disabled={slotIdx === equippedMoves.length - 1 || isGymBattleActive}
                                title="Bajar en el orden de combate"
                                className="p-1 rounded bg-[#ded1b5] hover:bg-[#c8bc9f] disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
                              >
                                <ArrowDown className="w-3.5 h-3.5" />
                              </button>

                              {/* Quitar */}
                              <button
                                type="button"
                                onClick={() => handleUnequip(slotIdx)}
                                disabled={equippedMoves.length <= 1 || isGymBattleActive}
                                title={
                                  equippedMoves.length <= 1
                                    ? 'Debes conservar al menos 1 movimiento'
                                    : 'Quitar movimiento'
                                }
                                className="p-1 rounded bg-[#f0dede] hover:bg-[#e4c8c8] text-[#b32b2b] disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer ml-1"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    }

                    return (
                      <div
                        key={`empty-slot-${slotIdx}`}
                        className="bg-[#ede4cf]/50 border-2 border-dashed border-[#c8bc9f] rounded-xl p-3 flex items-center justify-between text-xs text-[#8a8a79]"
                      >
                        <div className="flex items-center gap-2">
                          <span className="w-6 h-6 rounded-full bg-[#c8bc9f] text-[#f4ecd8] font-bold font-mono text-xs flex items-center justify-center">
                            {slotIdx + 1}
                          </span>
                          <span>Ranura {slotIdx + 1} libre</span>
                        </div>
                        <span className="text-[11px] italic">
                          Elige un movimiento abajo para equipar
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Movimientos Aprendidos por Nivel para esta Especie */}
              <div>
                <span className="text-xs font-bold text-[#1a3d2f] uppercase tracking-wide block mb-2">
                  Biblioteca de Movimientos Aprendidos:
                </span>

                <div className="space-y-2">
                  {allUnlockedMoves.map((item, idx) => {
                    const move = MOVES_DATA[item.moveId];
                    if (!move) return null;
                    const isEquipped = equippedMoves.includes(move.id);
                    const slotIndex = equippedMoves.indexOf(move.id);

                    // Si el movimiento requiere un nivel por encima del tope actual de medallas (Regla D)
                    const isLockedByCap = item.level > capInfo.cap;

                    return (
                      <div
                        key={`unlocked-${move.id}-${idx}`}
                        className={`p-2.5 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-2 transition-colors ${
                          isEquipped
                            ? 'bg-[#d8ecd8]/70 border-[#2d5a43]/40'
                            : isLockedByCap
                            ? 'bg-[#ede4cf]/50 border-[#c8bc9f] opacity-70'
                            : 'bg-[#ede4cf] border-[#c8bc9f] hover:border-[#8b9d83]'
                        }`}
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-[#1a3d2f] text-[#f4ecd8]">
                              Nv. {item.level}
                            </span>
                            <span className="font-bold text-sm text-[#1a3d2f]">{move.name}</span>
                            <span
                              className="px-1.5 py-0.2 rounded text-[9px] uppercase font-bold text-white"
                              style={{ backgroundColor: TYPE_COLORS[move.type]?.bg || '#777' }}
                            >
                              {move.type}
                            </span>
                            <span className="text-[10px] font-mono text-[#556b5f]">
                              {move.category === 'fisico'
                                ? 'Físico'
                                : move.category === 'especial'
                                ? 'Especial'
                                : 'Estado'}
                            </span>
                          </div>
                          <p className="text-[11px] text-[#556b5f] mt-0.5">{move.effect}</p>
                        </div>

                        <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0">
                          <div className="font-mono text-[11px] text-[#2d5a43] flex gap-2">
                            <span>Pot: {move.category === 'estado' ? '-' : move.power}</span>
                            <span>Prec: {move.accuracy}%</span>
                          </div>

                          {isEquipped ? (
                            <span className="text-[11px] font-bold text-[#2d5a43] flex items-center gap-1 bg-[#ffffff]/60 px-2.5 py-1 rounded-md border border-[#2d5a43]/30">
                              <Check className="w-3.5 h-3.5" />
                              <span>Equipado (R{slotIndex + 1})</span>
                            </span>
                          ) : isLockedByCap ? (
                            <span className="text-[10px] text-[#8a8a79] flex items-center gap-1 bg-[#ded1b5] px-2 py-1 rounded">
                              <Lock className="w-3 h-3" />
                              <span>Tope Nv.{capInfo.cap}</span>
                            </span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleEquipClick(move.id, item.level)}
                              disabled={isGymBattleActive}
                              className="px-3 py-1 bg-[#1a3d2f] hover:bg-[#25523f] active:bg-[#122b21] text-[#f4ecd8] text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1 cursor-pointer"
                            >
                              <Plus className="w-3.5 h-3.5" />
                              <span>{equippedMoves.length < 4 ? 'Equipar' : 'Reemplazar...'}</span>
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Próximos Movimientos a Niveles Superiores */}
              {futureMoves.length > 0 && (
                <div className="pt-2 border-t border-[#c8bc9f]/60">
                  <span className="text-xs font-bold text-[#556b5f] uppercase tracking-wide block mb-2">
                    Próximos Movimientos por Nivel:
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 opacity-75">
                    {futureMoves.map((m, idx) => {
                      const move = MOVES_DATA[m.moveId];
                      if (!move) return null;
                      return (
                        <div
                          key={`future-${move.id}-${idx}`}
                          className="bg-[#ede4cf]/60 border border-[#c8bc9f] rounded-lg p-2 text-xs flex items-center justify-between"
                        >
                          <div className="flex items-center gap-1.5">
                            <Lock className="w-3 h-3 text-[#556b5f]" />
                            <span className="font-bold text-[#1a3d2f]">{move.name}</span>
                            <span
                              className="text-[9px] uppercase px-1 py-0.2 rounded text-white"
                              style={{ backgroundColor: TYPE_COLORS[move.type]?.bg || '#777' }}
                            >
                              {move.type}
                            </span>
                          </div>
                          <span className="font-mono text-[10px] text-[#556b5f] font-semibold">
                            Desbloquea a Nv. {m.level}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ======================================================== */}
          {/* PESTAÑA 3: OBJETOS DE COMBATE Y EVOLUCIÓN               */}
          {/* ======================================================== */}
          {activeTab === 'items' && (
            <div className="space-y-4">
              {/* SECCIÓN A: OBJETO DE COMBATE EQUIPADO */}
              <div className="bg-[#ede4cf] border-2 border-[#1a3d2f]/30 rounded-xl p-3.5 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-[#3a72b8]" />
                    <span className="font-bold text-sm text-[#1a3d2f]">Objeto de Combate Equipado</span>
                  </div>
                  <span className="text-[10px] font-mono text-[#556b5f]">Máximo 1 por Pokémon</span>
                </div>

                {pokemon.heldItem && SHOP_ITEMS_BY_ID[pokemon.heldItem] ? (
                  <div className="bg-[#f6f2e8] p-3 rounded-lg border border-[#c8bc9f] flex items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-[#1a3d2f]">
                          {SHOP_ITEMS_BY_ID[pokemon.heldItem].name}
                        </span>
                        <span className="text-[9px] bg-[#d8e6f8] text-[#3a72b8] font-bold px-1.5 py-0.2 rounded">
                          Equipado
                        </span>
                      </div>
                      <p className="text-xs text-[#415a4d] mt-0.5">
                        {SHOP_ITEMS_BY_ID[pokemon.heldItem].effectText}
                      </p>
                    </div>

                    <button
                      type="button"
                      disabled={disableInCombat}
                      onClick={() => onUnequipItem?.(pokemon.uid)}
                      className="px-3 py-1.5 rounded-lg bg-[#ded1b5] hover:bg-[#c8bc9f] text-[#1a3d2f] text-xs font-bold transition-all cursor-pointer shrink-0 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Desequipar
                    </button>
                  </div>
                ) : (
                  <div className="p-3 bg-[#f6f2e8] rounded-lg border border-[#c8bc9f] text-xs text-[#556b5f] italic">
                    Este Pokémon no tiene ningún objeto de combate equipado.
                  </div>
                )}

                {/* Objetos de combate disponibles en inventario */}
                <div className="pt-2 border-t border-[#1a3d2f]/15">
                  <span className="text-xs font-bold text-[#1a3d2f] block mb-2">
                    Objetos de Combate Disponibles en Inventario:
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    {SHOP_ITEMS.filter((i) => i.category === 'combat').map((item) => {
                      const countAvailable = inventory?.[item.id] || 0;
                      const isCurrentHeld = pokemon.heldItem === item.id;

                      return (
                        <div
                          key={item.id}
                          className="bg-[#f6f2e8] p-2.5 rounded-lg border border-[#c8bc9f] flex flex-col justify-between"
                        >
                          <div>
                            <span className="font-bold text-xs text-[#1a3d2f] block">{item.name}</span>
                            <span className="text-[10px] text-[#415a4d] block mt-0.5">{item.effectText}</span>
                            <span className="font-mono text-[10px] text-[#556b5f] mt-1 block">
                              Disponibles: <strong className="text-[#1a3d2f]">{countAvailable}</strong>
                            </span>
                          </div>

                          <div className="mt-2 pt-1.5 border-t border-[#c8bc9f]/60 flex justify-end">
                            {isCurrentHeld ? (
                              <span className="text-[10px] font-bold text-[#2d5a43] px-2 py-0.5 bg-[#d8ecd8] rounded">
                                En uso
                              </span>
                            ) : (
                              <button
                                type="button"
                                disabled={countAvailable <= 0 || disableInCombat}
                                onClick={() => onEquipItem?.(pokemon.uid, item.id)}
                                className={`px-2.5 py-1 rounded text-xs font-bold transition-all ${
                                  countAvailable > 0 && !disableInCombat
                                    ? 'bg-[#1a3d2f] hover:bg-[#25523f] text-[#f4ecd8] cursor-pointer'
                                    : 'bg-[#d9d0ba] text-[#7a8c80] cursor-not-allowed'
                                }`}
                              >
                                Equipar
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* SECCIÓN B: EVOLUCIÓN POR PIEDRA U OBJETO */}
              <div className="bg-[#ede4cf] border-2 border-[#1a3d2f]/30 rounded-xl p-3.5 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-[#d89b25]" />
                    <span className="font-bold text-sm text-[#1a3d2f]">Evolución por Piedra o Cable Link</span>
                  </div>
                  <span className="text-[10px] font-mono text-[#556b5f]">Consumo único al confirmar</span>
                </div>

                {(() => {
                  const evos = getAvailableItemEvolutions(pokemon.speciesId);
                  if (evos.length === 0) {
                    return (
                      <div className="p-3 bg-[#f6f2e8] rounded-lg border border-[#c8bc9f] text-xs text-[#556b5f] italic">
                        Esta especie no evoluciona mediante piedras elementales ni Cable Link en Kanto.
                      </div>
                    );
                  }

                  return (
                    <div className="space-y-2.5">
                      {evos.map((evo) => {
                        const targetSpec = POKEMON_BY_ID[evo.targetSpeciesId];
                        if (!targetSpec) return null;
                        const countInStock = inventory?.[evo.requiredItemId] || 0;
                        const canEvolve = countInStock > 0 && !disableInCombat;

                        return (
                          <div
                            key={`${evo.targetSpeciesId}-${evo.requiredItemId}`}
                            className="bg-[#f6f2e8] p-3 rounded-xl border border-[#c8bc9f] flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs"
                          >
                            <div className="flex items-center gap-3">
                              <PokemonSprite speciesId={targetSpec.id} size="md" />
                              <div>
                                <div className="flex items-center gap-1.5">
                                  <span className="font-bold text-sm text-[#1a3d2f]">
                                    {targetSpec.name}
                                  </span>
                                  <span className="text-[10px] font-mono text-[#556b5f]">
                                    #{targetSpec.id.toString().padStart(3, '0')}
                                  </span>
                                </div>

                                <div className="flex gap-1 mt-0.5">
                                  {targetSpec.types.map((t) => (
                                    <span
                                      key={t}
                                      className="px-1.5 py-0.2 rounded text-[9px] uppercase font-bold text-white"
                                      style={{ backgroundColor: TYPE_COLORS[t].bg }}
                                    >
                                      {t}
                                    </span>
                                  ))}
                                </div>

                                <div className="text-[11px] text-[#556b5f] mt-1 font-mono">
                                  Requiere: <strong className="text-[#1a3d2f]">{evo.itemName}</strong> (Tienes: {countInStock})
                                </div>
                              </div>
                            </div>

                            <button
                              type="button"
                              disabled={!canEvolve}
                              onClick={() => {
                                setConfirmingEvolution({
                                  targetSpeciesId: evo.targetSpeciesId,
                                  requiredItemId: evo.requiredItemId,
                                  targetName: targetSpec.name,
                                  itemName: evo.itemName,
                                });
                              }}
                              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                                canEvolve
                                  ? 'bg-[#1a3d2f] hover:bg-[#25523f] active:bg-[#122b21] text-[#f4ecd8] cursor-pointer shadow-xs'
                                  : 'bg-[#d9d0ba] text-[#7a8c80] cursor-not-allowed'
                              }`}
                            >
                              <Sparkles className="w-3.5 h-3.5 text-[#d89b25]" />
                              <span>Evolucionar</span>
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}

                {disableInCombat && (
                  <p className="text-[11px] text-[#9b3a2b] italic">
                    * La evolución y equipamiento están deshabilitados durante combates activos para preservar la integridad del combate.
                  </p>
                )}
              </div>
            </div>
          )}

          {/* MODAL DE CONFIRMACIÓN DE EVOLUCIÓN */}
          {confirmingEvolution && (
            <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-2xs flex items-center justify-center p-4">
              <div className="bg-[#f6f2e8] border-3 border-[#1a3d2f] rounded-2xl p-5 max-w-sm w-full shadow-2xl text-[#1c2e24] space-y-4">
                <div className="flex items-center gap-2 text-[#1a3d2f]">
                  <Sparkles className="w-5 h-5 text-[#d89b25]" />
                  <h3 className="font-bold text-base font-['Plus_Jakarta_Sans']">Confirmar Evolución</h3>
                </div>

                <p className="text-xs text-[#415a4d] leading-relaxed">
                  ¿Deseas usar <strong>1x {confirmingEvolution.itemName}</strong> para evolucionar a{' '}
                  <strong>{pokemon.nickname || species.name}</strong> en{' '}
                  <strong>{confirmingEvolution.targetName}</strong>?
                </p>

                <p className="text-[11px] text-[#556b5f] bg-[#ede4cf] p-2.5 rounded-lg border border-[#c8bc9f]">
                  Esta acción consumirá 1 objeto de tu inventario. Se conservarán nivel, EXP, IVs y copias.
                </p>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setConfirmingEvolution(null)}
                    className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-[#ded1b5] hover:bg-[#c8bc9f] text-[#1a3d2f] cursor-pointer"
                  >
                    Cancelar
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      retroAudio.playRareChime();
                      onEvolveWithItem?.(
                        pokemon.uid,
                        confirmingEvolution.targetSpeciesId,
                        confirmingEvolution.requiredItemId
                      );
                      setConfirmingEvolution(null);
                    }}
                    className="px-4 py-1.5 rounded-lg text-xs font-bold bg-[#1a3d2f] hover:bg-[#25523f] text-[#f4ecd8] shadow-xs cursor-pointer"
                  >
                    Confirmar Evolución
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};


