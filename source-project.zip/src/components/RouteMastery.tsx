import React from 'react';
import { getRouteMastery } from '../utils/routeMastery';

export function RouteMastery({ victories }: { victories: number }) {
  const mastery = getRouteMastery(victories);
  return <div className="rounded-xl border border-[#d89b25]/40 bg-[#fff7df] p-3 text-xs text-[#1a3d2f]">
    <div className="flex justify-between gap-2 font-bold"><span>Maestría de ruta · {mastery.rank}/5</span><span>{mastery.rank}% evolución por sobre</span></div>
    <div className="h-1.5 rounded-full bg-[#e7ddc4] overflow-hidden my-2"><div className="h-full bg-[#d89b25]" style={{ width: `${mastery.nextGoal ? Math.min(100, victories / mastery.nextGoal * 100) : 100}%` }} /></div>
    <p>{mastery.nextGoal ? `${victories}/${mastery.nextGoal} victorias · siguiente mejora: ${mastery.rank + 1}%` : 'Maestría máxima alcanzada'}</p>
    <p className="text-[10px] text-[#756647] mt-1">Puede sustituir una carta por una evolución de la zona. Requiere la medalla de Brock y un tope de nivel suficiente. No incluye piedras ni intercambios.</p>
  </div>;
}
