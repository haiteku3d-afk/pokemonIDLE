import React, { useState } from 'react';
import { Sparkles, Check, FastForward, PlusCircle, Copy } from 'lucide-react';
import { PokemonSprite } from './PokemonSprite';
import { POKEMON_BY_ID, TYPE_COLORS } from '../data/pokemon151';
import { OwnedPokemon } from '../types/pokemon';
import { retroAudio } from '../utils/audio';

export interface DrawnCardResult {
  isShiny?: boolean;
  speciesId: number;
  level: number;
  isNew: boolean;
  newBalance: number; // Saldo actualizado de copias tras esta tirada
  newPokemon?: OwnedPokemon; // Instancia creada solo si es nuevo
}

interface PackOpeningModalProps {
  isOpen: boolean;
  packName: string;
  cards: DrawnCardResult[];
  teamCount: number;
  onAddToTeam: (poke: OwnedPokemon) => void;
  onClose: () => void;
}

export const PackOpeningModal: React.FC<PackOpeningModalProps> = ({
  isOpen,
  packName,
  cards,
  teamCount,
  onAddToTeam,
  onClose,
}) => {
  const [revealedIndices, setRevealedIndices] = useState<number[]>([]);
  const [addedSpeciesIds, setAddedSpeciesIds] = useState<number[]>([]);

  if (!isOpen || cards.length === 0) return null;

  const allRevealed = revealedIndices.length === cards.length;

  const handleRevealCard = (index: number) => {
    if (revealedIndices.includes(index)) return;

    const item = cards[index];
    if (item.isNew) {
      retroAudio.playRareChime();
    } else {
      retroAudio.playCardFlip();
    }

    setRevealedIndices((prev) => [...prev, index]);
  };

  const handleSkipAll = () => {
    retroAudio.playCardFlip();
    setRevealedIndices(cards.map((_, i) => i));
  };

  const handleAddQuick = (poke: OwnedPokemon) => {
    retroAudio.playRareChime();
    setAddedSpeciesIds((prev) => [...prev, poke.speciesId]);
    onAddToTeam(poke);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-2 sm:p-4 bg-black/75 backdrop-blur-xs overscroll-contain">
      <div className="relative w-full max-w-4xl bg-[#f6f2e8] border-3 sm:border-4 border-[#1a3d2f] rounded-2xl shadow-2xl flex flex-col text-[#1c2e24] max-h-[94dvh] sm:max-h-[92vh] overflow-hidden">
        {/* Cabecera fija del Sobre */}
        <div className="flex items-center justify-between border-b-2 border-[#1a3d2f]/20 p-3 sm:p-4 bg-[#efe7d3] shrink-0">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#d44f33]">
              Apertura de Colección
            </span>
            <h2 className="text-sm sm:text-lg font-bold font-['Plus_Jakarta_Sans'] text-[#1a3d2f] truncate">
              {packName} ({cards.length} {cards.length === 1 ? 'carta' : 'cartas'})
            </h2>
          </div>

          <div className="flex items-center gap-2">
            {!allRevealed && (
              <button
                type="button"
                onClick={handleSkipAll}
                className="px-2.5 sm:px-3 py-1.5 bg-[#e7ddc4] hover:bg-[#ded1b5] text-[#1a3d2f] text-xs font-bold rounded-lg border border-[#1a3d2f]/30 transition-colors flex items-center gap-1 cursor-pointer"
              >
                <FastForward className="w-3.5 h-3.5" />
                <span className="hidden xs:inline">Saltar animación</span>
                <span className="xs:hidden">Saltar</span>
              </button>
            )}

            {allRevealed && (
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 sm:px-4 py-1.5 bg-[#1a3d2f] hover:bg-[#25523f] text-[#f4ecd8] text-xs sm:text-sm font-bold rounded-lg shadow-sm transition-colors cursor-pointer"
              >
                Listo
              </button>
            )}
          </div>
        </div>

        {/* Rejilla desplazable de Cartas para Revelar */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-5">
          <div className="grid grid-cols-1 sm:grid-cols-3 md:grid-cols-5 gap-3 sm:gap-3.5">
          {cards.map((item, index) => {
            const isRevealed = revealedIndices.includes(index);
            const species = POKEMON_BY_ID[item.speciesId];
            const isAdded = addedSpeciesIds.includes(item.speciesId);
            const canAdd = item.isNew && item.newPokemon && teamCount < 6 && !isAdded;

            return (
              <div
                key={`${item.speciesId}-${index}`}
                className="flex flex-col items-center justify-center min-h-[220px]"
              >
                {!isRevealed ? (
                  /* Reverso de la Carta */
                  <button
                    type="button"
                    onClick={() => handleRevealCard(index)}
                    className="w-full h-56 sm:h-60 bg-gradient-to-br from-[#1a3d2f] to-[#25523f] border-3 border-[#d89b25] rounded-xl p-3 flex flex-col items-center justify-between shadow-md hover:scale-102 active:scale-98 transition-transform cursor-pointer group"
                  >
                    <div className="text-[10px] font-['Press_Start_2P'] text-[#d89b25] opacity-80">
                      KANTO
                    </div>
                    {/* Pokéball decorativa */}
                    <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-[#f4ecd8] border-3 border-[#1c2e24] relative overflow-hidden flex flex-col items-center justify-center group-hover:rotate-12 transition-transform shadow-xs">
                      <div className="w-full h-1/2 bg-[#d44f33]" />
                      <div className="w-full h-1/2 bg-[#f4ecd8]" />
                      <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-[3px] bg-[#1c2e24]" />
                      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-[#f4ecd8] border-[3px] border-[#1c2e24]" />
                    </div>
                    <span className="text-[11px] font-bold text-[#f4ecd8] underline decoration-[#d89b25]">
                      Toca para revelar
                    </span>
                  </button>
                ) : (
                  /* Anverso de la Carta Revelada */
                  <div
                    className="w-full h-56 sm:h-60 bg-[#ede4cf] border-3 border-[#1a3d2f] rounded-xl p-2.5 flex flex-col justify-between shadow-md relative animate-in fade-in zoom-in duration-200"
                    style={{
                      borderTopColor: TYPE_COLORS[species?.types[0] || 'normal'].bg,
                    }}
                  >
                    {/* Distinción NUEVO vs REPETIDO */}
                    {item.isNew ? (
                      <span className="absolute -top-2.5 -right-1 px-2 py-0.5 bg-[#d44f33] text-white text-[9px] font-['Press_Start_2P'] uppercase rounded-md shadow-xs animate-bounce">
                        ¡NUEVO!
                      </span>
                    ) : (
                      <span className="absolute -top-2.5 -right-1 px-2 py-0.5 bg-[#2d5a43] text-[#f4ecd8] text-[9px] font-bold uppercase rounded-md shadow-xs flex items-center gap-1">
                        <Copy className="w-2.5 h-2.5" />
                        <span>REPETIDO</span>
                      </span>
                    )}

                    {/* Encabezado */}
                    <div className="flex items-center justify-between text-xs font-bold">
                      <span className="text-[#1a3d2f] truncate">{species?.name}</span>
                      <span className="font-mono text-[11px] text-[#556b5f]">Nv.{item.level}</span>
                    </div>

                    {/* Sprite central */}
                    <div className="flex-1 flex items-center justify-center py-1">
                      <PokemonSprite speciesId={item.speciesId} shiny={item.isShiny} size="md" />
                      {item.isShiny && <span className="text-xs font-bold text-[#a47712]">✨ Variocolor</span>}
                    </div>

                    {/* Tipos */}
                    <div className="flex justify-center gap-1 my-1">
                      {species?.types.map((t) => (
                        <span
                          key={t}
                          className="px-1.5 py-0.2 rounded text-[9px] uppercase font-bold text-white"
                          style={{ backgroundColor: TYPE_COLORS[t].bg }}
                        >
                          {t}
                        </span>
                      ))}
                    </div>

                    {/* Estado: Nueva captura vs Copia de mejora */}
                    {item.isNew ? (
                      <div className="text-[10px] text-[#2d5a43] font-bold text-center bg-[#d8ecd8] py-1 rounded border border-[#2d5a43]/30">
                        ¡Especie registrada! (IVs en 0)
                      </div>
                    ) : (
                      <div className="bg-[#f6f2e8] p-1.5 rounded border border-[#c8bc9f] text-center">
                        <div className="text-[11px] font-bold text-[#d89b25] flex items-center justify-center gap-1">
                          <Sparkles className="w-3 h-3 fill-current" />
                          <span>+1 Copia de mejora</span>
                        </div>
                        <div className="text-[10px] font-mono text-[#556b5f] mt-0.5">
                          Saldo: <strong className="text-[#1a3d2f]">{item.newBalance}</strong> copias
                        </div>
                      </div>
                    )}

                    {/* Botón de añadir al equipo: SOLO si es nuevo y hay hueco */}
                    {canAdd && item.newPokemon && (
                      <button
                        type="button"
                        onClick={() => handleAddQuick(item.newPokemon!)}
                        className="mt-1 w-full py-1 bg-[#2d5a43] hover:bg-[#1a3d2f] text-[#f4ecd8] text-[10px] font-bold rounded flex items-center justify-center gap-1 transition-colors cursor-pointer"
                      >
                        <PlusCircle className="w-3 h-3" />
                        <span>Añadir al equipo</span>
                      </button>
                    )}
                    {isAdded && (
                      <div className="mt-1 w-full py-1 bg-[#d8ecd8] text-[#2d5a43] text-[10px] font-bold rounded flex items-center justify-center gap-1">
                        <Check className="w-3 h-3" />
                        <span>En tu equipo</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
          </div>
        </div>

        {/* Resumen Final fijo cuando todas están reveladas */}
        {allRevealed && (
          <div className="bg-[#ede4cf] border-t-2 border-[#1a3d2f]/20 p-3 sm:p-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs shrink-0">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#d89b25] shrink-0" />
              <span className="text-[#1a3d2f]">
                ¡Colección actualizada! Las especies nuevas se unen con IVs en 0.
                Los repetidos se acumulan como <strong>copias de mejora</strong>.
              </span>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="w-full sm:w-auto px-6 py-2.5 bg-[#1a3d2f] hover:bg-[#25523f] text-[#f4ecd8] font-bold rounded-lg shadow-sm transition-colors cursor-pointer text-center"
            >
              Cerrar y Continuar
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
