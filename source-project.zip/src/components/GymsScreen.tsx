import React, { useState, useEffect, useRef } from 'react';
import {
  Award,
  Shield,
  CheckCircle,
  Lock,
  Trophy,
  Sparkles,
  ChevronRight,
  Swords,
  Play,
  Pause,
  RotateCcw,
  Zap,
} from 'lucide-react';
import { GymLeader, OwnedPokemon } from '../types/pokemon';
import { KANTO_GYMS, KANTO_MISSIONS, StoryMission } from '../data/gymsAndMissions';
import { POKEMON_BY_ID, TYPE_COLORS } from '../data/pokemon151';
import { PokemonSprite } from './PokemonSprite';
import { calculateMaxHp, calculateStat } from '../utils/pokemonHelpers';
import { getDefaultEquippedMoves } from '../data/speciesLearnsets';
import { MOVES_DATA } from '../data/moves';
import {
  COMBAT_ACTION_INTERVAL_MS,
  executeMoveInCombat,
  CombatantSnapshot,
  getAttackIntervalMs,
  getCombatMoveId,
  getEffectiveSpeed,
  applyStatusTickDamage,
} from '../utils/combatEngine';
import { retroAudio } from '../utils/audio';

interface GymsScreenProps {
  ownedSpecies?: number[];
  defeatedGyms: string[];
  badges: string[];
  unlockedZones: string[];
  completedMissions: string[];
  zonePoints: Record<string, number>;
  team: OwnedPokemon[];
  onDefeatGym: (gym: GymLeader) => void;
  onClaimMissionReward: (mission: StoryMission) => void;
}

interface GymCombatant extends CombatantSnapshot {
  realLevel?: number;
}

export const GymsScreen: React.FC<GymsScreenProps> = ({
  defeatedGyms,
  badges,
  unlockedZones,
  completedMissions,
  zonePoints,
  ownedSpecies = [],
  team,
  onDefeatGym,
  onClaimMissionReward,
}) => {
  const [activeTab, setActiveTab] = useState<'gyms' | 'missions'>('gyms');

  // Gimnasio seleccionado para el desafío
  const [activeGym, setActiveGym] = useState<GymLeader | null>(null);
  const [combatState, setCombatState] = useState<'preview' | 'fighting' | 'won' | 'lost'>('preview');

  // Snapshots temporales a nivel igualado
  const [playerTeamSnapshot, setPlayerTeamSnapshot] = useState<GymCombatant[]>([]);
  const [leaderTeamSnapshot, setLeaderTeamSnapshot] = useState<GymCombatant[]>([]);
  const [playerActiveIdx, setPlayerActiveIdx] = useState(0);
  const [leaderActiveIdx, setLeaderActiveIdx] = useState(0);

  const [combatLogs, setCombatLogs] = useState<string[]>([]);
  const [isCombatPaused, setIsCombatPaused] = useState(false);

  // Temporizadores independientes basados en velocidad para el combate de gimnasio (Regla A)
  const [playerElapsedMs, setPlayerElapsedMs] = useState(0);
  const [leaderElapsedMs, setLeaderElapsedMs] = useState(0);

  const playerElapsedRef = useRef(0);
  const leaderElapsedRef = useRef(0);
  const lastTickRef = useRef<number>(Date.now());
  const isExecutingRef = useRef(false);

  // Comprobar si el gimnasio está desbloqueado respetando ciudad y líder previo (Regla B)
  const isGymUnlocked = (gym: GymLeader): boolean => {
    // Si requiere gimnasio anterior y no está vencido, está bloqueado
    if (gym.previousGymId && !defeatedGyms.includes(gym.previousGymId)) {
      return false;
    }
    // Si requiere haber llegado a la ciudad/zona y no está desbloqueada, está bloqueado
    if (gym.cityZoneId && !unlockedZones.includes(gym.cityZoneId)) {
      return false;
    }
    return true;
  };

  // Nivel de desafío del gimnasio (máximo nivel del equipo original del líder)
  const getChallengeLevel = (gym: GymLeader): number => {
    return Math.max(...gym.team.map((m) => m.level));
  };

  // Abrir vista previa del gimnasio con niveles igualados
  const handleOpenGymPreview = (gym: GymLeader) => {
    retroAudio.playClick();
    setActiveGym(gym);
    setCombatState('preview');

    const challengeLevel = getChallengeLevel(gym);

    // Snapshot temporal del equipo del jugador a Nivel Igualado con PS llenos
    const playerSnapshot: GymCombatant[] = team.map((p) => {
      const spec = POKEMON_BY_ID[p.speciesId];
      const maxHp = calculateMaxHp(spec?.baseStats.hp || 50, challengeLevel, p.ivs.hp);
      const attack = calculateStat(spec?.baseStats.attack || 50, challengeLevel, p.ivs.attack);
      const defense = calculateStat(spec?.baseStats.defense || 50, challengeLevel, p.ivs.defense);
      const spAtk = calculateStat(spec?.baseStats.spAtk || 50, challengeLevel, p.ivs.spAtk);
      const spDef = calculateStat(spec?.baseStats.spDef || 50, challengeLevel, p.ivs.spDef);
      const speed = calculateStat(spec?.baseStats.speed || 50, challengeLevel, p.ivs.speed);

      return {
        name: p.nickname || spec?.name || 'Pokémon',
        speciesId: p.speciesId,
        level: challengeLevel,
        realLevel: p.level,
        types: spec?.types || ['normal'],
        currentHp: maxHp,
        maxHp,
        attack,
        defense,
        spAtk,
        spDef,
        speed,
        stages: { attack: 0, defense: 0, spAtk: 0, spDef: 0, speed: 0 },
        equippedMoves: p.equippedMoves || ['placaje'],
        currentMoveIndex: 0,
        status: null,
        sleepTurns: 0,
      };
    });

    // Snapshot temporal del equipo del líder a Nivel Igualado
    const leaderSnapshot: GymCombatant[] = gym.team.map((m) => {
      const spec = POKEMON_BY_ID[m.speciesId];
      const maxHp = calculateMaxHp(spec?.baseStats.hp || 50, challengeLevel, 15);
      const attack = calculateStat(spec?.baseStats.attack || 50, challengeLevel, 15);
      const defense = calculateStat(spec?.baseStats.defense || 50, challengeLevel, 15);
      const spAtk = calculateStat(spec?.baseStats.spAtk || 50, challengeLevel, 15);
      const spDef = calculateStat(spec?.baseStats.spDef || 50, challengeLevel, 15);
      const speed = calculateStat(spec?.baseStats.speed || 50, challengeLevel, 15);

      const moves = getDefaultEquippedMoves(m.speciesId, challengeLevel);

      return {
        name: m.name,
        speciesId: m.speciesId,
        level: challengeLevel,
        realLevel: m.level,
        types: spec?.types || ['normal'],
        currentHp: maxHp,
        maxHp,
        attack,
        defense,
        spAtk,
        spDef,
        speed,
        stages: { attack: 0, defense: 0, spAtk: 0, spDef: 0, speed: 0 },
        equippedMoves: moves,
        currentMoveIndex: 0,
        status: null,
        sleepTurns: 0,
      };
    });

    setPlayerTeamSnapshot(playerSnapshot);
    setLeaderTeamSnapshot(leaderSnapshot);
    setPlayerActiveIdx(0);
    setLeaderActiveIdx(0);
    playerElapsedRef.current = 0;
    leaderElapsedRef.current = 0;
    setPlayerElapsedMs(0);
    setLeaderElapsedMs(0);
    lastTickRef.current = Date.now();
    setCombatLogs([gym.dialogue.intro]);
  };

  // Iniciar combate formal a ritmo dinámico por velocidad
  const handleStartBattle = () => {
    if (playerTeamSnapshot.length === 0) return;
    retroAudio.playHit();
    setCombatState('fighting');
    playerElapsedRef.current = 0;
    leaderElapsedRef.current = 0;
    setPlayerElapsedMs(0);
    setLeaderElapsedMs(0);
    lastTickRef.current = Date.now();
    setCombatLogs((prev) => [
      `¡Comienza el combate de gimnasio contra ${activeGym?.name}!`,
      `Regla aplicada: Niveles igualados a Nv. ${activeGym ? getChallengeLevel(activeGym) : 14}.`,
      ...prev,
    ]);
  };

  const activePlayerPoke = playerTeamSnapshot[playerActiveIdx];
  const activeLeaderPoke = leaderTeamSnapshot[leaderActiveIdx];

  const playerEffectiveSpeed = activePlayerPoke
    ? getEffectiveSpeed(activePlayerPoke.speed, activePlayerPoke.stages.speed, activePlayerPoke.status)
    : 50;
  const playerIntervalMs = getAttackIntervalMs(playerEffectiveSpeed, getCombatMoveId(activePlayerPoke, activeLeaderPoke));

  const leaderEffectiveSpeed = activeLeaderPoke
    ? getEffectiveSpeed(activeLeaderPoke.speed, activeLeaderPoke.stages.speed, activeLeaderPoke.status)
    : 50;
  const leaderIntervalMs = getAttackIntervalMs(leaderEffectiveSpeed, getCombatMoveId(activeLeaderPoke, activePlayerPoke));

  // Suspender ticks al ocultar pestaña
  useEffect(() => {
    const handleVis = () => {
      lastTickRef.current = Date.now();
    };
    document.addEventListener('visibilitychange', handleVis);
    return () => document.removeEventListener('visibilitychange', handleVis);
  }, []);

  // Bucle de combate del Gimnasio con temporizadores independientes de velocidad
  useEffect(() => {
    if (
      combatState !== 'fighting' ||
      isCombatPaused ||
      !activeGym ||
      !activePlayerPoke ||
      !activeLeaderPoke ||
      activePlayerPoke.currentHp <= 0 ||
      activeLeaderPoke.currentHp <= 0
    ) {
      lastTickRef.current = Date.now();
      return;
    }

    lastTickRef.current = Date.now();

    const intervalId = window.setInterval(() => {
      if (isExecutingRef.current) return;

      const now = Date.now();
      const delta = Math.min(100, Math.max(0, now - lastTickRef.current));
      lastTickRef.current = now;

      if (delta <= 0 || document.hidden) return;

      playerElapsedRef.current += delta;
      leaderElapsedRef.current += delta;

      setPlayerElapsedMs(playerElapsedRef.current);
      setLeaderElapsedMs(leaderElapsedRef.current);

      const playerReady = playerElapsedRef.current >= playerIntervalMs;
      const leaderReady = leaderElapsedRef.current >= leaderIntervalMs;

      if (!playerReady && !leaderReady) return;

      isExecutingRef.current = true;

      try {
        setPlayerTeamSnapshot((prevPlayerTeam) => {
          setLeaderTeamSnapshot((prevLeaderTeam) => {
            const playerPoke = prevPlayerTeam[playerActiveIdx];
            const leaderPoke = prevLeaderTeam[leaderActiveIdx];

            if (
              !playerPoke ||
              !leaderPoke ||
              playerPoke.currentHp <= 0 ||
              leaderPoke.currentHp <= 0
            ) {
              return prevLeaderTeam;
            }

            // Determinismo en empate: mayor velocidad ataca primero
            const playerActsFirst =
              playerReady && leaderReady
                ? playerEffectiveSpeed >= leaderEffectiveSpeed
                : playerReady;

            if (playerActsFirst && playerReady) {
              // --- ACCIÓN DEL JUGADOR ---
              playerElapsedRef.current = 0;
              setPlayerElapsedMs(0);

              const result = executeMoveInCombat(playerPoke, leaderPoke);
              retroAudio.playHit();

              const nextMoveIdx =
                (playerPoke.currentMoveIndex + 1) %
                Math.max(1, playerPoke.equippedMoves.length);
              playerPoke.currentMoveIndex = nextMoveIdx;

              leaderPoke.currentHp = Math.max(0, leaderPoke.currentHp - result.damage);
              if (result.recoilDamage) {
                playerPoke.currentHp = Math.max(0, playerPoke.currentHp - result.recoilDamage);
              }

              // Tick de daño por estado (Quemadura / Veneno) en el atacante
              const playerTick = applyStatusTickDamage(playerPoke);
              if (playerTick.damage > 0) {
                playerPoke.currentHp = Math.max(0, playerPoke.currentHp - playerTick.damage);
              }

              setCombatLogs((logs) => [
                ...(playerTick.logMessage ? [playerTick.logMessage] : []),
                result.logMessage,
                ...logs.slice(0, 7),
              ]);

              // Comprobar si el Pokémon del líder cayó
              if (leaderPoke.currentHp <= 0) {
                leaderPoke.status = null;
                leaderPoke.sleepTurns = 0;
                playerElapsedRef.current = 0;
                leaderElapsedRef.current = 0;
                setPlayerElapsedMs(0);
                setLeaderElapsedMs(0);

                setCombatLogs((logs) => [
                  `¡El ${leaderPoke.name} de ${activeGym.name} se ha debilitado!`,
                  ...logs.slice(0, 7),
                ]);

                const nextLeaderIdx = leaderActiveIdx + 1;
                if (nextLeaderIdx >= prevLeaderTeam.length) {
                  // ¡VICTORIA TOTAL EN EL GIMNASIO! Limpiar estados
                  prevPlayerTeam.forEach((p) => {
                    p.status = null;
                    p.sleepTurns = 0;
                  });
                  retroAudio.playFanfare();
                  setCombatState('won');
                  setCombatLogs((logs) => [
                    `¡Has derrotado a ${activeGym.name}!`,
                    activeGym.dialogue.defeat,
                    `¡Obtuviste la ${activeGym.badgeName}!`,
                    activeGym.unlocksText,
                    ...logs,
                  ]);
                  onDefeatGym(activeGym);
                } else {
                  setLeaderActiveIdx(nextLeaderIdx);
                  setCombatLogs((logs) => [
                    `¡${activeGym.name} envía a ${prevLeaderTeam[nextLeaderIdx].name} (Nv. ${prevLeaderTeam[nextLeaderIdx].level})!`,
                    ...logs.slice(0, 7),
                  ]);
                }
                return [...prevLeaderTeam];
              }
            } else if (leaderReady) {
              // --- ACCIÓN DEL LÍDER ---
              leaderElapsedRef.current = 0;
              setLeaderElapsedMs(0);

              const result = executeMoveInCombat(leaderPoke, playerPoke);
              retroAudio.playHit();

              const nextLeaderMoveIdx =
                (leaderPoke.currentMoveIndex + 1) %
                Math.max(1, leaderPoke.equippedMoves.length);
              leaderPoke.currentMoveIndex = nextLeaderMoveIdx;

              playerPoke.currentHp = Math.max(0, playerPoke.currentHp - result.damage);
              if (result.recoilDamage) {
                leaderPoke.currentHp = Math.max(0, leaderPoke.currentHp - result.recoilDamage);
              }

              // Tick de daño por estado (Quemadura / Veneno) en el líder
              const leaderTick = applyStatusTickDamage(leaderPoke);
              if (leaderTick.damage > 0) {
                leaderPoke.currentHp = Math.max(0, leaderPoke.currentHp - leaderTick.damage);
              }

              setCombatLogs((logs) => [
                ...(leaderTick.logMessage ? [leaderTick.logMessage] : []),
                result.logMessage,
                ...logs.slice(0, 7),
              ]);

              // Comprobar si el Pokémon del jugador cayó
              if (playerPoke.currentHp <= 0) {
                playerPoke.status = null;
                playerPoke.sleepTurns = 0;
                playerElapsedRef.current = 0;
                leaderElapsedRef.current = 0;
                setPlayerElapsedMs(0);
                setLeaderElapsedMs(0);

                setCombatLogs((logs) => [
                  `¡Tu ${playerPoke.name} se ha debilitado!`,
                  ...logs.slice(0, 7),
                ]);

                const nextPlayerIdx = playerActiveIdx + 1;
                if (nextPlayerIdx >= prevPlayerTeam.length) {
                  // ¡DERROTA EN EL GIMNASIO! Limpiar estados
                  prevPlayerTeam.forEach((p) => {
                    p.status = null;
                    p.sleepTurns = 0;
                  });
                  setCombatState('lost');
                  setCombatLogs((logs) => [
                    `¡Todo tu equipo ha caído en el gimnasio de ${activeGym.name}!`,
                    'Consejo: Tus Pokémon lucharon al nivel igualado. Ajusta tus movimientos, tipos o mejora los IVs de tu equipo.',
                    ...logs,
                  ]);
                } else {
                  setPlayerActiveIdx(nextPlayerIdx);
                  setCombatLogs((logs) => [
                    `¡Entra al combate ${prevPlayerTeam[nextPlayerIdx].name} (Nv. ${prevPlayerTeam[nextPlayerIdx].level})!`,
                    ...logs.slice(0, 7),
                  ]);
                }
              }
            }

            return [...prevLeaderTeam];
          });

          return [...prevPlayerTeam];
        });
      } finally {
        isExecutingRef.current = false;
      }
    }, 50);

    return () => {
      clearInterval(intervalId);
    };
  }, [
    combatState,
    isCombatPaused,
    activeGym,
    playerActiveIdx,
    leaderActiveIdx,
    activePlayerPoke,
    activeLeaderPoke,
    playerIntervalMs,
    leaderIntervalMs,
    playerEffectiveSpeed,
    leaderEffectiveSpeed,
    onDefeatGym,
  ]);

  const playerAttackProgressPct = Math.min(100, (playerElapsedMs / playerIntervalMs) * 100);
  const leaderAttackProgressPct = Math.min(100, (leaderElapsedMs / leaderIntervalMs) * 100);

  const playerTimeRemainingSec = Math.max(0, (playerIntervalMs - playerElapsedMs) / 1000).toFixed(1);
  const leaderTimeRemainingSec = Math.max(0, (leaderIntervalMs - leaderElapsedMs) / 1000).toFixed(1);

  return (
    <div className="max-w-6xl mx-auto px-3 sm:px-6 py-4 flex flex-col gap-4 text-[#1c2e24]">
      {/* Cabecera y Selector de Subpestaña */}
      <div className="bg-[#ede4cf] border-2 border-[#1a3d2f]/30 rounded-xl p-3 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#d44f33]">
            Desafío de Entrenador
          </span>
          <h1 className="text-base sm:text-xl font-bold font-['Plus_Jakarta_Sans'] text-[#1a3d2f]">
            Gimnasios y Misiones de Kanto
          </h1>
          <p className="text-xs sm:text-sm text-[#415a4d] mt-0.5">
            Lucha en igualdad de condiciones con la regla de <strong>Niveles Igualados</strong> de
            gimnasio.
          </p>
        </div>

        {/* Pestañas de Navegación Interna */}
        <div className="flex items-center gap-1 bg-[#f6f2e8] p-1 rounded-lg border border-[#2d5a43]/20 shrink-0">
          <button
            type="button"
            onClick={() => {
              retroAudio.playClick();
              setActiveTab('gyms');
            }}
            className={`px-3 py-1.5 rounded-md text-xs font-bold transition-colors cursor-pointer ${
              activeTab === 'gyms'
                ? 'bg-[#1a3d2f] text-[#f4ecd8]'
                : 'text-[#415a4d] hover:text-[#1a3d2f]'
            }`}
          >
            Líderes de Gimnasio ({defeatedGyms.length}/{KANTO_GYMS.length})
          </button>

          <button
            type="button"
            onClick={() => {
              retroAudio.playClick();
              setActiveTab('missions');
            }}
            className={`px-3 py-1.5 rounded-md text-xs font-bold transition-colors cursor-pointer ${
              activeTab === 'missions'
                ? 'bg-[#1a3d2f] text-[#f4ecd8]'
                : 'text-[#415a4d] hover:text-[#1a3d2f]'
            }`}
          >
            Misiones de los 151 ({completedMissions.length}/{KANTO_MISSIONS.length})
          </button>
        </div>
      </div>

      {/* ========================================================= */}
      {/* SECCIÓN 1: LÍDERES DE GIMNASIO                            */}
      {/* ========================================================= */}
      {activeTab === 'gyms' && !activeGym && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {KANTO_GYMS.map((gym, index) => {
            const isDefeated = defeatedGyms.includes(gym.id);
            const isUnlocked = isGymUnlocked(gym);
            const challengeLevel = getChallengeLevel(gym);

            return (
              <div
                key={gym.id}
                className={`bg-[#ede4cf] border-2 rounded-xl p-4 flex flex-col justify-between gap-3 shadow-xs transition-all ${
                  isDefeated
                    ? 'border-[#2d5a43] bg-[#d8ecd8]/40'
                    : isUnlocked
                    ? 'border-[#1a3d2f] hover:border-[#2d5a43]'
                    : 'border-[#c8bc9f] opacity-60'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2 border-b border-[#c8bc9f]/60 pb-2 mb-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-[#d44f33]">
                          Gimnasio #{index + 1}
                        </span>
                        <h2 className="text-base font-bold text-[#1a3d2f]">{gym.name}</h2>
                      </div>
                      <span className="text-[11px] text-[#556b5f]">
                        {gym.city} · {gym.title}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {isDefeated ? (
                        <span className="px-2.5 py-1 bg-[#2d5a43] text-[#f4ecd8] text-[10px] font-bold uppercase rounded-md flex items-center gap-1">
                          <CheckCircle className="w-3 h-3" />
                          <span>Medalla Obtenida</span>
                        </span>
                      ) : isUnlocked ? (
                        <span className="px-2 py-0.5 bg-[#f6f2e8] text-[#1a3d2f] text-[10px] font-mono font-bold rounded border border-[#1a3d2f]/30">
                          Nv. {challengeLevel} Igualado
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 bg-[#eae3d2] text-[#8a8a79] text-[10px] font-bold rounded flex items-center gap-1">
                          <Lock className="w-3 h-3" />
                          <span>Bloqueado</span>
                        </span>
                      )}
                    </div>
                  </div>

                  <p className="text-xs text-[#415a4d] leading-relaxed mb-2">
                    {gym.unlocksText}
                  </p>

                  {/* Requisito visible si está bloqueado */}
                  {!isUnlocked && gym.unlockRequirementText && (
                    <div className="mb-2 p-2 bg-[#ded1b5] rounded-md text-[10px] text-[#8a8a79] font-medium flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5 text-[#8a8a79] shrink-0" />
                      <span>{gym.unlockRequirementText}</span>
                    </div>
                  )}

                  {/* Equipo del Líder con sprites */}
                  <div className="bg-[#f6f2e8] p-2.5 rounded-lg border border-[#c8bc9f]/60">
                    <span className="text-[10px] uppercase font-bold text-[#556b5f] block mb-1">
                      Equipo del Líder (Desafío a Nv. {challengeLevel}):
                    </span>
                    <div className="flex items-center gap-3 overflow-x-auto py-1">
                      {gym.team.map((member, mIdx) => (
                        <div
                          key={`${member.speciesId}-${mIdx}`}
                          className="flex items-center gap-1.5 shrink-0"
                        >
                          <PokemonSprite speciesId={member.speciesId} size="xs" />
                          <div className="text-[11px]">
                            <span className="font-bold text-[#1a3d2f] block leading-tight">
                              {member.name}
                            </span>
                            <span className="font-mono text-[9px] text-[#556b5f]">
                              Nv. {challengeLevel}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Botón de acción */}
                <div className="flex items-center justify-between pt-1">
                  <div className="text-[11px] text-[#556b5f] font-mono">
                    Recompensa: <strong className="text-[#1a3d2f]">{gym.badgeName}</strong>
                    {gym.rewardItem && ` + ${gym.rewardItem.name}`}
                  </div>

                  {isUnlocked && (
                    <button
                      type="button"
                      onClick={() => handleOpenGymPreview(gym)}
                      className="px-4 py-2 bg-[#1a3d2f] hover:bg-[#25523f] active:bg-[#122b21] text-[#f4ecd8] text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                    >
                      <Swords className="w-3.5 h-3.5" />
                      <span>{isDefeated ? 'Reintentar Desafío' : 'Desafiar Líder'}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL / PANTALLA DE COMBATE DE GIMNASIO CON NIVELES IGUALADOS */}
      {/* ========================================================= */}
      {activeGym && (
        <div className="bg-[#ede4cf] border-3 border-[#1a3d2f] rounded-2xl p-4 sm:p-6 flex flex-col gap-4 shadow-md">
          {/* Cabecera del Desafío */}
          <div className="flex items-center justify-between border-b-2 border-[#1a3d2f]/20 pb-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 bg-[#d44f33] text-white text-[10px] font-bold uppercase rounded">
                  Gimnasio Oficial
                </span>
                <h2 className="text-base sm:text-xl font-bold text-[#1a3d2f]">
                  Combate de Gimnasio: {activeGym.name} ({activeGym.city})
                </h2>
              </div>
              <p className="text-xs text-[#415a4d] mt-1">
                <strong>Regla de Niveles Igualados:</strong> Todos los Pokémon combaten a{' '}
                <strong>Nivel {getChallengeLevel(activeGym)}</strong>. Tu nivel, EXP y PS reales de
                expedición se conservan intactos.
              </p>
            </div>

            <button
              type="button"
              onClick={() => {
                setActiveGym(null);
                setCombatState('preview');
              }}
              className="px-3 py-1.5 bg-[#ded1b5] hover:bg-[#c8bc9f] text-[#1a3d2f] text-xs font-bold rounded-lg transition-colors cursor-pointer"
            >
              Volver a la Lista
            </button>
          </div>

          {/* VISTA PREVIA ANTES DE COMBATIR */}
          {combatState === 'preview' && (
            <div className="space-y-4">
              <div className="bg-[#f6f2e8] p-3.5 rounded-xl border border-[#c8bc9f] flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-[#1a3d2f] text-[#f4ecd8] font-['Press_Start_2P'] text-xs flex items-center justify-center shrink-0">
                  LÍDER
                </div>
                <div>
                  <span className="text-xs font-bold text-[#1a3d2f] block">{activeGym.title}</span>
                  <p className="text-xs text-[#556b5f] italic mt-0.5">«{activeGym.dialogue.intro}»</p>
                </div>
              </div>

              {/* Comparativa de Equipos a Nivel Igualado */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {/* Equipo del Jugador */}
                <div className="bg-[#f6f2e8] p-3 rounded-xl border border-[#c8bc9f]">
                  <span className="text-xs font-bold text-[#1a3d2f] uppercase tracking-wide block mb-2">
                    Tu Equipo ({playerTeamSnapshot.length} miembros):
                  </span>
                  <div className="space-y-2">
                    {playerTeamSnapshot.map((p, idx) => (
                      <div
                        key={`p-preview-${idx}`}
                        className="p-2 rounded-lg bg-[#ede4cf] flex items-center justify-between text-xs"
                      >
                        <div className="flex items-center gap-2">
                          <PokemonSprite speciesId={p.speciesId} size="xs" />
                          <div>
                            <span className="font-bold text-[#1a3d2f] block">{p.name}</span>
                            <span className="text-[10px] text-[#556b5f]">
                              Nivel real: Nv. {p.realLevel} →{' '}
                              <strong>Nivel desafío: Nv. {p.level}</strong>
                            </span>
                          </div>
                        </div>
                        <div className="font-mono text-[11px] text-[#2d5a43] text-right">
                          <div>PS: {p.maxHp}</div>
                          <div className="text-[10px] text-[#556b5f]">
                            {p.equippedMoves.length} movimientos
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Equipo del Líder */}
                <div className="bg-[#f6f2e8] p-3 rounded-xl border border-[#c8bc9f]">
                  <span className="text-xs font-bold text-[#1a3d2f] uppercase tracking-wide block mb-2">
                    Equipo de {activeGym.name} ({leaderTeamSnapshot.length} miembros):
                  </span>
                  <div className="space-y-2">
                    {leaderTeamSnapshot.map((m, idx) => (
                      <div
                        key={`l-preview-${idx}`}
                        className="p-2 rounded-lg bg-[#ede4cf] flex items-center justify-between text-xs"
                      >
                        <div className="flex items-center gap-2">
                          <PokemonSprite speciesId={m.speciesId} size="xs" />
                          <div>
                            <span className="font-bold text-[#1a3d2f] block">{m.name}</span>
                            <span className="text-[10px] text-[#556b5f]">
                              Nivel original: Nv. {m.realLevel} →{' '}
                              <strong>Nivel desafío: Nv. {m.level}</strong>
                            </span>
                          </div>
                        </div>
                        <div className="font-mono text-[11px] text-[#2d5a43] text-right">
                          <div>PS: {m.maxHp}</div>
                          <div className="text-[10px] text-[#556b5f]">
                            {m.equippedMoves.length} movimientos
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Botón de Iniciar */}
              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={handleStartBattle}
                  className="w-full sm:w-auto px-6 py-3 bg-[#1a3d2f] hover:bg-[#25523f] active:bg-[#122b21] text-[#f4ecd8] font-bold text-sm sm:text-base rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Swords className="w-4 h-4" />
                  <span>Comenzar Combate de Gimnasio a Nv. {getChallengeLevel(activeGym)}</span>
                </button>
              </div>
            </div>
          )}

          {/* COMBATE ACTIVO, VICTORIA O DERROTA */}
          {combatState !== 'preview' && (
            <div className="space-y-4">
              {/* Arena del Gimnasio */}
              <div className="relative bg-[#e9f0e4] border-4 border-[#1a3d2f] rounded-xl p-4 sm:p-6 min-h-[320px] flex flex-col justify-between shadow-inner">
                {/* HUD Superior: Pokémon del Líder + Barra Próximo Ataque */}
                <div className="flex justify-end">
                  {activeLeaderPoke && (
                    <div className="bg-[#f6f2e8] border-2 border-[#1a3d2f] rounded-lg p-2.5 w-64 sm:w-76 shadow-xs">
                      <div className="flex items-center justify-between text-xs font-bold">
                        <div className="flex items-center gap-1.5 truncate">
                          <span className="text-[#1a3d2f] truncate">{activeLeaderPoke.name}</span>
                          {activeLeaderPoke.status && (
                            <span
                              className={`px-1 py-0.2 rounded text-[8px] font-bold text-white uppercase ${
                                activeLeaderPoke.status === 'paralisis'
                                  ? 'bg-[#d89b25]'
                                  : activeLeaderPoke.status === 'quemadura'
                                  ? 'bg-[#c54a2a]'
                                  : activeLeaderPoke.status === 'veneno'
                                  ? 'bg-[#89389e]'
                                  : 'bg-[#5176b5]'
                              }`}
                            >
                              {activeLeaderPoke.status === 'paralisis'
                                ? 'PAR'
                                : activeLeaderPoke.status === 'quemadura'
                                ? 'QMD'
                                : activeLeaderPoke.status === 'veneno'
                                ? 'PSN'
                                : 'DOR'}
                            </span>
                          )}
                        </div>
                        <span className="font-mono text-[11px] text-[#d44f33]">
                          Nv.{activeLeaderPoke.level}
                        </span>
                      </div>
                      <div className="mt-1 h-2 bg-[#d9d0ba] rounded-full overflow-hidden">
                        <div
                          className="h-full bg-[#589b43] transition-all duration-300"
                          style={{
                            width: `${Math.max(
                              0,
                              (activeLeaderPoke.currentHp / activeLeaderPoke.maxHp) * 100
                            )}%`,
                          }}
                        />
                      </div>
                      <div className="text-right text-[10px] font-mono text-[#556b5f] mt-0.5">
                        {activeLeaderPoke.currentHp}/{activeLeaderPoke.maxHp} PS (Líder{' '}
                        {leaderActiveIdx + 1}/{leaderTeamSnapshot.length})
                      </div>

                      {/* Barra Próximo Ataque del Líder (Regla A) */}
                      <div className="mt-2 pt-1.5 border-t border-[#c8bc9f]/60">
                        <div className="flex justify-between items-center text-[9px] text-[#556b5f] font-mono">
                          <span className="font-bold text-[#9b3a2b]">
                            Ataque: {leaderTimeRemainingSec}s
                          </span>
                          <span>Vel: {leaderEffectiveSpeed}</span>
                        </div>
                        <div className="h-1.5 bg-[#d9d0ba] rounded-full overflow-hidden mt-0.5">
                          <div
                            className="h-full bg-[#d44f33] transition-all duration-75"
                            style={{ width: `${leaderAttackProgressPct}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Sprites enfrentados */}
                <div className="flex items-center justify-between px-6 sm:px-16 my-3">
                  <div>
                    {activePlayerPoke && (
                      <div className="text-center">
                        <PokemonSprite speciesId={activePlayerPoke.speciesId} size="lg" />
                        <span className="text-[10px] font-bold text-[#1a3d2f] block mt-1">
                          {activePlayerPoke.name}
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="text-xs font-mono font-bold text-[#556b5f] bg-[#ede4cf] px-2.5 py-1 rounded-md border border-[#c8bc9f]">
                    VS
                  </div>

                  <div>
                    {activeLeaderPoke && (
                      <div className="text-center">
                        <PokemonSprite speciesId={activeLeaderPoke.speciesId} size="lg" />
                        <span className="text-[10px] font-bold text-[#1a3d2f] block mt-1">
                          {activeLeaderPoke.name}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* HUD Inferior: Pokémon del Jugador + Barra Próximo Ataque */}
                <div className="flex justify-start">
                  {activePlayerPoke && (
                    <div className="bg-[#f6f2e8] border-2 border-[#1a3d2f] rounded-lg p-2.5 w-64 sm:w-76 shadow-xs">
                      <div className="flex items-center justify-between text-xs font-bold">
                        <div className="flex items-center gap-1.5 truncate">
                          <span className="text-[#1a3d2f] truncate">{activePlayerPoke.name}</span>
                          {activePlayerPoke.status && (
                            <span
                              className={`px-1 py-0.2 rounded text-[8px] font-bold text-white uppercase ${
                                activePlayerPoke.status === 'paralisis'
                                  ? 'bg-[#d89b25]'
                                  : activePlayerPoke.status === 'quemadura'
                                  ? 'bg-[#c54a2a]'
                                  : activePlayerPoke.status === 'veneno'
                                  ? 'bg-[#89389e]'
                                  : 'bg-[#5176b5]'
                              }`}
                            >
                              {activePlayerPoke.status === 'paralisis'
                                ? 'PAR'
                                : activePlayerPoke.status === 'quemadura'
                                ? 'QMD'
                                : activePlayerPoke.status === 'veneno'
                                ? 'PSN'
                                : 'DOR'}
                            </span>
                          )}
                        </div>
                        <span className="font-mono text-[11px] text-[#2d5a43]">
                          Nv.{activePlayerPoke.level}
                        </span>
                      </div>
                      <div className="mt-1 h-2 bg-[#d9d0ba] rounded-full overflow-hidden">
                        <div
                          className="h-full bg-[#589b43] transition-all duration-300"
                          style={{
                            width: `${Math.max(
                              0,
                              (activePlayerPoke.currentHp / activePlayerPoke.maxHp) * 100
                            )}%`,
                          }}
                        />
                      </div>
                      <div className="text-right text-[10px] font-mono text-[#556b5f] mt-0.5">
                        {activePlayerPoke.currentHp}/{activePlayerPoke.maxHp} PS (Equipo{' '}
                        {playerActiveIdx + 1}/{playerTeamSnapshot.length})
                      </div>

                      {/* Barra Próximo Ataque del Jugador (Regla A) */}
                      <div className="mt-2 pt-1.5 border-t border-[#c8bc9f]/60">
                        <div className="flex justify-between items-center text-[9px] text-[#556b5f] font-mono">
                          <span className="font-bold text-[#2d5a43]">
                            Ataque: {playerTimeRemainingSec}s
                          </span>
                          <span>Vel: {playerEffectiveSpeed}</span>
                        </div>
                        <div className="h-1.5 bg-[#d9d0ba] rounded-full overflow-hidden mt-0.5">
                          <div
                            className="h-full bg-[#2d5a43] transition-all duration-75"
                            style={{ width: `${playerAttackProgressPct}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Registro de Combate del Gimnasio */}
              <div className="bg-[#f6f2e8] p-3 rounded-xl border border-[#c8bc9f]">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-[#1a3d2f] uppercase tracking-wide">
                    Registro de Combate de Gimnasio
                  </span>
                  {combatState === 'fighting' && (
                    <button
                      type="button"
                      onClick={() => setIsCombatPaused(!isCombatPaused)}
                      className="text-xs font-bold px-2 py-0.5 rounded bg-[#ede4cf] hover:bg-[#ded1b5] flex items-center gap-1 cursor-pointer"
                    >
                      {isCombatPaused ? <Play className="w-3 h-3" /> : <Pause className="w-3 h-3" />}
                      <span>{isCombatPaused ? 'Reanudar' : 'Pausar'}</span>
                    </button>
                  )}
                </div>

                <div className="max-h-[140px] overflow-y-auto space-y-1 text-xs font-mono pr-1">
                  {combatLogs.map((log, lIdx) => (
                    <div key={`glog-${lIdx}`} className="p-1 rounded bg-[#ede4cf] text-[#1c2e24]">
                      {log}
                    </div>
                  ))}
                </div>
              </div>

              {/* Botón de Reintentar o Salir tras finalizar */}
              {(combatState === 'won' || combatState === 'lost') && (
                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => handleOpenGymPreview(activeGym)}
                    className="px-4 py-2 bg-[#2d5a43] hover:bg-[#1a3d2f] text-[#f4ecd8] text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Reintentar Desafío</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setActiveGym(null);
                      setCombatState('preview');
                    }}
                    className="px-4 py-2 bg-[#ded1b5] hover:bg-[#c8bc9f] text-[#1a3d2f] text-xs font-bold rounded-lg transition-colors cursor-pointer"
                  >
                    Volver a la Lista
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ========================================================= */}
      {/* SECCIÓN 2: MISIONES DE HISTORIA DE LOS 151                */}
      {/* ========================================================= */}
      {activeTab === 'missions' && (
        <div className="space-y-3">
          <div className="bg-[#ede4cf] p-3 rounded-xl border border-[#c8bc9f] text-xs text-[#415a4d]">
            Completa misiones especiales basadas en los eventos clásicos de Kanto (Rojo y Azul) para
            obtener Pokémon únicos, fósiles, iniciales adicionales y caramelos evolutivos.
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {KANTO_MISSIONS.map((mission) => {
              const isCompleted = completedMissions.includes(mission.id);

              // Comprobar requisitos
              let canClaim = !isCompleted;
              if (mission.requiresNoSpecies && ownedSpecies.includes(mission.requiresNoSpecies)) canClaim = false;
              if (mission.badgeRequired && !badges.includes(mission.badgeRequired)) {
                canClaim = false;
              }
              if (mission.zoneRequired && !unlockedZones.includes(mission.zoneRequired)) {
                canClaim = false;
              }
              if (mission.pointsRequired) {
                const currentPts = zonePoints[mission.pointsRequired.zoneId] || 0;
                if (currentPts < mission.pointsRequired.amount) {
                  canClaim = false;
                }
              }

              return (
                <div
                  key={mission.id}
                  className={`bg-[#ede4cf] border-2 rounded-xl p-3.5 flex flex-col justify-between gap-3 shadow-xs transition-colors ${
                    isCompleted
                      ? 'border-[#2d5a43] bg-[#d8ecd8]/30'
                      : canClaim
                      ? 'border-[#d89b25] bg-[#f6f2e8]'
                      : 'border-[#c8bc9f] opacity-75'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between border-b border-[#c8bc9f]/60 pb-1.5 mb-2">
                      <div>
                        <span className="text-[10px] uppercase font-bold text-[#d44f33] tracking-wide block">
                          {mission.location}
                        </span>
                        <h3 className="font-bold text-sm text-[#1a3d2f]">{mission.title}</h3>
                      </div>

                      {isCompleted ? (
                        <span className="text-[10px] font-bold text-[#2d5a43] bg-[#d8ecd8] px-2 py-0.5 rounded flex items-center gap-1">
                          <CheckCircle className="w-3 h-3" />
                          <span>Completada</span>
                        </span>
                      ) : canClaim ? (
                        <span className="text-[10px] font-bold text-[#d89b25] bg-[#fef5e7] px-2 py-0.5 rounded border border-[#d89b25]/30">
                          ¡Lista para Reclamar!
                        </span>
                      ) : (
                        <span className="text-[10px] text-[#8a8a79] flex items-center gap-1">
                          <Lock className="w-3 h-3" />
                          <span>Bloqueada</span>
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-[#556b5f] leading-relaxed mb-2">
                      {mission.description}
                    </p>

                    <div className="bg-[#f6f2e8] p-2 rounded-md border border-[#c8bc9f]/60 text-[11px] text-[#415a4d]">
                      <strong>Requisito:</strong> {mission.requirementText}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-[#c8bc9f]/40">
                    <div className="text-xs font-mono">
                      Recompensa:{' '}
                      <strong className="text-[#1a3d2f]">
                        {mission.reward.speciesName
                          ? `${mission.reward.speciesName} (Nv. ${mission.reward.level})`
                          : `${mission.reward.itemName || 'Objeto'} x${
                              mission.reward.itemCount || 1
                            }`}
                      </strong>
                    </div>

                    {!isCompleted && (
                      <button
                        type="button"
                        onClick={() => onClaimMissionReward(mission)}
                        disabled={!canClaim}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                          canClaim
                            ? 'bg-[#2d5a43] hover:bg-[#1a3d2f] text-[#f4ecd8] cursor-pointer shadow-xs'
                            : 'bg-[#ded1b5] text-[#8a8a79] cursor-not-allowed'
                        }`}
                      >
                        Reclamar
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

