import React, { useId } from 'react';
import { ZoneData } from '../types/pokemon';
import { ZONE_IMAGES } from '../data/zoneImages';

export type PackDesign = 'standard' | 'blue' | 'fishing' | 'surf';
const THEMES = {
  standard: { dark: '#681d28', light: '#c7493b', foil: '#e9c568', label: 'EDICIÓN ROJA' },
  blue: { dark: '#102c68', light: '#477ec4', foil: '#d5e6f7', label: 'EDICIÓN AZUL' },
  fishing: { dark: '#164847', light: '#42a195', foil: '#e4d5a1', label: 'PESCA' },
  surf: { dark: '#123c70', light: '#3fc5dd', foil: '#d5f5fc', label: 'SURF' },
};
const MASCOTS: Record<string, number> = { 'route-1': 16, 'route-2': 13, 'viridian-forest': 25, 'route-3': 21, 'mt-moon': 35, 'route-4': 23, 'pewter-city': 74 };

export function PackArtwork({ className = '', opening = false, zone, design = 'standard', count }: { className?: string; opening?: boolean; zone?: ZoneData; design?: PackDesign; count?: number }) {
  const id = useId().replace(/:/g, '');
  const theme = THEMES[design];
  const table = design === 'blue' ? zone?.blueAlternateTable : design === 'fishing' ? (zone?.fishingTable?.superRod || zone?.fishingTable?.goodRod || zone?.fishingTable?.oldRod) : design === 'surf' ? zone?.surfTable : zone?.encounterTable;
  const species = design === 'standard' && zone && MASCOTS[zone.id] ? MASCOTS[zone.id] : table?.[0]?.speciesId;
  return <svg viewBox="0 0 180 260" role="img" aria-label={`Sobre ${theme.label} de ${zone?.name || 'Kanto'}${count ? ' · ' + count + ' Pokémon' : ''}`} className={`${className} ${opening ? 'pack-opening' : ''}`}>
    <defs>
      <linearGradient id={id} x1="0" y1="0" x2="1" y2="1"><stop stopColor={theme.dark} /><stop offset=".4" stopColor={theme.light} /><stop offset="1" stopColor={theme.dark} /></linearGradient>
      <clipPath id={id + '-view'}><path d="M23 87H157V188H23Z" /></clipPath>
    </defs>
    <path d="M15 7 L165 7 169 250 11 250Z" fill={`url(#${id})`} stroke={theme.foil} strokeWidth={count === 5 ? 5 : 3} />
    <g className={opening ? 'pack-tear' : ''}><path d="M15 7H165V29H15Z" fill={theme.foil} />{Array.from({ length: 18 }, (_, i) => <path key={i} d={`M${19 + i * 8} 9v17`} stroke={theme.dark} opacity=".4" />)}</g>
    <path d="M12 229H168V250H12Z" fill={theme.foil} />
    <path d="M27 35L153 222M27 75L130 228" stroke="#fff" strokeWidth="12" opacity=".1" />
    <text x="90" y="55" textAnchor="middle" fill={theme.foil} fontSize="19" fontWeight="900" letterSpacing="3">KANTO</text>
    <text x="90" y="73" textAnchor="middle" fill="#fff" fontSize="9" fontWeight="bold" letterSpacing="2">{theme.label}</text>
    <g clipPath={`url(#${id}-view)`}>
      {zone && ZONE_IMAGES[zone.id] && <image href={ZONE_IMAGES[zone.id]} x="23" y="87" width="134" height="101" preserveAspectRatio="xMidYMid slice" opacity=".65" />}
      <path d="M23 87H157V188H23Z" fill={theme.dark} opacity=".2" />
      {design === 'fishing' && <path d="M33 111Q58 88 70 119V145Q70 164 55 153" fill="none" stroke={theme.foil} strokeWidth="3" />}
      {(design === 'fishing' || design === 'surf') && <path d="M18 166Q35 150 52 166T86 166T120 166T154 166T188 166M18 178Q35 162 52 178T86 178T120 178T154 178" fill="none" stroke={theme.foil} strokeWidth="3" opacity=".8" />}
      {species && <image href={`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${species}.png`} x="39" y="91" width="106" height="106" style={{ imageRendering: 'pixelated' }} />}
    </g>
    <path d="M23 87H157V188H23Z" fill="none" stroke={theme.foil} strokeWidth="2" />
    <text x="90" y="207" textAnchor="middle" fill="#fff" fontSize={(zone?.name.length || 0) > 20 ? 7 : 10} fontWeight="bold">{zone?.name || 'Colección Kanto'}</text>
    <text x="90" y="220" textAnchor="middle" fill={theme.foil} fontSize="8" letterSpacing="1">{count ? count + ' POKÉMON' : 'DESCUBRE · COLECCIONA'}</text>
    {count === 5 && <path d="m147 35 3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1Z" fill={theme.foil} />}
  </svg>;
}