import React, { useState } from 'react';
import { Search, Sparkles, ArrowRight, Table, Award, Zap, HelpCircle } from 'lucide-react';
import { POKEMON_151, POKEMON_BY_ID, TYPE_COLORS } from '../data/pokemon151';
import { PokedexEntry, PokemonSpecies, PokemonType, OwnedPokemon } from '../types/pokemon';
import { PokemonSprite } from './PokemonSprite';
import { retroAudio } from '../utils/audio';

interface PokedexScreenProps {
  pokedex: Record<number, PokedexEntry>;
  oakCandies: number;
  items: Record<string, number>;
  team: OwnedPokemon[];
  pcBox: OwnedPokemon[];
  onOpenCardModal: (pokemon: OwnedPokemon) => void;
  onEvolvePokemon: (pokemonUid: string, targetSpeciesId: number, consumedItem?: string) => void;
}

export const PokedexScreen: React.FC<PokedexScreenProps> = ({
  pokedex,
  oakCandies,
  items,
  team,
  pcBox,
  onOpenCardModal,
  onEvolvePokemon,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<PokemonType | 'all'>('all');
  const [selectedStatus, setSelectedStatus] = useState<'all' | 'caught' | 'missing'>('all');
  const [inspectSpeciesId, setInspectSpeciesId] = useState<number | null>(null);

  // Estadísticas globales
  const totalCaught = Object.values(pokedex).filter((p) => p.caught).length;
  const totalSeen = Object.values(pokedex).filter((p) => p.seen).length;

  // Filtrado de Pokémon
  const filteredList = POKEMON_151.filter((species) => {
    const matchesSearch =
      species.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      species.id.toString() === searchTerm.trim() ||
      `#${species.id}` === searchTerm.trim();

    if (!matchesSearch) return false;

    if (selectedType !== 'all' && !species.types.includes(selectedType)) {
      return false;
    }

    const entry = pokedex[species.id];
    if (selectedStatus === 'caught' && !entry?.caught) return false;
    if (selectedStatus === 'missing' && entry?.caught) return false;

    return true;
  });

  const inspectedSpecies = inspectSpeciesId ? POKEMON_BY_ID[inspectSpeciesId] : null;
  const inspectedEntry = inspectSpeciesId ? pokedex[inspectSpeciesId] : null;

  // Ejemplar único que el jugador posee de esta especie (en equipo o PC)
  const ownedInstance = inspectSpeciesId
    ? [...team, ...pcBox].find((p) => p.speciesId === inspectSpeciesId)
    : null;

  const handleInspect = (id: number) => {
    retroAudio.playClick();
    setInspectSpeciesId(id);
  };

  return (
    <div className="max-w-6xl mx-auto px-3 sm:px-6 py-4 flex flex-col gap-4 text-[#1c2e24]">
      {/* Cabecera y Contador de la Pokédex */}
      <div className="bg-[#ede4cf] border-2 border-[#1a3d2f]/30 rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#d44f33]">
            Enciclopedia Oficial de Kanto
          </span>
          <h1 className="text-lg sm:text-xl font-bold font-['Plus_Jakarta_Sans'] text-[#1a3d2f]">
            Pokédex Nacional de 151 Especies
          </h1>
          <p className="text-xs sm:text-sm text-[#415a4d] mt-1">
            Colección única por especie. Los repetidos se acumulan como copias para entrenar los 6 IVs (0 a 31).
          </p>
        </div>

        {/* Marcadores de Progreso */}
        <div className="flex items-center gap-3">
          <div className="flex flex-col items-center bg-[#f6f2e8] border border-[#2d5a43]/20 px-3 py-2 rounded-lg">
            <span className="text-[10px] uppercase font-bold text-[#556b5f]">Capturados</span>
            <span className="font-['Press_Start_2P'] text-xs sm:text-sm text-[#2d5a43]">
              {totalCaught}/151
            </span>
          </div>

          <div className="flex flex-col items-center bg-[#f6f2e8] border border-[#2d5a43]/20 px-3 py-2 rounded-lg">
            <span className="text-[10px] uppercase font-bold text-[#556b5f]">Caramelos Raros</span>
            <span className="font-mono font-bold text-sm text-[#d89b25]">{oakCandies}</span>
          </div>
        </div>
      </div>

      {/* Barra de Búsqueda y Filtros */}
      <div className="bg-[#f6f2e8] border-2 border-[#1a3d2f]/20 rounded-xl p-3 flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        {/* Buscador */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-[#556b5f] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Buscar por nombre o número (ej: Pikachu, 25)..."
            className="w-full pl-9 pr-3 py-1.5 bg-[#ede4cf] border border-[#c8bc9f] rounded-lg text-xs font-medium text-[#1a3d2f] focus:outline-none focus:ring-1 focus:ring-[#1a3d2f]"
          />
        </div>

        {/* Filtro por Estado */}
        <div className="flex items-center gap-1 bg-[#ede4cf] p-1 rounded-lg">
          {(
            [
              { id: 'all', label: 'Todos' },
              { id: 'caught', label: `Capturados (${totalCaught})` },
              { id: 'missing', label: `Faltan (${151 - totalCaught})` },
            ] as const
          ).map((s) => (
            <button
              key={s.id}
              onClick={() => setSelectedStatus(s.id)}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                selectedStatus === s.id
                  ? 'bg-[#1a3d2f] text-[#f4ecd8]'
                  : 'text-[#556b5f] hover:text-[#1a3d2f]'
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* Rejilla de la Pokédex */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2.5">
        {filteredList.map((species) => {
          const entry = pokedex[species.id];
          const isCaught = Boolean(entry?.caught);
          const isSeen = Boolean(entry?.seen);
          const inst = [...team, ...pcBox].find((p) => p.speciesId === species.id);
          const copyBalance = inst?.upgradeCopies || 0;

          return (
            <button
              key={species.id}
              onClick={() => handleInspect(species.id)}
              className={`relative p-2.5 rounded-xl border flex flex-col items-center text-center transition-all cursor-pointer ${
                isCaught
                  ? 'bg-[#ede4cf] border-[#1a3d2f]/30 hover:border-[#1a3d2f] hover:shadow-md'
                  : isSeen
                  ? 'bg-[#ede4cf]/50 border-[#c8bc9f] opacity-75'
                  : 'bg-[#ded1b5]/30 border-dashed border-[#c8bc9f] opacity-40'
              }`}
            >
              {/* Número de Pokédex y saldo de copias */}
              <div className="w-full flex items-center justify-between text-[10px] font-mono text-[#556b5f] mb-1">
                <span>#{species.id.toString().padStart(3, '0')}</span>
                {isCaught && copyBalance > 0 && (
                  <span className="text-[9px] bg-[#d8ecd8] text-[#2d5a43] px-1 rounded font-bold">
                    {copyBalance} copias
                  </span>
                )}
              </div>

              {/* Sprite o Silueta */}
              <div className="h-16 flex items-center justify-center my-1">
                {isCaught || isSeen ? (
                  <PokemonSprite
                    speciesId={species.id}
                    size="sm"
                    className={!isCaught ? 'brightness-0 opacity-40' : ''}
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-[#1a3d2f]/10 flex items-center justify-center text-[#556b5f] font-mono text-xs">
                    ?
                  </div>
                )}
              </div>

              {/* Nombre */}
              <h3 className="text-xs font-bold text-[#1a3d2f] truncate w-full mt-0.5">
                {isCaught || isSeen ? species.name : '???'}
              </h3>

              {/* Tipos */}
              <div className="flex justify-center gap-1 mt-1">
                {isCaught ? (
                  species.types.map((t) => (
                    <span
                      key={t}
                      className="px-1 py-0.2 rounded text-[8px] uppercase font-bold text-white"
                      style={{ backgroundColor: TYPE_COLORS[t].bg }}
                    >
                      {t}
                    </span>
                  ))
                ) : (
                  <span className="text-[9px] text-[#8a8a79] italic">Desconocido</span>
                )}
              </div>
            </button>
          );
        })}
      </div>

      {/* Modal de Detalle de la Pokédex */}
      {inspectedSpecies && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs">
          <div className="relative w-full max-w-xl bg-[#f6f2e8] border-3 border-[#1a3d2f] rounded-2xl shadow-2xl p-5 flex flex-col gap-4 text-[#1c2e24] max-h-[90vh] overflow-y-auto">
            {/* Cabecera del Inspector */}
            <div className="flex items-start justify-between pb-2 border-b border-[#1a3d2f]/20">
              <div className="flex items-center gap-3">
                <PokemonSprite speciesId={inspectedSpecies.id} size="md" />
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs text-[#556b5f]">
                      #{inspectedSpecies.id.toString().padStart(3, '0')}
                    </span>
                    <h2 className="text-base sm:text-lg font-bold text-[#1a3d2f]">
                      {inspectedSpecies.name}
                    </h2>
                    {ownedInstance && (
                      <span className="font-mono text-xs text-[#2d5a43] bg-[#d8ecd8] px-2 py-0.5 rounded font-bold">
                        Nv.{ownedInstance.level}
                      </span>
                    )}
                  </div>
                  <div className="flex gap-1.5 mt-1">
                    {inspectedSpecies.types.map((t) => (
                      <span
                        key={t}
                        className="px-2 py-0.5 rounded text-[10px] uppercase font-bold text-white"
                        style={{ backgroundColor: TYPE_COLORS[t].bg }}
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <button
                onClick={() => setInspectSpeciesId(null)}
                className="w-7 h-7 rounded-md bg-[#ded1b5] hover:bg-[#c8bc9f] flex items-center justify-center font-bold text-xs cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Descripción oficial */}
            <div className="bg-[#ede4cf] p-3 rounded-lg border border-[#c8bc9f] text-xs leading-relaxed text-[#2d5a43] italic">
              «{inspectedSpecies.description}»
            </div>

            {/* Botón de Ficha de Pokémon para ver las 6 estadísticas y subir IVs */}
            {ownedInstance && (
              <div className="bg-[#ede4cf] p-3.5 rounded-xl border border-[#c8bc9f] flex items-center justify-between gap-3">
                <div>
                  <span className="text-xs font-bold text-[#1a3d2f] block">
                    Ficha de Pokémon & Entrenamiento de IVs
                  </span>
                  <span className="text-[11px] text-[#556b5f]">
                    Saldo disponible: <strong className="text-[#1a3d2f]">{ownedInstance.upgradeCopies}</strong> copias de mejora
                  </span>
                </div>

                <button
                  onClick={() => {
                    setInspectSpeciesId(null);
                    onOpenCardModal(ownedInstance);
                  }}
                  className="px-3.5 py-2 bg-[#1a3d2f] hover:bg-[#25523f] text-[#f4ecd8] text-xs font-bold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                >
                  <Table className="w-3.5 h-3.5 text-[#d89b25]" />
                  <span>Abrir Ficha de IVs</span>
                </button>
              </div>
            )}

            {/* Estadísticas Base Oficiales (las 6 estadísticas) */}
            <div className="bg-[#ede4cf] p-3 rounded-lg border border-[#c8bc9f]">
              <span className="text-[11px] font-bold text-[#1a3d2f] block mb-2">
                Estadísticas Base Oficiales (Inmutables)
              </span>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 text-center font-mono text-xs">
                <div className="bg-[#f6f2e8] p-1.5 rounded border border-[#c8bc9f]">
                  <span className="text-[9px] text-[#556b5f] block">PS</span>
                  <span className="font-bold text-[#1a3d2f]">{inspectedSpecies.baseStats.hp}</span>
                </div>
                <div className="bg-[#f6f2e8] p-1.5 rounded border border-[#c8bc9f]">
                  <span className="text-[9px] text-[#556b5f] block">Ataque</span>
                  <span className="font-bold text-[#1a3d2f]">{inspectedSpecies.baseStats.attack}</span>
                </div>
                <div className="bg-[#f6f2e8] p-1.5 rounded border border-[#c8bc9f]">
                  <span className="text-[9px] text-[#556b5f] block">Defensa</span>
                  <span className="font-bold text-[#1a3d2f]">{inspectedSpecies.baseStats.defense}</span>
                </div>
                <div className="bg-[#f6f2e8] p-1.5 rounded border border-[#c8bc9f]">
                  <span className="text-[9px] text-[#556b5f] block">Atq. Esp</span>
                  <span className="font-bold text-[#1a3d2f]">{inspectedSpecies.baseStats.spAtk}</span>
                </div>
                <div className="bg-[#f6f2e8] p-1.5 rounded border border-[#c8bc9f]">
                  <span className="text-[9px] text-[#556b5f] block">Def. Esp</span>
                  <span className="font-bold text-[#1a3d2f]">{inspectedSpecies.baseStats.spDef}</span>
                </div>
                <div className="bg-[#f6f2e8] p-1.5 rounded border border-[#c8bc9f]">
                  <span className="text-[9px] text-[#556b5f] block">Velocidad</span>
                  <span className="font-bold text-[#1a3d2f]">{inspectedSpecies.baseStats.speed}</span>
                </div>
              </div>
            </div>

            {/* Sección de Evolución (preserva nivel, EXP e IVs; consolida si ya existe) */}
            {inspectedSpecies.evolution && ownedInstance && (
              <div className="bg-[#ede4cf] p-3 rounded-lg border border-[#c8bc9f]">
                <span className="text-xs font-bold text-[#1a3d2f] block mb-2">
                  Método de Evolución
                </span>

                {/* Evolución por Nivel */}
                {inspectedSpecies.evolution.type === 'level' && (() => {
                  const evo = inspectedSpecies.evolution;
                  const canEvo = ownedInstance.level >= evo.level;

                  return (
                    <div className="flex flex-col gap-2">
                      <p className="text-xs text-[#556b5f]">
                        Evoluciona a{' '}
                        <strong>{POKEMON_BY_ID[evo.into]?.name}</strong> al
                        alcanzar el <strong>Nivel {evo.level}</strong> (conserva nivel, EXP e IVs).
                      </p>

                      {canEvo && (
                        <div className="flex items-center justify-between p-2 bg-[#f6f2e8] rounded-md border border-[#2d5a43]">
                          <span className="text-xs font-bold text-[#2d5a43]">
                            ¡Listo para evolucionar a {POKEMON_BY_ID[evo.into]?.name}!
                          </span>
                          <button
                            onClick={() => {
                              onEvolvePokemon(ownedInstance.uid, evo.into);
                              setInspectSpeciesId(null);
                            }}
                            className="px-3 py-1 bg-[#1a3d2f] hover:bg-[#25523f] text-[#f4ecd8] text-xs font-bold rounded cursor-pointer"
                          >
                            Evolucionar ahora
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })()}

                {/* Evolución por Piedra */}
                {inspectedSpecies.evolution.type === 'stone' && (() => {
                  const evo = inspectedSpecies.evolution;
                  const stoneKey = `${evo.stone}_stone`;
                  const hasStone = (items[stoneKey] || 0) > 0;

                  return (
                    <div className="flex flex-col gap-2">
                      <p className="text-xs text-[#556b5f]">
                        Evoluciona a{' '}
                        <strong>{POKEMON_BY_ID[evo.into]?.name}</strong> usando{' '}
                        <strong>Piedra {evo.stone}</strong>.
                      </p>

                      <div className="flex items-center justify-between p-2 bg-[#f6f2e8] rounded-md border border-[#c8bc9f]">
                        <span className="text-xs font-bold">
                          {hasStone ? `Tienes Piedra ${evo.stone}` : `Requiere Piedra ${evo.stone}`}
                        </span>
                        <button
                          disabled={!hasStone}
                          onClick={() => {
                            onEvolvePokemon(ownedInstance.uid, evo.into, stoneKey);
                            setInspectSpeciesId(null);
                          }}
                          className={`px-3 py-1 rounded text-xs font-bold ${
                            hasStone
                              ? 'bg-[#1a3d2f] hover:bg-[#25523f] text-[#f4ecd8] cursor-pointer'
                              : 'bg-[#ded1b5] text-[#8a8a79] opacity-50 cursor-not-allowed'
                          }`}
                        >
                          {hasStone ? `Usar Piedra ${evo.stone}` : 'Piedra requerida'}
                        </button>
                      </div>
                    </div>
                  );
                })()}

                {/* Evolución por Cable Link */}
                {inspectedSpecies.evolution.type === 'item' && (() => {
                  const evo = inspectedSpecies.evolution;
                  const hasCable = (items.cable_link || 0) > 0;

                  return (
                    <div className="flex flex-col gap-2">
                      <p className="text-xs text-[#556b5f]">
                        Evolución por intercambio: usa el objeto{' '}
                        <strong>Cable Link Evolutivo</strong> para evolucionar a{' '}
                        <strong>{POKEMON_BY_ID[evo.into]?.name}</strong>.
                      </p>

                      <div className="flex items-center justify-between p-2 bg-[#f6f2e8] rounded-md border border-[#c8bc9f]">
                        <span className="text-xs font-bold">
                          {hasCable ? 'Tienes Cable Link' : 'Requiere Cable Link'}
                        </span>
                        <button
                          disabled={!hasCable}
                          onClick={() => {
                            onEvolvePokemon(ownedInstance.uid, evo.into, 'cable_link');
                            setInspectSpeciesId(null);
                          }}
                          className={`px-3 py-1 rounded text-xs font-bold ${
                            hasCable
                              ? 'bg-[#2d5a43] hover:bg-[#1a3d2f] text-[#f4ecd8] cursor-pointer'
                              : 'bg-[#ded1b5] text-[#8a8a79] opacity-50 cursor-not-allowed'
                          }`}
                        >
                          {hasCable ? 'Usar Cable Link' : 'Requiere Cable Link'}
                        </button>
                      </div>
                    </div>
                  );
                })()}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

