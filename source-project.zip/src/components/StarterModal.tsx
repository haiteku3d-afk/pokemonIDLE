import React, { useState } from 'react';
import { PokemonSprite } from './PokemonSprite';
import { POKEMON_BY_ID, TYPE_COLORS } from '../data/pokemon151';
import { retroAudio } from '../utils/audio';

interface StarterModalProps {
  isOpen: boolean;
  onChooseStarter: (speciesId: number) => void;
}

const STARTERS = [
  {
    id: 1,
    species: POKEMON_BY_ID[1],
    advantage: 'Fácil al inicio contra Brock y Misty',
    shortAdvantage: 'Ventaja inicial vs Brock',
    accent: '#589b43',
  },
  {
    id: 4,
    species: POKEMON_BY_ID[4],
    advantage: 'Gran potencial ofensivo de fuego',
    shortAdvantage: 'Poder ofensivo de fuego',
    accent: '#d44f33',
  },
  {
    id: 7,
    species: POKEMON_BY_ID[7],
    advantage: 'Equilibrio defensivo ideal para Kanto',
    shortAdvantage: 'Gran equilibrio defensivo',
    accent: '#3a72b8',
  },
];

export const StarterModal: React.FC<StarterModalProps> = ({ isOpen, onChooseStarter }) => {
  const [selectedId, setSelectedId] = useState<number>(1);

  if (!isOpen) return null;

  const handleConfirm = (idToConfirm?: number) => {
    const finalId = idToConfirm || selectedId;
    try {
      retroAudio.playFanfare();
    } catch {
      // Audio fallback
    }
    onChooseStarter(finalId);
  };

  const handleSelect = (id: number) => {
    // Si vuelve a tocar el que ya está elegido, confirmar directamente
    if (selectedId === id) {
      handleConfirm(id);
      return;
    }
    setSelectedId(id);
    try {
      retroAudio.playClick();
    } catch {
      // Audio fallback
    }
  };

  const selectedPokemon = POKEMON_BY_ID[selectedId];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-2 sm:p-4 bg-black/75 backdrop-blur-xs overscroll-contain">
      <div className="relative w-full max-w-xl sm:max-w-2xl max-h-[94dvh] sm:max-h-[90vh] flex flex-col bg-[#f6f2e8] border-3 sm:border-4 border-[#1a3d2f] rounded-2xl shadow-2xl overflow-hidden text-[#1c2e24]">
        {/* Encabezado fijo del Profesor Oak */}
        <div className="p-3 sm:p-4 border-b-2 border-[#1a3d2f]/20 bg-[#efe7d3] flex items-center gap-3 shrink-0">
          <div className="w-11 h-11 sm:w-14 sm:h-14 rounded-lg bg-[#e7ddc4] border-2 border-[#1a3d2f] flex items-center justify-center shrink-0 shadow-xs">
            <span className="font-['Press_Start_2P'] text-xs sm:text-base text-[#2d5a43]">OAK</span>
          </div>
          <div className="flex-1 min-w-0">
            <span className="text-[10px] sm:text-xs font-bold uppercase tracking-wider text-[#d44f33] block">
              Laboratorio de Pueblo Paleta
            </span>
            <h2 className="text-sm sm:text-lg font-bold font-['Plus_Jakarta_Sans'] text-[#1a3d2f] leading-tight truncate">
              ¡Bienvenido a Kanto Sobres!
            </h2>
            <p className="text-[11px] sm:text-xs text-[#415a4d] line-clamp-2 mt-0.5 leading-snug">
              «Elige a tu primer compañero. Reunirás puntos en cada ruta para abrir sobres coleccionables. Cuentas con curación gratuita siempre para avanzar con seguridad.»
            </p>
          </div>
        </div>

        {/* Cuerpo desplazable con los 3 iniciales y detalles */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-5 space-y-3 sm:space-y-4">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-[#2d5a43]">
                Elige a tu Pokémon Inicial:
              </span>
              <span className="text-[10px] text-[#556b5f] hidden xs:inline">
                (Toca dos veces para elegir)
              </span>
            </div>

            {/* Rejilla de 3 columnas para ver los 3 a la vez tanto en móvil como en escritorio */}
            <div className="grid grid-cols-3 gap-2 sm:gap-3">
              {STARTERS.map((starter) => {
                const isSelected = selectedId === starter.id;
                return (
                  <button
                    key={starter.id}
                    type="button"
                    onClick={() => handleSelect(starter.id)}
                    className={`relative flex flex-col items-center p-2 sm:p-3.5 rounded-xl border-2 text-center transition-all cursor-pointer active:scale-97 select-none ${
                      isSelected
                        ? 'bg-[#f4ecd8] border-[#1a3d2f] shadow-md ring-2 ring-[#2d5a43] -translate-y-0.5'
                        : 'bg-[#ede4cf] border-[#c8bc9f] hover:border-[#8b9d83] opacity-90 hover:opacity-100'
                    }`}
                  >
                    {/* Indicador de seleccionado */}
                    {isSelected ? (
                      <span className="absolute -top-2 px-1.5 py-0.5 bg-[#1a3d2f] text-[#f4ecd8] text-[8px] sm:text-[9px] font-['Press_Start_2P'] uppercase rounded shadow-xs">
                        ✓ ELEGIDO
                      </span>
                    ) : (
                      <span className="absolute -top-2 px-1 py-0.2 bg-[#c8bc9f] text-[#415a4d] text-[8px] font-mono rounded">
                        #{String(starter.id).padStart(3, '0')}
                      </span>
                    )}

                    {/* Sprite del Pokémon */}
                    <div className="h-16 sm:h-20 flex items-center justify-center my-0.5">
                      <PokemonSprite speciesId={starter.id} size="sm" />
                    </div>

                    {/* Nombre */}
                    <h3 className="font-bold text-xs sm:text-sm text-[#1a3d2f] truncate w-full">
                      {starter.species.name}
                    </h3>

                    {/* Tipos */}
                    <div className="flex flex-wrap justify-center gap-0.5 sm:gap-1 mt-1">
                      {starter.species.types.map((t) => (
                        <span
                          key={t}
                          className="text-[8px] sm:text-[10px] uppercase font-bold px-1 sm:px-1.5 py-0.2 sm:py-0.5 rounded-xs"
                          style={{
                            backgroundColor: TYPE_COLORS[t].bg,
                            color: TYPE_COLORS[t].text,
                          }}
                        >
                          {t}
                        </span>
                      ))}
                    </div>

                    {/* Ventaja breve */}
                    <p className="text-[9px] sm:text-[11px] text-[#556b5f] mt-1.5 leading-tight hidden xs:block line-clamp-2 italic">
                      {starter.shortAdvantage}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Ficha Resumen del Pokémon Actualmente Seleccionado */}
          {selectedPokemon && (
            <div className="bg-[#ede4cf] border border-[#c8bc9f] rounded-xl p-2.5 sm:p-3.5 text-xs text-[#2d5a43] space-y-1.5 shadow-xs">
              <div className="flex items-center justify-between gap-2 border-b border-[#c8bc9f]/60 pb-1.5">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-sm text-[#1a3d2f]">
                    {selectedPokemon.name}
                  </span>
                  <span className="text-[11px] px-1.5 py-0.2 bg-[#1a3d2f] text-[#f4ecd8] font-mono rounded">
                    Nv. 5
                  </span>
                </div>
                <div className="flex gap-1">
                  {selectedPokemon.types.map((t) => (
                    <span
                      key={t}
                      className="text-[9px] uppercase font-bold px-1.5 py-0.2 rounded-xs"
                      style={{
                        backgroundColor: TYPE_COLORS[t].bg,
                        color: TYPE_COLORS[t].text,
                      }}
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </div>

              <p className="text-[11px] sm:text-xs text-[#415a4d] leading-relaxed">
                {selectedPokemon.description}
              </p>

              {/* Estadísticas Base */}
              <div className="pt-1">
                <span className="text-[10px] font-bold uppercase text-[#556b5f] block mb-1">
                  Bases de Especie:
                </span>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-1 font-mono text-[10px] sm:text-[11px] text-center">
                  <div className="bg-[#f6f2e8] p-1 rounded border border-[#c8bc9f]/50">
                    <span className="text-[#556b5f] block text-[9px]">PS</span>
                    <strong className="text-[#1a3d2f]">{selectedPokemon.baseStats.hp}</strong>
                  </div>
                  <div className="bg-[#f6f2e8] p-1 rounded border border-[#c8bc9f]/50">
                    <span className="text-[#556b5f] block text-[9px]">Atq</span>
                    <strong className="text-[#1a3d2f]">{selectedPokemon.baseStats.attack}</strong>
                  </div>
                  <div className="bg-[#f6f2e8] p-1 rounded border border-[#c8bc9f]/50">
                    <span className="text-[#556b5f] block text-[9px]">Def</span>
                    <strong className="text-[#1a3d2f]">{selectedPokemon.baseStats.defense}</strong>
                  </div>
                  <div className="bg-[#f6f2e8] p-1 rounded border border-[#c8bc9f]/50">
                    <span className="text-[#556b5f] block text-[9px]">At.Esp</span>
                    <strong className="text-[#1a3d2f]">{selectedPokemon.baseStats.spAtk}</strong>
                  </div>
                  <div className="bg-[#f6f2e8] p-1 rounded border border-[#c8bc9f]/50">
                    <span className="text-[#556b5f] block text-[9px]">Df.Esp</span>
                    <strong className="text-[#1a3d2f]">{selectedPokemon.baseStats.spDef}</strong>
                  </div>
                  <div className="bg-[#f6f2e8] p-1 rounded border border-[#c8bc9f]/50">
                    <span className="text-[#556b5f] block text-[9px]">Vel</span>
                    <strong className="text-[#1a3d2f]">{selectedPokemon.baseStats.speed}</strong>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Pie fijo con el Botón de Confirmación SIEMPRE visible en móvil y escritorio */}
        <div className="p-3 sm:p-4 bg-[#efe7d3] border-t-2 border-[#1a3d2f]/20 shrink-0 flex flex-col sm:flex-row items-center justify-between gap-2.5">
          <div className="text-xs text-[#2d5a43] hidden sm:flex items-center gap-1.5">
            <span>Compañero elegido:</span>
            <strong className="text-[#1a3d2f] text-sm">{selectedPokemon?.name}</strong>
          </div>

          <button
            type="button"
            onClick={() => handleConfirm()}
            className="w-full sm:w-auto px-6 py-3 bg-[#1a3d2f] hover:bg-[#25523f] active:bg-[#122b21] text-[#f4ecd8] font-bold text-sm sm:text-base rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98"
          >
            <span>¡Elegir a {selectedPokemon?.name} y Comenzar!</span>
            <span className="font-['Press_Start_2P'] text-xs">→</span>
          </button>
        </div>
      </div>
    </div>
  );
};

