import React, { useState, useEffect } from 'react';
import { POKEMON_BY_ID, TYPE_COLORS } from '../data/pokemon151';

interface PokemonSpriteProps {
  shiny?: boolean;
  speciesId: number;
  alt?: string;
  className?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
}

const SIZE_MAP = {
  xs: 'w-8 h-8',
  sm: 'w-12 h-12',
  md: 'w-20 h-20',
  lg: 'w-28 h-28',
  xl: 'w-36 h-36',
};

export const PokemonSprite: React.FC<PokemonSpriteProps> = ({
  speciesId,
  alt,
  className = '',
  size = 'md',
  shiny = false,
}) => {
  const [loadError, setLoadError] = useState(false);
  useEffect(() => setLoadError(false), [speciesId, shiny]);
  const species = POKEMON_BY_ID[speciesId];
  const primaryType = species?.types[0] || 'normal';
  const typeColor = TYPE_COLORS[primaryType] || TYPE_COLORS.normal;

  const sizeClass = SIZE_MAP[size];

  // Sprites públicos de alta fidelidad de la Pokédex oficial
  const spriteUrl = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${shiny ? 'shiny/' : ''}${speciesId}.png`;

  if (loadError || !species) {
    // Fallback visual elegante tipo silueta pixel art con colores temáticos
    return (
      <div
        className={`${sizeClass} rounded-lg flex flex-col items-center justify-center p-1 font-mono select-none ${className}`}
        style={{
          backgroundColor: `${typeColor.bg}22`,
          border: `2px dashed ${typeColor.border}`,
        }}
        title={species?.name || `Pokémon #${speciesId}`}
      >
        <svg
          viewBox="0 0 24 24"
          className="w-3/5 h-3/5"
          fill="none"
          stroke={typeColor.border}
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="12" cy="12" r="9" />
          <path d="M3 12h18" />
          <circle cx="12" cy="12" r="3" fill={typeColor.bg} />
        </svg>
        <span className="text-[9px] font-bold mt-0.5 tracking-tighter" style={{ color: typeColor.border }}>
          #{speciesId}
        </span>
      </div>
    );
  }

  return (
    <div className={`relative inline-flex items-center justify-center select-none ${sizeClass} ${className}`}>
      <img
        src={spriteUrl}
        alt={alt || `${species.name}${shiny ? ' variocolor' : ''}`}
        loading="lazy"
        referrerPolicy="no-referrer"
        onError={() => setLoadError(true)}
        className="w-full h-full object-contain filter drop-shadow-sm transition-transform duration-150"
        style={{ imageRendering: 'pixelated' }}
      />
    </div>
  );
};
