import React, { useRef, useState } from 'react';
import { Volume2, VolumeX, Download, Upload, RotateCcw, Save, Check, AlertCircle } from 'lucide-react';
import { GameSave } from '../types/pokemon';
import { saveGame, getDefaultSave, migrateSave } from '../utils/pokemonHelpers';
import { retroAudio } from '../utils/audio';

interface SettingsModalProps {
  isOpen: boolean;
  gameState: GameSave;
  onClose: () => void;
  onUpdateState: (newState: GameSave) => void;
  onResetGame: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  gameState,
  onClose,
  onUpdateState,
  onResetGame,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [saveStatus, setSaveStatus] = useState<string | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);

  if (!isOpen) return null;

  const handleManualSave = () => {
    retroAudio.playClick();
    const ok = saveGame(gameState);
    if (ok) {
      setSaveStatus('¡Partida guardada con éxito en tu navegador!');
      setTimeout(() => setSaveStatus(null), 3000);
    } else {
      setSaveStatus('Error al guardar en el almacenamiento local.');
    }
  };

  const handleExportJson = () => {
    retroAudio.playClick();
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(gameState, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `kanto_sobres_save_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportJson = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const parsed = JSON.parse(content);
        const migrated = migrateSave(parsed);
        if (migrated && typeof migrated === 'object' && migrated.player && Array.isArray(migrated.team)) {
          retroAudio.playRareChime();
          onUpdateState(migrated);
          saveGame(migrated);
          setSaveStatus('¡Partida importada y migrada al nuevo esquema correctamente!');
          setTimeout(() => setSaveStatus(null), 3000);
        } else {
          setSaveStatus('El archivo JSON no corresponde a una partida válida de Kanto Sobres.');
        }
      } catch {
        setSaveStatus('Error al leer el archivo JSON.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-3 sm:p-4 bg-black/65 backdrop-blur-xs overscroll-contain">
      <div className="relative w-full max-w-lg bg-[#f6f2e8] border-3 border-[#1a3d2f] rounded-2xl shadow-2xl p-4 sm:p-5 flex flex-col gap-4 text-[#1c2e24] max-h-[92dvh] overflow-y-auto">
        {/* Cabecera */}
        <div className="flex items-center justify-between pb-2 border-b border-[#1a3d2f]/20">
          <h2 className="text-base sm:text-lg font-bold text-[#1a3d2f]">
            Ajustes y Gestión de Partida
          </h2>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-md bg-[#ded1b5] hover:bg-[#c8bc9f] flex items-center justify-center font-bold text-xs cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Mensaje de estado */}
        {saveStatus && (
          <div className="p-2.5 bg-[#d8ecd8] border border-[#2d5a43] text-[#2d5a43] rounded-lg text-xs font-semibold flex items-center gap-2">
            <Check className="w-4 h-4 shrink-0" />
            <span>{saveStatus}</span>
          </div>
        )}

        {/* Ajustes de Sonido */}
        <div className="bg-[#ede4cf] p-3 rounded-xl border border-[#c8bc9f] flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-[#1a3d2f] block">Efectos de Sonido Chiptune</span>
            <span className="text-[11px] text-[#556b5f]">Sintetizados en tiempo real mediante Web Audio</span>
          </div>

          <button
            onClick={() => {
              const newSound = !gameState.settings.sound;
              retroAudio.enabled = newSound;
              onUpdateState({
                ...gameState,
                settings: { ...gameState.settings, sound: newSound },
              });
              if (newSound) retroAudio.playClick();
            }}
            className="p-2 rounded-lg bg-[#f6f2e8] border border-[#c8bc9f] text-[#2d5a43] hover:bg-[#ffffff] transition-colors cursor-pointer"
          >
            {gameState.settings.sound ? (
              <Volume2 className="w-4 h-4" />
            ) : (
              <VolumeX className="w-4 h-4 text-[#8a8a79]" />
            )}
          </button>
        </div>

        {/* Guardado Manual y Copias de Seguridad */}
        <div className="bg-[#ede4cf] p-3 rounded-xl border border-[#c8bc9f] flex flex-col gap-2.5">
          <span className="text-xs font-bold text-[#1a3d2f] block">
            Guardado Local y Exportación
          </span>
          <p className="text-[11px] text-[#556b5f] leading-relaxed">
            El juego guarda automáticamente tus avances en la memoria de tu navegador (localStorage).
            Puedes exportar un archivo JSON para jugar en otro dispositivo o mantener una copia de respaldo.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-1">
            <button
              onClick={handleManualSave}
              className="px-3 py-2 bg-[#1a3d2f] hover:bg-[#25523f] text-[#f4ecd8] text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Guardar Ahora</span>
            </button>

            <button
              onClick={handleExportJson}
              className="px-3 py-2 bg-[#2d5a43] hover:bg-[#1a3d2f] text-[#f4ecd8] text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Exportar JSON</span>
            </button>
          </div>

          <div className="pt-2 border-t border-[#1a3d2f]/10">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleImportJson}
              accept=".json"
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full py-2 bg-[#f6f2e8] hover:bg-[#ffffff] text-[#1a3d2f] border border-[#c8bc9f] text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Importar Partida desde Archivo JSON</span>
            </button>
          </div>
        </div>

        {/* Estadísticas de Partida */}
        <div className="bg-[#ede4cf] p-3 rounded-xl border border-[#c8bc9f] text-xs font-mono">
          <span className="font-bold text-[#1a3d2f] block mb-1.5 font-['Plus_Jakarta_Sans']">
            Estadísticas Globales
          </span>
          <div className="grid grid-cols-2 gap-2 text-[11px] text-[#556b5f]">
            <div>Victorias: <strong className="text-[#1a3d2f]">{gameState.stats.totalVictories}</strong></div>
            <div>Sobres abiertos: <strong className="text-[#1a3d2f]">{gameState.stats.totalPacksOpened}</strong></div>
            <div>Cartas sorteadas: <strong className="text-[#1a3d2f]">{gameState.stats.totalCardsDrawn}</strong></div>
            <div>Evoluciones logradas: <strong className="text-[#1a3d2f]">{gameState.stats.totalEvolutions}</strong></div>
          </div>
        </div>

        {/* Zona Peligrosa: Reiniciar Partida */}
        <div className="bg-[#fbdcd5]/60 border border-[#d44f33]/30 p-3 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-[#d44f33] block">Reiniciar Aventura</span>
            <span className="text-[10px] text-[#556b5f]">Borra los datos locales y empieza de cero</span>
          </div>

          {!confirmReset ? (
            <button
              onClick={() => setConfirmReset(true)}
              className="px-3 py-1.5 bg-[#d44f33] hover:bg-[#b03a22] text-white text-xs font-bold rounded-lg transition-colors cursor-pointer"
            >
              Reiniciar
            </button>
          ) : (
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => {
                  onResetGame();
                  setConfirmReset(false);
                  onClose();
                }}
                className="px-2.5 py-1 bg-[#d44f33] text-white text-[11px] font-bold rounded cursor-pointer"
              >
                Confirmar
              </button>
              <button
                onClick={() => setConfirmReset(false)}
                className="px-2 py-1 bg-[#ded1b5] text-[#1a3d2f] text-[11px] font-semibold rounded cursor-pointer"
              >
                No
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
