import React, { useState } from 'react';
import { GameSave } from '../types/pokemon';
import { KANTO_ZONES } from '../data/zones';
import { MOVES_DATA } from '../data/moves';
import { POKEMON_BY_ID } from '../data/pokemon151';

const TMS = ['rapidez', 'rayo_burbuja', 'rayo', 'lanzallamas', 'rayo_hielo', 'terremoto'];
export function KantoObjectives({ save, update, mode = 'missions' }: { save: GameSave; update: React.Dispatch<React.SetStateAction<GameSave>>; mode?: 'missions' | 'tms' }) {
  const [selectedUid, setSelectedUid] = useState('');
  const pokemon = [...save.team, ...save.pcBox];
  const selected = pokemon.find(p => p.uid === selectedUid) || pokemon[0];
  const button = 'px-3 py-2 rounded-lg bg-[#1a3d2f] text-[#fff6de] text-xs font-bold disabled:opacity-40';
  const routes = KANTO_ZONES.filter(zone => zone.encounterTable.length > 0 && save.unlockedZones.includes(zone.id));
  return <section className="bg-[#ede4cf] border-2 border-[#1a3d2f]/30 rounded-xl p-4 space-y-4">
    <div><h2 className="font-bold text-[#1a3d2f]">{mode === 'missions' ? 'Misiones de exploración' : 'Máquinas técnicas'}</h2><p className="text-xs text-[#556b5f]">{mode === 'missions' ? 'Recompensas únicas por ruta.' : 'Enseña movimientos y después elige cuáles equipar desde la ficha del Pokémon.'}</p></div>
    {mode === 'missions' && <div className="grid sm:grid-cols-2 gap-2 max-h-72 overflow-auto">
      {routes.flatMap((zone, routeIndex) => ['victories', 'collection'].map(kind => {
        const id = zone.id + ':' + kind;
        const species = [...new Set(zone.encounterTable.map(entry => entry.speciesId))];
        const progress = kind === 'victories' ? save.zoneVictories[zone.id] || 0 : species.filter(id => save.pokedex[id]?.caught).length;
        const goal = kind === 'victories' ? Math.max(30, (zone.requiredVictories || 10) * 3) : species.length;
        const claimed = save.claimedRouteQuests?.includes(id);
        const tm = TMS[KANTO_ZONES.findIndex(candidate => candidate.id === zone.id) % TMS.length];
        return <div key={id} className="rounded-lg bg-[#fffaf0] p-3 border border-[#c8bc9f]">
          <p className="font-bold text-xs">{zone.name} · {kind === 'victories' ? 'Veterano' : 'Coleccionista'}</p>
          <p className="text-xs my-1">{Math.min(progress, goal)}/{goal} {kind === 'victories' ? 'victorias' : 'especies registradas'} · {kind === 'victories' ? '20 fichas' : `MT ${MOVES_DATA[tm].name}`}</p>
          <button className={button} disabled={claimed || progress < goal} onClick={() => update(prev => {
            if (prev.claimedRouteQuests?.includes(id) || !prev.unlockedZones.includes(zone.id)) return prev;
            const current = kind === 'victories' ? prev.zoneVictories[zone.id] || 0 : species.filter(id => prev.pokedex[id]?.caught).length;
            if (current < goal) return prev;
            return { ...prev, claimedRouteQuests: [...(prev.claimedRouteQuests || []), id], trainerTokens: prev.trainerTokens + (kind === 'victories' ? 20 : 0), inventory: kind === 'collection' ? { ...prev.inventory, ['tm:' + tm]: (prev.inventory['tm:' + tm] || 0) + 1 } : prev.inventory };
          })}>{claimed ? 'Reclamado' : 'Reclamar'}</button>
        </div>;
      }))}
    </div>}
    {mode === 'tms' && <div className="border-t border-[#c8bc9f] pt-3">
      <h3 className="font-bold text-sm">Enseñar una MT</h3>
      <select aria-label="Pokémon que aprenderá la MT" className="w-full p-2 my-2 bg-[#fffaf0] border rounded-lg" value={selected?.uid || ''} onChange={event => setSelectedUid(event.target.value)}>
        {pokemon.map(p => <option key={p.uid} value={p.uid}>{p.nickname || POKEMON_BY_ID[p.speciesId].name}{p.isShiny ? ' ✨' : ''}</option>)}
      </select>
      <div className="flex flex-wrap gap-2">{TMS.map(id => {
        const move = MOVES_DATA[id];
        const compatible = !!selected && (move.type === 'normal' || POKEMON_BY_ID[selected.speciesId].types.includes(move.type));
        const learned = selected?.taughtMoves?.includes(id);
        return <button key={id} className={button} disabled={!compatible || learned || !(save.inventory['tm:' + id] > 0)} onClick={() => update(prev => {
          const recipient = [...prev.team, ...prev.pcBox].find(p => p.uid === selected?.uid);
          if (!recipient || recipient.taughtMoves?.includes(id) || !(prev.inventory['tm:' + id] > 0) || !(move.type === 'normal' || POKEMON_BY_ID[recipient.speciesId].types.includes(move.type))) return prev;
          const teach = (p: typeof recipient) => p.uid === recipient.uid ? { ...p, taughtMoves: [...(p.taughtMoves || []), id] } : p;
          return { ...prev, team: prev.team.map(teach), pcBox: prev.pcBox.map(teach), inventory: { ...prev.inventory, ['tm:' + id]: prev.inventory['tm:' + id] - 1 } };
        })}>{move.name} · {save.inventory['tm:' + id] || 0}{learned ? ' · Aprendido' : !compatible ? ' · Incompatible' : ''}</button>;
      })}</div>
      <p className="text-[11px] text-[#556b5f] mt-2">Regla de esta versión: MT normales para todos; otras MT para Pokémon del mismo tipo. Enseñarlas consume una MT, sin reemplazar ataques automáticamente.</p>
    </div>}
    {mode === 'missions' && <p className="text-xs text-[#556b5f]">Variocolores: 1 posibilidad entre 1024 por carta de sobre. Si sale una especie repetida, tu ejemplar conserva la variante permanentemente. No otorga ventaja en combate.</p>}
  </section>;
}
