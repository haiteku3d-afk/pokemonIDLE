import React, { useState } from 'react';
import { ZoneData } from '../types/pokemon';
import { ZONE_IMAGES } from '../data/zoneImages';

export function ZoneImage({ zone, compact = false }: { zone: ZoneData; compact?: boolean }) {
  const [failedUrl, setFailedUrl] = useState('');
  const url = ZONE_IMAGES[zone.id];
  if (!url || failedUrl === url) return null;
  return <figure className="relative overflow-hidden rounded-xl border border-[#1a3d2f]/20 bg-[#bfd6a2]">
    <img src={url} alt={`Vista de ${zone.name} en Pokémon Rojo Fuego`} loading="lazy" referrerPolicy="no-referrer" onError={() => setFailedUrl(url)} className={`w-full object-cover ${compact ? 'h-32' : 'h-44 sm:h-56'}`} style={{ imageRendering: 'pixelated', objectPosition: 'center 55%' }} />
    <figcaption className="absolute bottom-0 inset-x-0 px-3 py-2 text-white text-xs bg-gradient-to-t from-black/80 to-transparent">
      <span className="font-bold">{zone.name}</span><span className="block text-[9px] opacity-80">Rojo Fuego / Verde Hoja · Bulbagarden Archives</span>
    </figcaption>
  </figure>;
}
