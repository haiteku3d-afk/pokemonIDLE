import React from 'react';
import { OwnedPokemon } from '../types/pokemon';
import { getLevelCap } from '../utils/levelCaps';

export function ExperienceBar({ pokemon, badges }: { pokemon: OwnedPokemon; badges: string[] }) {
  const cap = getLevelCap(badges);
  const capped = pokemon.level >= cap.cap;
  const progress = capped ? 100 : Math.max(0, Math.min(100, pokemon.exp / Math.max(1, pokemon.nextLevelExp) * 100));
  return <div className="mt-2">
    <div className="flex justify-between gap-2 text-[10px] text-[#456b95] font-mono"><span>EXP</span><span>{capped ? cap.isMax ? 'Nivel máximo' : `Límite · ${cap.nextLeaderName}` : `${pokemon.exp}/${pokemon.nextLevelExp}`}</span></div>
    <div className="h-1.5 bg-[#cdd9e3] rounded-full overflow-hidden mt-0.5" role="progressbar" aria-label={`Experiencia de ${pokemon.nickname || 'Pokémon'}`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(progress)} aria-valuetext={capped ? `Límite de nivel ${cap.cap}` : `${pokemon.exp} de ${pokemon.nextLevelExp} EXP`}><div className={`h-full transition-all duration-300 ${capped ? 'bg-[#8294a4]' : 'bg-[#478bc6]'}`} style={{ width: `${progress}%` }} /></div>
  </div>;
}
