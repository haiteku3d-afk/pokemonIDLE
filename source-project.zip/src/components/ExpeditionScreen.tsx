import { RouteMastery } from './RouteMastery';
import { ExperienceBar } from './ExperienceBar';
import { calculateExpeditionExperience } from '../utils/expeditionExperience';
import { ZONE_IMAGES } from '../data/zoneImages';
import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Play,
  Pause,
  Heart,
  Sparkles,
  MapPin,
  ChevronRight,
  ShieldAlert,
  Zap,
  Swords,
  Award,
  AlertCircle,
  Layers,
} from 'lucide-react';
import { OwnedPokemon, ZoneData, PendingMoveLearning } from '../types/pokemon';
import { POKEMON_BY_ID, TYPE_COLORS } from '../data/pokemon151';
import { ZONES_BY_ID } from '../data/zones';
import { PokemonSprite } from './PokemonSprite';
import {
  rollFromEncounterTable,
  calculateMaxHp,
  calculateStat,
  expRequiredForLevel,
  recalculatePokemonStats,
} from '../utils/pokemonHelpers';
import {
  COMBAT_ACTION_INTERVAL_MS,
  COMBAT_ENEMY_TRANSITION_MS,
  executeMoveInCombat,
  CombatantSnapshot,
  getAttackIntervalMs,
  getNextUsefulMoveIndex,
  isMoveUseful,
  getEffectiveSpeed,
  getStatStageMultiplier,
  applyStatusTickDamage,
} from '../utils/combatEngine';
import { StatusCondition } from '../types/moves';
import { getLevelCap, getEffectiveLevel } from '../utils/levelCaps';
import { getDefaultEquippedMoves, SPECIES_LEARNSETS } from '../data/speciesLearnsets';
import { MOVES_DATA } from '../data/moves';
import { SHOP_ITEMS_BY_ID } from '../data/items';
import { retroAudio } from '../utils/audio';

interface ExpeditionScreenProps {
  zone: ZoneData;
  team: OwnedPokemon[];
  zonePoints: number;
  zoneVictories: number;
  badges: string[];
  battlePaused: boolean;
  onTogglePause: () => void;
  onEnemyDefeated: (
    zoneId: string,
    expAwarded: number,
    updatedTeam: OwnedPokemon[],
    newPendingMoves?: PendingMoveLearning[]
  ) => void;
  onUpdateTeam: (team: OwnedPokemon[]) => void;
  onGoToPacks: () => void;
  onGoToMap: () => void;
  unlockedDoubleBattle?: boolean;
  unlockedTripleBattle?: boolean;
  activeLaneCount?: 1 | 2 | 3;
  onSetLaneCount?: (count: 1 | 2 | 3) => void;
}

interface WildCombatant {
  speciesId: number;
  level: number;
  name: string;
  currentHp: number;
  maxHp: number;
  attack: number;
  defense: number;
  spAtk: number;
  spDef: number;
  speed: number;
  stages: {
    attack: number;
    defense: number;
    spAtk: number;
    spDef: number;
    speed: number;
  };
  equippedMoves: string[];
  currentMoveIndex: number;
  status?: StatusCondition | null;
  sleepTurns?: number;
}

interface BattleLogEntry {
  id: string;
  text: string;
  type: 'attack' | 'damage' | 'victory' | 'faint' | 'levelup' | 'info';
}

export function MoveAttackBars({ moves, nextIndex, progress, remaining, waiting = false, onReorder }: {
  moves: string[]; nextIndex: number; progress: number; remaining: string; waiting?: boolean; onReorder?: (moves: string[]) => void;
}) {
  const equipped = moves.length ? moves.slice(0, 4) : ['placaje'];
  return <div className="mt-2 pt-2 border-t border-[#c8bc9f]/60 space-y-1.5" aria-label="Secuencia de movimientos">
    {equipped.map((id, index) => {
      const move = MOVES_DATA[id];
      const active = index === nextIndex % equipped.length;
      return <div key={`${id}-${index}`} className={`rounded-lg p-2 border ${active ? 'border-[#2d5a43]/40 bg-[#e6eddb]' : 'border-[#c8bc9f]/40 bg-[#f6f2e8]'}`}>
        <div className="flex items-center justify-between gap-2 text-[10px]">
          <span className="font-bold text-[#1a3d2f]">{index + 1}. {move?.name || id}</span>
          <span className="text-[#556b5f]">{active ? waiting ? 'Esperando rival' : `Próximo · ${remaining}s` : 'En espera'}</span>
        </div>
        {move && <p className="text-[9px] text-[#556b5f] mt-1">
          {move.category === 'fisico' ? 'Físico' : move.category === 'especial' ? 'Especial' : 'Estado'} · {move.type}
          {move.power > 0 ? ` · Potencia ${move.power}` : ''} · Precisión {move.accuracy}%
        </p>}
        {move && <p className="text-[9px] text-[#556b5f] mt-1">{move.effect}</p>}
        {onReorder && <div className="flex gap-1 mt-1">
          {[-1, 1].map(direction => <button type="button" key={direction} disabled={index + direction < 0 || index + direction >= equipped.length} aria-label={`${direction < 0 ? 'Subir' : 'Bajar'} ${move?.name || id}`} className="px-2 py-1 text-[10px] rounded bg-[#ede4cf] disabled:opacity-30" onClick={() => {
            const reordered = [...equipped];
            [reordered[index], reordered[index + direction]] = [reordered[index + direction], reordered[index]];
            onReorder(reordered);
          }}>{direction < 0 ? '↑ Subir' : '↓ Bajar'}</button>)}
        </div>}
        <div className="h-1.5 bg-[#d9d0ba] rounded-full overflow-hidden mt-1" role="progressbar" aria-label={`Carga de ${move?.name || id}`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={active && !waiting ? Math.round(progress) : 0}>
          <div className="h-full bg-[#2d5a43]" style={{ width: `${active && !waiting ? progress : 0}%` }} />
        </div>
      </div>;
    })}
  </div>;
}

export function EffectiveStats({ pokemon, stages, level }: { pokemon: OwnedPokemon | WildCombatant; stages: StatStages; level?: number }) {
  const labels: Record<keyof StatStages, string> = { attack: 'ATQ', defense: 'DEF', spAtk: 'AT. ESP', spDef: 'DEF. ESP', speed: 'VEL' };
  return <div className="flex flex-wrap gap-x-3 gap-y-1 text-[9px] text-[#556b5f] mt-2" aria-label="Estadísticas efectivas">
    {(Object.keys(labels) as (keyof StatStages)[]).map(stat => {
      const base = level !== undefined && 'ivs' in pokemon ? calculateStat(POKEMON_BY_ID[pokemon.speciesId].baseStats[stat], level, pokemon.ivs[stat]) : pokemon[stat];
      const value = stat === 'speed' ? getEffectiveSpeed(base, stages.speed, pokemon.status) : Math.floor(base * getStatStageMultiplier(stages[stat]) * (stat === 'attack' && pokemon.status === 'quemadura' ? 0.5 : 1));
      return <span key={stat}>{labels[stat]} <strong>{value}</strong></span>;
    })}
  </div>;
}

export function StatChanges({ stages }: { stages: StatStages }) {
  const labels: Record<keyof StatStages, string> = { attack: 'Ataque', defense: 'Defensa', spAtk: 'At. especial', spDef: 'Def. especial', speed: 'Velocidad' };
  const changes = (Object.keys(labels) as (keyof StatStages)[]).filter(stat => stages[stat] !== 0);
  if (!changes.length) return null;
  return <div className="flex flex-wrap gap-1 mt-2" aria-label="Cambios de estadísticas">
    {changes.map(stat => <span key={stat} className={`px-2 py-1 rounded-md text-[10px] font-bold ${stages[stat] > 0 ? 'bg-[#d8ecd8] text-[#1a3d2f]' : 'bg-[#f8e4e4] text-[#9b3a2b]'}`}>
      {labels[stat]} {stages[stat] > 0 ? '↑ +' : '↓ '}{stages[stat]}
    </span>)}
  </div>;
}

interface StatStages {
  attack: number;
  defense: number;
  spAtk: number;
  spDef: number;
  speed: number;
}

export const ExpeditionScreen: React.FC<ExpeditionScreenProps> = ({
  zone,
  team,
  zonePoints,
  zoneVictories,
  badges,
  battlePaused,
  onTogglePause,
  onEnemyDefeated,
  onUpdateTeam,
  onGoToPacks,
  onGoToMap,
  unlockedDoubleBattle = false,
  unlockedTripleBattle = false,
  activeLaneCount = 1,
  onSetLaneCount,
}) => {
  const capInfo = getLevelCap(badges);

  // Comprobar si la ruta actual ya fue completada (requisito para permitir multicariles)
  const targetVictories = zone.requiredVictories || 10;
  const isZoneCompleted = zoneVictories >= targetVictories;
  const nextZoneData = zone.nextZoneId ? ZONES_BY_ID[zone.nextZoneId] : null;

  // Límite de carriles activos: rutas nuevas siempre singles (1 carril)
  const effectiveLaneCount: 1 | 2 | 3 = !isZoneCompleted
    ? 1
    : (Math.max(1, Math.min(team.length, activeLaneCount || 1, unlockedTripleBattle ? 3 : unlockedDoubleBattle ? 2 : 1)) as 1 | 2 | 3);

  // Asignación de Pokémon a los carriles (especies estrictamente distintas, sin duplicar)
  const [effectivenessNotices, setEffectivenessNotices] = useState<{ text: string; time: number }[]>([]);
  const [assignedUids, setAssignedUids] = useState<string[]>([]);

  // Sincronizar asignación de carriles con los miembros vivos del equipo
  useEffect(() => {
    setAssignedUids((prev) => {
      const needed = effectiveLaneCount;
      const result = Array.from({ length: needed }, (_, lane) =>
        team.some(p => p.uid === prev[lane] && p.currentHp > 0) ? prev[lane] : ''
      );
      for (let lane = 0; lane < needed; lane++) {
        if (result[lane]) continue;
        const next = team.find(p => p.currentHp > 0 && !result.includes(p.uid));
        // Mantener el último Pokémon si no quedan reservas para este combate.
        result[lane] = next?.uid || (team.some(p => p.uid === prev[lane]) ? prev[lane] : '');
      }
      return result.length === prev.length && result.every((uid, i) => uid === prev[i]) ? prev : result;
    });
  }, [team, effectiveLaneCount]);

  // Estados independientes por carril (hasta 3)
  const [wildEnemies, setWildEnemies] = useState<(WildCombatant | null)[]>([null, null, null]);
  const [laneStages, setLaneStages] = useState<StatStages[]>([
    { attack: 0, defense: 0, spAtk: 0, spDef: 0, speed: 0 },
    { attack: 0, defense: 0, spAtk: 0, spDef: 0, speed: 0 },
    { attack: 0, defense: 0, spAtk: 0, spDef: 0, speed: 0 },
  ]);
  const [playerMoveIndices, setPlayerMoveIndices] = useState<number[]>([0, 0, 0]);
  const [isAttackingPlayer, setIsAttackingPlayer] = useState<boolean[]>([false, false, false]);
  const [isAttackingEnemy, setIsAttackingEnemy] = useState<boolean[]>([false, false, false]);
  const [isTransitioning, setIsTransitioning] = useState<boolean[]>([false, false, false]);
  const [isRecovering, setIsRecovering] = useState(false);
  const [battleLogs, setBattleLogs] = useState<BattleLogEntry[]>([]);

  // Temporizadores independientes por velocidad
  const [playerElapsedMs, setPlayerElapsedMs] = useState<number[]>([0, 0, 0]);
  const [enemyElapsedMs, setEnemyElapsedMs] = useState<number[]>([0, 0, 0]);

  const playerElapsedRefs = useRef<number[]>([0, 0, 0]);
  const enemyElapsedRefs = useRef<number[]>([0, 0, 0]);
  const previousAssignedRef = useRef<string[]>([]);
  useEffect(() => {
    assignedUids.forEach((uid, lane) => {
      const previous = previousAssignedRef.current[lane];
      if (previous === uid) return;
      playerElapsedRefs.current[lane] = 0;
      setPlayerMoveIndices(indices => indices.map((value, i) => i === lane ? 0 : value));
      setLaneStages(stages => stages.map((value, i) => i === lane
        ? { attack: 0, defense: 0, spAtk: 0, spDef: 0, speed: 0 } : value));
      const member = team.find(p => p.uid === uid);
      if (previous && member && member.currentHp > 0) {
        setBattleLogs(logs => [{
          id: `switch-${lane}-${Date.now()}`,
          text: `[Carril ${lane + 1}] ¡Entra ${member.nickname || POKEMON_BY_ID[member.speciesId]?.name}!`,
          type: 'attack',
        }, ...logs.slice(0, 7)]);
      }
    });
    previousAssignedRef.current = [...assignedUids];
  }, [assignedUids, team]);
  const lastTickTimeRef = useRef<number>(Date.now());
  const transitionTimersRef = useRef<(number | null)[]>([null, null, null]);
  const isExecutingRef = useRef<boolean>(false);

  // Spawnea un enemigo salvaje para un carril
  const spawnWildEnemy = useCallback((): WildCombatant | null => {
    if (!zone.encounterTable || zone.encounterTable.length === 0) return null;
    const rolled = rollFromEncounterTable(zone.encounterTable);
    const species = POKEMON_BY_ID[rolled.speciesId];
    if (!species) return null;

    const maxHp = calculateMaxHp(species.baseStats.hp, rolled.level, 0);
    const attack = calculateStat(species.baseStats.attack, rolled.level, 0);
    const defense = calculateStat(species.baseStats.defense, rolled.level, 0);
    const spAtk = calculateStat(species.baseStats.spAtk, rolled.level, 0);
    const spDef = calculateStat(species.baseStats.spDef, rolled.level, 0);
    const speed = calculateStat(species.baseStats.speed, rolled.level, 0);
    const moves = getDefaultEquippedMoves(rolled.speciesId, rolled.level);

    return {
      speciesId: rolled.speciesId,
      level: rolled.level,
      name: species.name,
      currentHp: maxHp,
      maxHp,
      attack,
      defense,
      spAtk,
      spDef,
      speed,
      stages: { attack: 0, defense: 0, spAtk: 0, spDef: 0, speed: 0 },
      equippedMoves: moves,
      currentMoveIndex: 0,
      status: null,
      sleepTurns: 0,
    };
  }, [zone]);

  // Inicializar o restablecer enemigos al cambiar de ruta
  useEffect(() => {
    transitionTimersRef.current.forEach((timer) => {
      if (timer) clearTimeout(timer);
    });
    transitionTimersRef.current = [null, null, null];

    const e0 = spawnWildEnemy();
    const e1 = spawnWildEnemy();
    const e2 = spawnWildEnemy();
    setWildEnemies([e0, e1, e2]);
    setIsTransitioning([false, false, false]);
    playerElapsedRefs.current = [0, 0, 0];
    enemyElapsedRefs.current = [0, 0, 0];
    setPlayerElapsedMs([0, 0, 0]);
    setEnemyElapsedMs([0, 0, 0]);

    setBattleLogs([
      {
        id: `init-${Date.now()}`,
        text: `Has entrado en ${zone.name}. ¡Explorando la zona!`,
        type: 'info',
      },
    ]);
  }, [zone, spawnWildEnemy]);

  // Curación de todo el equipo
  const healTeam = useCallback(() => {
    retroAudio.playRareChime();
    const healed = team.map((p) => ({
      ...p,
      currentHp: p.maxHp,
      status: null,
      sleepTurns: 0,
    }));
    onUpdateTeam(healed);
    setIsRecovering(false);
    setLaneStages([
      { attack: 0, defense: 0, spAtk: 0, spDef: 0, speed: 0 },
      { attack: 0, defense: 0, spAtk: 0, spDef: 0, speed: 0 },
      { attack: 0, defense: 0, spAtk: 0, spDef: 0, speed: 0 },
    ]);
    playerElapsedRefs.current = [0, 0, 0];
    enemyElapsedRefs.current = [0, 0, 0];
    setPlayerElapsedMs([0, 0, 0]);
    setEnemyElapsedMs([0, 0, 0]);
    lastTickTimeRef.current = Date.now();
    setBattleLogs((prev) => [
      {
        id: `heal-${Date.now()}`,
        text: '¡El equipo ha descansado y recuperado todos sus PS de forma gratuita!',
        type: 'info',
      },
      ...prev.slice(0, 7),
    ]);
  }, [team, onUpdateTeam]);

  // Si todo el equipo está debilitado
  const allFainted = team.length > 0 && team.every((p) => p.currentHp <= 0);

  useEffect(() => {
    if (allFainted && !isRecovering) {
      setIsRecovering(true);
      setBattleLogs((prev) => [
        {
          id: `fainted-all-${Date.now()}`,
          text: '¡Todo el equipo se ha debilitado! Pulsa "Curar Equipo" para continuar.',
          type: 'faint',
        },
        ...prev.slice(0, 7),
      ]);
    }
  }, [allFainted, isRecovering]);

  // Manejo de visibilidad de pestaña para suspender ticks atrasados
  useEffect(() => {
    const handleVis = () => {
      lastTickTimeRef.current = Date.now();
    };
    document.addEventListener('visibilitychange', handleVis);
    return () => document.removeEventListener('visibilitychange', handleVis);
  }, []);

  // Limpiar temporizadores de transición al desmontar
  useEffect(() => {
    return () => {
      transitionTimersRef.current.forEach((t) => {
        if (t) clearTimeout(t);
      });
    };
  }, []);

  // Bucle de Combate Independiente por Carril (1, 2 o 3 carriles 1v1 individuales)
  useEffect(() => {
    if (battlePaused || isRecovering) {
      lastTickTimeRef.current = Date.now();
      return;
    }

    lastTickTimeRef.current = Date.now();

    const intervalId = window.setInterval(() => {
      if (isExecutingRef.current) return;

      const now = Date.now();
      const delta = Math.min(100, Math.max(0, now - lastTickTimeRef.current));
      lastTickTimeRef.current = now;

      if (delta <= 0 || document.hidden) return;

      // Iterar por cada carril activo
      for (let laneIdx = 0; laneIdx < effectiveLaneCount; laneIdx++) {
        if (isTransitioning[laneIdx]) continue;

        const assignedUid = assignedUids[laneIdx];
        const playerPoke = team.find((p) => p.uid === assignedUid);
        const wildEnemy = wildEnemies[laneIdx];

        // Carril muerto no ataca: si el Pokémon del carril está debilitado o no hay enemigo, detener carril
        if (!playerPoke || !wildEnemy || playerPoke.currentHp <= 0 || wildEnemy.currentHp <= 0) {
          continue;
        }

        const playerSpec = POKEMON_BY_ID[playerPoke.speciesId];
        const enemySpec = POKEMON_BY_ID[wildEnemy.speciesId];
        if (!playerSpec || !enemySpec) continue;

        // Sumar tiempo a este carril específico
        playerElapsedRefs.current[laneIdx] += delta;
        enemyElapsedRefs.current[laneIdx] += delta;

        const playerSpeed = getEffectiveSpeed(
          playerPoke.speed,
          laneStages[laneIdx].speed,
          playerPoke.status
        );
        const playerContext = { ...playerPoke, stages: laneStages[laneIdx] };
        const pNext = getNextUsefulMoveIndex(playerPoke.equippedMoves || [], playerMoveIndices[laneIdx] || 0, playerContext, wildEnemy);
        const eNext = getNextUsefulMoveIndex(wildEnemy.equippedMoves, wildEnemy.currentMoveIndex, wildEnemy, playerContext);
        const playerInterval = getAttackIntervalMs(playerSpeed, isMoveUseful(playerPoke.equippedMoves?.[pNext] || 'placaje', playerContext, wildEnemy) ? playerPoke.equippedMoves?.[pNext] : 'forcejeo');

        const enemySpeed = getEffectiveSpeed(
          wildEnemy.speed,
          wildEnemy.stages.speed,
          wildEnemy.status
        );
        const enemyInterval = getAttackIntervalMs(enemySpeed, isMoveUseful(wildEnemy.equippedMoves[eNext], wildEnemy, playerContext) ? wildEnemy.equippedMoves[eNext] : 'forcejeo');

        const playerReady = playerElapsedRefs.current[laneIdx] >= playerInterval;
        const enemyReady = enemyElapsedRefs.current[laneIdx] >= enemyInterval;

        if (!playerReady && !enemyReady) continue;

        isExecutingRef.current = true;

        try {
          const effectiveLvl = getEffectiveLevel(playerPoke.level, badges);

          // Snapshots para ejecución aislada 1v1
          const playerSnapshot: CombatantSnapshot = {
            name: playerPoke.nickname || playerSpec.name,
            speciesId: playerPoke.speciesId,
            level: effectiveLvl,
            types: playerSpec.types,
            currentHp: playerPoke.currentHp,
            maxHp: playerPoke.maxHp,
            attack: playerPoke.attack,
            defense: playerPoke.defense,
            spAtk: playerPoke.spAtk,
            spDef: playerPoke.spDef,
            speed: playerPoke.speed,
            stages: { ...laneStages[laneIdx] },
            equippedMoves: playerPoke.equippedMoves || ['placaje'],
            currentMoveIndex: pNext,
            status: playerPoke.status || null,
            sleepTurns: playerPoke.sleepTurns || 0,
            heldItem: playerPoke.heldItem || null,
          };

          const enemySnapshot: CombatantSnapshot = {
            name: wildEnemy.name,
            speciesId: wildEnemy.speciesId,
            level: wildEnemy.level,
            types: enemySpec.types,
            currentHp: wildEnemy.currentHp,
            maxHp: wildEnemy.maxHp,
            attack: wildEnemy.attack,
            defense: wildEnemy.defense,
            spAtk: wildEnemy.spAtk,
            spDef: wildEnemy.spDef,
            speed: wildEnemy.speed,
            stages: { ...wildEnemy.stages },
            equippedMoves: wildEnemy.equippedMoves || ['placaje'],
            currentMoveIndex: eNext,
            status: wildEnemy.status || null,
            sleepTurns: wildEnemy.sleepTurns || 0,
          };

          const playerGoesFirst =
            playerReady && enemyReady ? playerSpeed >= enemySpeed : playerReady;

          if (playerGoesFirst && playerReady) {
            // ATAQUE DEL JUGADOR EN ESTE CARRIL
            playerElapsedRefs.current[laneIdx] = 0;
            const res = executeMoveInCombat(playerSnapshot, enemySnapshot);
            if (res.canAct && res.isHit && res.moveUsed.category !== 'estado') setEffectivenessNotices(prev => { const next = [...prev]; next[laneIdx] = { text: res.effectiveness === 0 ? '¡Inmune!' : res.effectiveness > 1 ? '¡Supereficaz!' : res.effectiveness < 1 ? 'Resistido' : '', time: Date.now() }; return next; });
            retroAudio.playHit();

            const nextMoveIdx =
              (playerSnapshot.currentMoveIndex + 1) %
              Math.max(1, playerSnapshot.equippedMoves.length);
            setPlayerMoveIndices((prev) => {
              const cp = [...prev];
              cp[laneIdx] = nextMoveIdx;
              return cp;
            });

            // Daño residual por turno (Quemadura / Veneno) en el atacante
            const pTick = applyStatusTickDamage(playerSnapshot);

            const newEnemyHp = Math.max(0, enemySnapshot.currentHp - res.damage);
            const newPlayerHp = Math.max(
              0,
              playerSnapshot.currentHp - (res.recoilDamage || 0) - pTick.damage
            );

            // Actualizar etapas de este carril
            setLaneStages((prev) => {
              const cp = [...prev];
              cp[laneIdx] = playerSnapshot.stages;
              return cp;
            });

            // Actualizar estado del rival en este carril
            setWildEnemies((prev) => {
              const cp = [...prev];
              if (cp[laneIdx]) {
                cp[laneIdx] = {
                  ...cp[laneIdx]!,
                  currentHp: newEnemyHp,
                  stages: enemySnapshot.stages,
                  status: enemySnapshot.status,
                  sleepTurns: enemySnapshot.sleepTurns,
                };
              }
              return cp;
            });

            // Actualizar salud y estado del Pokémon del jugador en el equipo
            const updatedTeam = team.map((p) =>
              p.uid === playerPoke.uid
                ? {
                    ...p,
                    currentHp: newPlayerHp,
                    status: playerSnapshot.status,
                    sleepTurns: playerSnapshot.sleepTurns,
                  }
                : p
            );
            onUpdateTeam(updatedTeam);

            const attackLog: BattleLogEntry = {
              id: `atk-p-${laneIdx}-${Date.now()}`,
              text: `[Carril ${laneIdx + 1}] ${res.logMessage}`,
              type: 'attack',
            };

            const tickLogs: BattleLogEntry[] = [];
            if (pTick.damage > 0 && pTick.logMessage) {
              tickLogs.push({
                id: `tick-p-${laneIdx}-${Date.now()}`,
                text: `[Carril ${laneIdx + 1}] ${pTick.logMessage}`,
                type: 'damage',
              });
            }

            if (newEnemyHp <= 0) {
              // ¡ENEMIGO DERROTADO EN ESTE CARRIL!
              retroAudio.playLevelUp();
              playerElapsedRefs.current[laneIdx] = 0;
              enemyElapsedRefs.current[laneIdx] = 0;

              // EXP completa al combatiente y 70% para cada compañero vivo.
              let levelUpText = '';
              let expGained = 0;
              const pendingList: PendingMoveLearning[] = [];
              let sharedExpTotal = 0;

              const updatedTeamWon = updatedTeam.map((member) => {
                const isCombatant = member.uid === playerPoke.uid;
                const memberSpec = POKEMON_BY_ID[member.speciesId];

                // Limpiar estados al derrotar rival
                const cleanMember = isCombatant ? { ...member, status: null, sleepTurns: 0 } : { ...member };
                if (cleanMember.currentHp <= 0 || cleanMember.level >= capInfo.cap) {
                  return cleanMember;
                }

                const memberExp = calculateExpeditionExperience({
                  baseExp: enemySpec.baseExp || 60, enemyLevel: wildEnemy.level,
                  receiverLevel: cleanMember.level, levelCap: capInfo.cap,
                  alive: cleanMember.currentHp > 0, active: isCombatant,
                });
                if (isCombatant) expGained = memberExp;
                else sharedExpTotal += memberExp;
                if (memberExp <= 0) return cleanMember;

                let newExp = cleanMember.exp + memberExp;
                let currentLevel = cleanMember.level;
                let currentMember = { ...cleanMember };

                while (newExp >= Math.max(15, expRequiredForLevel(currentLevel + 1) - expRequiredForLevel(currentLevel)) && currentLevel < capInfo.cap) {
                  newExp -= Math.max(15, expRequiredForLevel(currentLevel + 1) - expRequiredForLevel(currentLevel));
                  currentLevel += 1;
                  levelUpText += ` ¡${member.nickname || memberSpec.name} subió al Nivel ${currentLevel}!`;

                  const speciesLearnset = SPECIES_LEARNSETS[member.speciesId] || [];
                  const learnedAtThisLevel = speciesLearnset.filter((m) => m.level === currentLevel);

                  for (const lm of learnedAtThisLevel) {
                    if (!currentMember.equippedMoves?.includes(lm.moveId)) {
                      pendingList.push({
                        pokemonUid: member.uid,
                        pokemonName: member.nickname || memberSpec.name,
                        speciesId: member.speciesId,
                        moveId: lm.moveId,
                      });
                    }
                  }

                  if (
                    POKEMON_BY_ID[currentMember.speciesId]?.evolution?.type === 'level' &&
                    currentLevel >= (POKEMON_BY_ID[currentMember.speciesId].evolution as { level: number }).level
                  ) {
                    const nextEvo = POKEMON_BY_ID[POKEMON_BY_ID[currentMember.speciesId].evolution!.into];
                    if (nextEvo) {
                      currentMember.speciesId = nextEvo.id;
                      currentMember.nickname = nextEvo.name;
                      levelUpText += ` ¡Evolucionó a ${nextEvo.name}!`;
                    }
                  }
                }

                if (currentLevel >= capInfo.cap) newExp = 0;

                return recalculatePokemonStats({
                  ...currentMember,
                  level: currentLevel,
                  exp: newExp,
                });
              });

              const victoryLog: BattleLogEntry = {
                id: `vic-${laneIdx}-${Date.now()}`,
                text: `[Carril ${laneIdx + 1}] ¡${wildEnemy.name} derrotado! +1 Victoria en ${zone.name} (+1 punto)${
                  expGained > 0 ? ` (+${expGained} EXP)` : ''
                }${sharedExpTotal > 0 ? ` · Equipo vivo: +${sharedExpTotal} EXP repartida (70 % por compañero)` : ''}.${levelUpText}`,
                type: 'victory',
              };

              setBattleLogs((prev) => [victoryLog, ...tickLogs, attackLog, ...prev.slice(0, 6)]);

              // Premio de victoria: exactamente 1 punto + 1 victoria SIN multiplicador
              onEnemyDefeated(zone.id, expGained, updatedTeamWon, pendingList);

              // Transición aislada de 2000 ms en este carril
              setIsTransitioning((prev) => {
                const cp = [...prev];
                cp[laneIdx] = true;
                return cp;
              });

              transitionTimersRef.current[laneIdx] = window.setTimeout(() => {
                const nextEnemy = spawnWildEnemy();
                setWildEnemies((prev) => {
                  const cp = [...prev];
                  cp[laneIdx] = nextEnemy;
                  return cp;
                });
                setIsTransitioning((prev) => {
                  const cp = [...prev];
                  cp[laneIdx] = false;
                  return cp;
                });
                setLaneStages((prev) => {
                  const cp = [...prev];
                  cp[laneIdx] = { attack: 0, defense: 0, spAtk: 0, spDef: 0, speed: 0 };
                  return cp;
                });
                playerElapsedRefs.current[laneIdx] = 0;
                enemyElapsedRefs.current[laneIdx] = 0;
                transitionTimersRef.current[laneIdx] = null;
              }, COMBAT_ENEMY_TRANSITION_MS);

              continue;
            }

            setBattleLogs((prev) => [...tickLogs, attackLog, ...prev.slice(0, 6)]);
          } else if (enemyReady) {
            // ATAQUE DEL ENEMIGO EN ESTE CARRIL
            enemyElapsedRefs.current[laneIdx] = 0;
            const res = executeMoveInCombat(enemySnapshot, playerSnapshot);
            if (res.canAct && res.isHit && res.moveUsed.category !== 'estado') setEffectivenessNotices(prev => { const next = [...prev]; next[laneIdx] = { text: res.effectiveness === 0 ? '¡Inmune!' : res.effectiveness > 1 ? '¡Supereficaz!' : res.effectiveness < 1 ? 'Resistido' : '', time: Date.now() }; return next; });
            retroAudio.playHit();

            const nextEnemyMoveIdx =
              (enemySnapshot.currentMoveIndex + 1) %
              Math.max(1, enemySnapshot.equippedMoves.length);

            const eTick = applyStatusTickDamage(enemySnapshot);

            const newPlayerHp = Math.max(0, playerSnapshot.currentHp - res.damage);
            const newEnemyHp = Math.max(
              0,
              enemySnapshot.currentHp - (res.recoilDamage || 0) - eTick.damage
            );

            setLaneStages((prev) => {
              const cp = [...prev];
              cp[laneIdx] = playerSnapshot.stages;
              return cp;
            });

            setWildEnemies((prev) => {
              const cp = [...prev];
              if (cp[laneIdx]) {
                cp[laneIdx] = {
                  ...cp[laneIdx]!,
                  currentHp: newEnemyHp,
                  currentMoveIndex: nextEnemyMoveIdx,
                  stages: enemySnapshot.stages,
                  status: enemySnapshot.status,
                  sleepTurns: enemySnapshot.sleepTurns,
                };
              }
              return cp;
            });

            const updatedTeam = team.map((p) =>
              p.uid === playerPoke.uid
                ? {
                    ...p,
                    currentHp: newPlayerHp,
                    status: playerSnapshot.status,
                    sleepTurns: playerSnapshot.sleepTurns,
                  }
                : p
            );
            onUpdateTeam(updatedTeam);

            const enemyLog: BattleLogEntry = {
              id: `atk-e-${laneIdx}-${Date.now()}`,
              text: `[Carril ${laneIdx + 1}] ${res.logMessage}`,
              type: 'damage',
            };

            const tickLogs: BattleLogEntry[] = [];
            if (eTick.damage > 0 && eTick.logMessage) {
              tickLogs.push({
                id: `tick-e-${laneIdx}-${Date.now()}`,
                text: `[Carril ${laneIdx + 1}] ${eTick.logMessage}`,
                type: 'damage',
              });
            }

            if (newPlayerHp <= 0) {
              // Limpieza de estado al debilitarse el Pokémon del carril
              const faintTeam = team.map((p) =>
                p.uid === playerPoke.uid
                  ? { ...p, currentHp: 0, status: null, sleepTurns: 0 }
                  : p
              );
              onUpdateTeam(faintTeam);

              const faintLog: BattleLogEntry = {
                id: `faint-${laneIdx}-${Date.now()}`,
                text: `[Carril ${laneIdx + 1}] ¡${playerSnapshot.name} se ha debilitado!`,
                type: 'faint',
              };
              setBattleLogs((prev) => [faintLog, ...tickLogs, enemyLog, ...prev.slice(0, 6)]);
              playerElapsedRefs.current[laneIdx] = 0;
            } else {
              setBattleLogs((prev) => [...tickLogs, enemyLog, ...prev.slice(0, 6)]);
            }
          }
        } finally {
          isExecutingRef.current = false;
        }
      }

      setPlayerElapsedMs([...playerElapsedRefs.current]);
      setEnemyElapsedMs([...enemyElapsedRefs.current]);
    }, 50);

    return () => clearInterval(intervalId);
  }, [
    battlePaused,
    isRecovering,
    effectiveLaneCount,
    assignedUids,
    team,
    wildEnemies,
    laneStages,
    playerMoveIndices,
    isTransitioning,
    badges,
    zone,
    capInfo.cap,
    onEnemyDefeated,
    onUpdateTeam,
    spawnWildEnemy,
  ]);

  const routeBackdrop: React.CSSProperties = ZONE_IMAGES[zone.id] ? {
    backgroundImage: 'linear-gradient(rgba(233,240,228,.78), rgba(233,240,228,.78)), url("' + ZONE_IMAGES[zone.id] + '")',
    backgroundSize: 'cover', backgroundPosition: 'center 55%',
  } : {};
  return (
    <div className="max-w-5xl mx-auto px-3 sm:px-6 py-4 flex flex-col gap-4 text-[#1c2e24]">
      <RouteMastery victories={zoneVictories} />
      {/* Barra Superior: Progreso de Ruta y Controles */}
      <div className="bg-[#ede4cf] border-2 border-[#1a3d2f]/30 rounded-xl p-3 sm:p-4 flex flex-col gap-3 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#1a3d2f] text-[#f4ecd8] flex items-center justify-center font-bold text-sm shrink-0">
              #{zone.order}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-bold font-['Plus_Jakarta_Sans'] text-[#1a3d2f]">
                  {zone.name}
                </h1>
                <span className="text-[10px] text-[#2d5a43] font-semibold bg-[#d8ecd8] px-1.5 py-0.5 rounded">
                  Probabilidades GB
                </span>
              </div>
              <p className="text-xs text-[#556b5f] mt-0.5">{zone.subtitle}</p>
            </div>
          </div>

          {/* Botones de navegación rápida */}
          <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#f6f2e8] border border-[#2d5a43]/20 rounded-lg text-xs font-mono">
              <Sparkles className="w-3.5 h-3.5 text-[#d89b25]" />
              <span className="text-[#556b5f]">Puntos locales:</span>
              <span className="font-bold text-sm text-[#1a3d2f] tabular-nums">{zonePoints}</span>
            </div>

            <button
              type="button"
              onClick={onGoToPacks}
              className="px-3 py-1.5 bg-[#2d5a43] hover:bg-[#1a3d2f] text-[#f4ecd8] text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <span>Abrir Sobres</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>

            <button
              type="button"
              onClick={() => {
                onGoToMap();
              }}
              className="px-3 py-1.5 bg-[#e7ddc4] hover:bg-[#ded1b5] text-[#1a3d2f] text-xs font-semibold rounded-lg border border-[#1a3d2f]/20 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <MapPin className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Mapa / Cambiar</span>
            </button>
          </div>
        </div>

        {/* Sub-barra: Objetivo de Victorias & Selector de Carriles */}
        <div className="pt-2 border-t border-[#1a3d2f]/15 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
          {/* Progreso de victorias en esta ruta */}
          <div className="flex items-center gap-2 flex-1">
            <span className="text-[11px] font-bold text-[#1a3d2f] shrink-0">Progreso de Ruta:</span>
            <div className="flex-1 max-w-xs h-2 bg-[#d9d0ba] rounded-full overflow-hidden border border-[#1a3d2f]/20">
              <div
                className={`h-full transition-all duration-300 ${
                  isZoneCompleted ? 'bg-[#2d5a43]' : 'bg-[#d89b25]'
                }`}
                style={{ width: `${Math.min(100, (zoneVictories / targetVictories) * 100)}%` }}
              />
            </div>
            <span className="font-mono text-[11px] text-[#556b5f] shrink-0">
              <strong>{zoneVictories}</strong>/{targetVictories} vic.
            </span>
          </div>

          {/* Selector de Modo Carriles (1, 2 o 3 carriles individuales simultáneos) */}
          <div className="flex items-center gap-1.5 bg-[#f6f2e8] p-1 rounded-lg border border-[#c8bc9f]">
            <span className="text-[10px] font-bold text-[#556b5f] px-1 flex items-center gap-1">
              <Layers className="w-3 h-3 text-[#1a3d2f]" />
              <span>Carriles:</span>
            </span>

            {isZoneCompleted ? (
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => onSetLaneCount?.(1)}
                  className={`px-2 py-0.5 rounded text-[11px] font-bold transition-all ${
                    effectiveLaneCount === 1
                      ? 'bg-[#1a3d2f] text-[#f4ecd8]'
                      : 'bg-[#ede4cf] text-[#556b5f] hover:text-[#1a3d2f]'
                  }`}
                >
                  1
                </button>

                {unlockedDoubleBattle ? (
                  <button
                    type="button"
                    onClick={() => onSetLaneCount?.(2)}
                    className={`px-2 py-0.5 rounded text-[11px] font-bold transition-all ${
                      effectiveLaneCount === 2
                        ? 'bg-[#1a3d2f] text-[#f4ecd8]'
                        : 'bg-[#ede4cf] text-[#556b5f] hover:text-[#1a3d2f]'
                    }`}
                  >
                    2 (Doble)
                  </button>
                ) : (
                  <span
                    className="px-2 py-0.5 rounded text-[10px] text-[#8a8a79] bg-[#ede4cf]/60 flex items-center gap-0.5"
                    title="Requiere superar el Reto Doble tras Brock"
                  >
                    2 🔒
                  </span>
                )}

                {unlockedTripleBattle ? (
                  <button
                    type="button"
                    onClick={() => onSetLaneCount?.(3)}
                    className={`px-2 py-0.5 rounded text-[11px] font-bold transition-all ${
                      effectiveLaneCount === 3
                        ? 'bg-[#1a3d2f] text-[#f4ecd8]'
                        : 'bg-[#ede4cf] text-[#556b5f] hover:text-[#1a3d2f]'
                    }`}
                  >
                    3 (Triple)
                  </button>
                ) : (
                  <span
                    className="px-2 py-0.5 rounded text-[10px] text-[#8a8a79] bg-[#ede4cf]/60 flex items-center gap-0.5"
                    title="Requiere superar el Reto Triple tras Lt. Surge"
                  >
                    3 🔒
                  </span>
                )}
              </div>
            ) : (
              <span className="text-[10px] text-[#d89b25] font-semibold px-1">
                Individual (1 carril hasta completar objetivo)
              </span>
            )}
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* CARRILES DE COMBATE INDIVIDUALES SIMULTÁNEOS (APILADOS VERTICALMENTE 390PX) */}
      {/* ========================================================================= */}
      <div className="space-y-4">
        {Array.from({ length: effectiveLaneCount }).map((_, laneIdx) => {
          const assignedUid = assignedUids[laneIdx];
          const playerPoke = team.find((p) => p.uid === assignedUid) || team[laneIdx];
          const wildEnemy = wildEnemies[laneIdx];
          const playerSpec = playerPoke ? POKEMON_BY_ID[playerPoke.speciesId] : null;
          const enemySpec = wildEnemy ? POKEMON_BY_ID[wildEnemy.speciesId] : null;

          const pSpeed = playerPoke
            ? getEffectiveSpeed(playerPoke.speed, laneStages[laneIdx]?.speed || 0, playerPoke.status)
            : 50;
          const playerContext = playerPoke ? { ...playerPoke, stages: laneStages[laneIdx] } : null;
          const pNext = playerContext && wildEnemy ? getNextUsefulMoveIndex(playerContext.equippedMoves || [], playerMoveIndices[laneIdx] || 0, playerContext, wildEnemy) : 0;
          const eNext = playerContext && wildEnemy ? getNextUsefulMoveIndex(wildEnemy.equippedMoves, wildEnemy.currentMoveIndex, wildEnemy, playerContext) : 0;
          const pInterval = getAttackIntervalMs(pSpeed, playerContext && wildEnemy && !isMoveUseful(playerPoke?.equippedMoves?.[pNext] || 'placaje', playerContext, wildEnemy) ? 'forcejeo' : playerPoke?.equippedMoves?.[pNext]);
          const pFallback = !!playerContext && !!wildEnemy && !isMoveUseful(playerPoke?.equippedMoves?.[pNext] || 'placaje', playerContext, wildEnemy);
          const pDisplayMoves = pFallback ? [...(playerPoke?.equippedMoves || []), 'forcejeo'] : playerPoke?.equippedMoves || [];
          const pElapsed = playerElapsedMs[laneIdx] || 0;
          const pAttackProgress = Math.min(100, (pElapsed / pInterval) * 100);
          const pRemainingSec = Math.max(0, (pInterval - pElapsed) / 1000).toFixed(1);

          const eSpeed = wildEnemy
            ? getEffectiveSpeed(wildEnemy.speed, wildEnemy.stages.speed, wildEnemy.status)
            : 50;
          const eInterval = getAttackIntervalMs(eSpeed, playerContext && wildEnemy && !isMoveUseful(wildEnemy.equippedMoves[eNext], wildEnemy, playerContext) ? 'forcejeo' : wildEnemy?.equippedMoves[eNext]);
          const eFallback = !!playerContext && !!wildEnemy && !isMoveUseful(wildEnemy.equippedMoves[eNext], wildEnemy, playerContext);
          const eDisplayMoves = eFallback ? [...(wildEnemy?.equippedMoves || []), 'forcejeo'] : wildEnemy?.equippedMoves || [];
          const eElapsed = enemyElapsedMs[laneIdx] || 0;
          const eAttackProgress = Math.min(100, (eElapsed / eInterval) * 100);
          const eRemainingSec = Math.max(0, (eInterval - eElapsed) / 1000).toFixed(1);

          const isFainted = !playerPoke || playerPoke.currentHp <= 0;
          const isTrans = isTransitioning[laneIdx];

          return (
            <div
              key={`lane-${laneIdx}`}
              style={routeBackdrop}
              className="bg-[#e9f0e4] border-3 sm:border-4 border-[#1a3d2f] rounded-xl p-3 sm:p-4 shadow-md relative overflow-hidden"
            >
              {/* Etiqueta del Carril y Selector de Pokémon */}
              <div className="flex items-center justify-between mb-2.5 pb-2 border-b border-[#1a3d2f]/20">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 bg-[#1a3d2f] text-[#f4ecd8] font-bold text-xs rounded uppercase font-mono">
                    Carril {laneIdx + 1}
                  </span>
                  <span className="text-[11px] text-[#556b5f] font-mono">
                    Combate 1v1 independiente
                  </span>
                </div>

                {/* Selector de combatiente para este carril */}
                {team.length > 1 && (
                  <select
                    value={assignedUid || ''}
                    disabled={isFainted}
                    onChange={(e) => {
                      const newUid = e.target.value;
                      setAssignedUids((prev) => {
                        const cp = [...prev];
                        // Evitar asignar el mismo Pokémon a varios carriles
                        const otherIdx = cp.findIndex((u, i) => i !== laneIdx && u === newUid);
                        if (otherIdx !== -1) {
                          // Intercambiar
                          cp[otherIdx] = cp[laneIdx];
                        }
                        cp[laneIdx] = newUid;
                        return cp;
                      });
                    }}
                    className="text-xs bg-[#f6f2e8] border border-[#c8bc9f] rounded px-2 py-1 font-semibold text-[#1a3d2f] cursor-pointer"
                  >
                    {team.map((member) => (
                      <option key={member.uid} value={member.uid}>
                        {member.nickname || POKEMON_BY_ID[member.speciesId]?.name} (Nv.{member.level} - {member.currentHp}/{member.maxHp} PS)
                      </option>
                    ))}
                  </select>
                )}
              </div>

              {effectivenessNotices[laneIdx]?.text && Date.now() - effectivenessNotices[laneIdx].time < 2000 && <div role="status" className="text-center font-bold text-sm text-[#1a3d2f] bg-[#f4ecd8] rounded-lg py-2 mb-2">{effectivenessNotices[laneIdx].text}</div>}
              {/* Arena del Carril */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-center">
                {/* HUD y Sprite del Jugador */}
                <div className="bg-[#f6f2e8] border-2 border-[#1a3d2f] rounded-lg p-2.5 shadow-2xs">
                  {playerPoke && playerSpec ? (
                    <div>
                      <div className="flex items-center justify-between text-xs font-bold">
                        <div className="flex items-center gap-1.5 truncate">
                          <span className="text-[#1a3d2f] truncate">
                            {playerPoke.nickname || playerSpec.name}
                          </span>
                          {playerPoke.status && (
                            <span
                              className={`px-1 py-0.2 rounded text-[8px] font-bold text-white uppercase ${
                                playerPoke.status === 'paralisis'
                                  ? 'bg-[#d89b25]'
                                  : playerPoke.status === 'quemadura'
                                  ? 'bg-[#c54a2a]'
                                  : playerPoke.status === 'veneno'
                                  ? 'bg-[#89389e]'
                                  : 'bg-[#5176b5]'
                              }`}
                            >
                              {playerPoke.status === 'paralisis'
                                ? 'PAR'
                                : playerPoke.status === 'quemadura'
                                ? 'QMD'
                                : playerPoke.status === 'veneno'
                                ? 'PSN'
                                : 'DOR'}
                            </span>
                          )}
                          {playerPoke.heldItem && SHOP_ITEMS_BY_ID[playerPoke.heldItem] && (
                            <span className="px-1 py-0.2 rounded text-[8px] font-bold text-white uppercase bg-[#3a72b8]" title={SHOP_ITEMS_BY_ID[playerPoke.heldItem].name}>
                              OBJ
                            </span>
                          )}
                        </div>
                        <span className="font-mono text-[11px] text-[#2d5a43]">Nv.{playerPoke.level}</span>
                      </div>

                      {/* Barra de vida */}
                      <StatChanges stages={laneStages[laneIdx]} />
                      <EffectiveStats pokemon={playerPoke} stages={laneStages[laneIdx]} level={getEffectiveLevel(playerPoke.level, badges)} />
                      <div style={routeBackdrop} className="flex justify-center py-2 rounded-lg bg-[#e6eddb] mt-2">
                        <PokemonSprite
                          key={playerPoke.speciesId}
                          speciesId={playerPoke.speciesId} shiny={playerPoke.isShiny}
                          size="lg"
                          className={isFainted ? 'opacity-40 grayscale' : ''}
                        />
                      </div>
                      <div className="mt-1 h-2 bg-[#d9d0ba] rounded-full overflow-hidden">
                        <div
                          className={`h-full transition-all duration-300 ${
                            playerPoke.currentHp / playerPoke.maxHp > 0.5
                              ? 'bg-[#589b43]'
                              : playerPoke.currentHp / playerPoke.maxHp > 0.2
                              ? 'bg-[#d89b25]'
                              : 'bg-[#d44f33]'
                          }`}
                          style={{
                            width: `${Math.max(0, (playerPoke.currentHp / playerPoke.maxHp) * 100)}%`,
                          }}
                        />
                      </div>
                      <div className="flex justify-between items-center text-[10px] font-mono text-[#556b5f] mt-0.5">
                        <span>PS: {playerPoke.currentHp}/{playerPoke.maxHp}</span>
                        <span>Vel: {pSpeed}</span>
                      </div>

                      <ExperienceBar pokemon={playerPoke} badges={badges} />
                      {/* Barra Próximo Ataque del Jugador */}
                      {!isFainted ? (
                        <MoveAttackBars moves={pDisplayMoves} nextIndex={pFallback ? pDisplayMoves.length - 1 : pNext} progress={pAttackProgress} remaining={pRemainingSec} waiting={isTrans} onReorder={battlePaused && !pFallback ? (moves) => { onUpdateTeam(team.map(p => p.uid === playerPoke.uid ? { ...p, equippedMoves: moves } : p)); setPlayerMoveIndices(indices => indices.map((value, i) => i === laneIdx ? 0 : value)); playerElapsedRefs.current[laneIdx] = 0; } : undefined} />
                      ) : (
                        <div className="mt-2 text-center text-xs font-bold text-[#d44f33] bg-[#f8e4e4] py-1 rounded">
                          Pokémon Debilitado (Carril Inactivo)
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-xs text-[#556b5f] italic">Sin Pokémon asignado</div>
                  )}
                </div>

                {/* HUD y Sprite del Rival */}
                <div className="bg-[#f6f2e8] border-2 border-[#1a3d2f] rounded-lg p-2.5 shadow-2xs">
                  {wildEnemy && enemySpec && !isTrans ? (
                    <div>
                      <div className="flex items-center justify-between text-xs font-bold">
                        <div className="flex items-center gap-1.5 truncate">
                          <span className="text-[#1a3d2f] truncate">{wildEnemy.name}</span>
                          {wildEnemy.status && (
                            <span
                              className={`px-1 py-0.2 rounded text-[8px] font-bold text-white uppercase ${
                                wildEnemy.status === 'paralisis'
                                  ? 'bg-[#d89b25]'
                                  : wildEnemy.status === 'quemadura'
                                  ? 'bg-[#c54a2a]'
                                  : wildEnemy.status === 'veneno'
                                  ? 'bg-[#89389e]'
                                  : 'bg-[#5176b5]'
                              }`}
                            >
                              {wildEnemy.status === 'paralisis'
                                ? 'PAR'
                                : wildEnemy.status === 'quemadura'
                                ? 'QMD'
                                : wildEnemy.status === 'veneno'
                                ? 'PSN'
                                : 'DOR'}
                            </span>
                          )}
                        </div>
                        <span className="font-mono text-[11px] text-[#d44f33]">Nv.{wildEnemy.level}</span>
                      </div>

                      {/* Barra de vida rival */}
                      <StatChanges stages={wildEnemy.stages} />
                      <EffectiveStats pokemon={wildEnemy} stages={wildEnemy.stages} />
                      <div style={routeBackdrop} className="flex justify-center py-2 rounded-lg bg-[#e6eddb] mt-2">
                        <PokemonSprite
                          key={wildEnemy.speciesId}
                          speciesId={wildEnemy.speciesId}
                          size="lg"
                        />
                      </div>
                      <div className="mt-1 h-2 bg-[#d9d0ba] rounded-full overflow-hidden">
                        <div
                          className={`h-full transition-all duration-300 ${
                            wildEnemy.currentHp / wildEnemy.maxHp > 0.5
                              ? 'bg-[#589b43]'
                              : wildEnemy.currentHp / wildEnemy.maxHp > 0.2
                              ? 'bg-[#d89b25]'
                              : 'bg-[#d44f33]'
                          }`}
                          style={{
                            width: `${Math.max(0, (wildEnemy.currentHp / wildEnemy.maxHp) * 100)}%`,
                          }}
                        />
                      </div>
                      <div className="flex justify-between items-center text-[10px] font-mono text-[#556b5f] mt-0.5">
                        <span>PS: {wildEnemy.currentHp}/{wildEnemy.maxHp}</span>
                        <span>Vel: {eSpeed}</span>
                      </div>

                      {/* Barra Próximo Ataque del Rival */}
                      <MoveAttackBars moves={eDisplayMoves} nextIndex={eFallback ? eDisplayMoves.length - 1 : eNext} progress={eAttackProgress} remaining={eRemainingSec} />
                    </div>
                  ) : (
                    <div className="text-xs text-[#556b5f] italic text-center py-4">
                      {isTrans
                        ? 'Esperando al próximo enemigo (2.0s)...'
                        : 'Buscando Pokémon salvaje...'}
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Controles de Batalla y Registro */}
      <div className="bg-[#ede4cf] border-2 border-[#1a3d2f]/30 rounded-xl p-3 sm:p-4 flex flex-col gap-3 shadow-xs">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onTogglePause}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
                battlePaused
                  ? 'bg-[#2d5a43] text-[#f4ecd8]'
                  : 'bg-[#ded1b5] text-[#1a3d2f] hover:bg-[#c8bc9f]'
              }`}
            >
              {battlePaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
              <span>{battlePaused ? 'Reanudar Combate' : 'Pausar Combate'}</span>
            </button>

            <button
              type="button"
              onClick={healTeam}
              className="px-3 py-1.5 bg-[#d44f33] hover:bg-[#b03e26] text-white text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Heart className="w-3.5 h-3.5 fill-current" />
              <span>Curar Equipo</span>
            </button>
          </div>

          <span className="text-[11px] font-mono text-[#556b5f]">
            Registro de combates en tiempo real
          </span>
        </div>

        {/* Registro de combate */}
        <div className="bg-[#f6f2e8] p-3 rounded-lg border border-[#c8bc9f] max-h-[130px] overflow-y-auto space-y-1 text-xs font-mono">
          {battleLogs.map((log) => (
            <div
              key={log.id}
              className={`p-1 rounded ${
                log.type === 'victory'
                  ? 'bg-[#d8ecd8] text-[#1a3d2f] font-bold'
                  : log.type === 'faint'
                  ? 'bg-[#f8e4e4] text-[#9b3a2b] font-bold'
                  : 'bg-[#ede4cf] text-[#1c2e24]'
              }`}
            >
              {log.text}
            </div>
          ))}
        </div>
        <section aria-label="Equipo de expedición" className="border-t border-[#c8bc9f] pt-3">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-sm font-bold text-[#1a3d2f]">Tu equipo</h2>
            <span className="text-xs text-[#556b5f]">{team.length}/6 Pokémon</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
            {team.map((member) => {
              const species = POKEMON_BY_ID[member.speciesId];
              const lane = assignedUids.slice(0, effectiveLaneCount).indexOf(member.uid);
              const fainted = member.currentHp <= 0;
              return (
                <div key={member.uid} className="bg-[#fffaf0] border border-[#c8bc9f] rounded-xl p-2 text-center">
                  <PokemonSprite speciesId={member.speciesId} shiny={member.isShiny} size="sm" className={fainted ? 'opacity-40 grayscale' : ''} />
                  <p className="text-xs font-bold text-[#1a3d2f] truncate" title={member.nickname || species?.name}>{member.nickname || species?.name}</p>
                  <p className="text-[10px] text-[#556b5f] mt-0.5">Nv. {member.level} · {fainted ? 'Debilitado' : lane >= 0 ? `Combate ${lane + 1}` : 'En reserva'}</p>
                  <div className="h-1.5 bg-[#d9d0ba] rounded-full overflow-hidden mt-2" role="meter" aria-label={`Vida de ${member.nickname || species?.name}`} aria-valuemin={0} aria-valuemax={member.maxHp} aria-valuenow={member.currentHp}>
                    <div className={`h-full transition-all ${fainted ? 'bg-[#d44f33]' : 'bg-[#589b43]'}`} style={{ width: `${Math.max(0, Math.min(100, member.currentHp / member.maxHp * 100))}%` }} />
                  </div>
                  <p className="text-[10px] font-mono text-[#556b5f] mt-1">{member.currentHp}/{member.maxHp} PS</p>
                  <ExperienceBar pokemon={member} badges={badges} />
                </div>
              );
            })}
          </div>
        </section>
      </div>
    </div>
  );
};





