import { PokemonType } from './pokemon';

export type MoveCategory = 'fisico' | 'especial' | 'estado';

export type StatusCondition = 'quemadura' | 'paralisis' | 'sueno' | 'veneno';

export interface MoveStatusEffect {
  status: StatusCondition;
  chance: number; // 1 to 100% chance (e.g. 100 for Onda Trueno, 10 for Rayo)
  target?: 'rival' | 'usuario'; // defaults to 'rival'
}

export interface MoveStatMod {
  stat: 'attack' | 'defense' | 'spAtk' | 'spDef' | 'speed';
  stages: number; // e.g. -1 for Growl/Tail Whip, +2 for Agility
  target: 'rival' | 'usuario';
}

export interface MoveData {
  id: string;
  name: string;
  type: PokemonType;
  category: MoveCategory;
  priority?: number;
  power: number; // 0 for status moves
  accuracy: number; // 100 for 100%
  effect: string;
  statMod?: MoveStatMod;
  statusEffect?: MoveStatusEffect;
  isStruggle?: boolean;
}

export interface LevelUpMove {
  level: number;
  moveId: string;
}
