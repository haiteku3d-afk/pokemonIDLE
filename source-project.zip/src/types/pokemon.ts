/**
 * Tipos de Pokémon y definiciones de Kanto Sobres
 */

export type PokemonType =
  | 'normal'
  | 'fuego'
  | 'agua'
  | 'planta'
  | 'electrico'
  | 'hielo'
  | 'lucha'
  | 'veneno'
  | 'tierra'
  | 'volador'
  | 'psiquico'
  | 'bicho'
  | 'roca'
  | 'fantasma'
  | 'dragon';

export interface BaseStats {
  hp: number;
  attack: number;
  defense: number;
  spAtk: number;
  spDef: number;
  speed: number;
}

export type StatKey = 'hp' | 'attack' | 'defense' | 'spAtk' | 'spDef' | 'speed';

export interface PokemonIVs {
  hp: number;      // 0 a 31
  attack: number;  // 0 a 31
  defense: number; // 0 a 31
  spAtk: number;   // 0 a 31
  spDef: number;   // 0 a 31
  speed: number;   // 0 a 31
}

export type EvolutionMethod =
  | { type: 'level'; level: number; into: number }
  | { type: 'stone'; stone: 'fire' | 'water' | 'thunder' | 'leaf' | 'moon'; into: number }
  | { type: 'item'; item: 'cable_link'; into: number };

export interface PokemonSpecies {
  id: number;
  name: string;
  types: PokemonType[];
  baseStats: BaseStats;
  evolution?: EvolutionMethod;
  catchRate: number;
  baseExp: number;
  description: string;
}

export interface OwnedPokemon {
  isShiny?: boolean;
  taughtMoves?: string[];
  uid: string;
  speciesId: number;
  nickname?: string;
  level: number;
  currentHp: number;
  maxHp: number;
  exp: number;
  nextLevelExp: number;
  attack: number;
  defense: number;
  spAtk: number;
  spDef: number;
  speed: number;
  ivs: PokemonIVs;
  equippedMoves: string[]; // Hasta 4 movimientos equipados en orden cíclico de combate
  status?: 'quemadura' | 'paralisis' | 'sueno' | 'veneno' | null;
  sleepTurns?: number;     // Turnos restantes dormido si está en sueño
  heldItem?: string | null; // Objeto de combate equipado (ej. 'cinta_fuerza', 'gafas_sabias', 'chaleco_defensa')
  upgradeCopies: number;   // Saldo de copias disponibles para mejorar IVs de esta especie
  totalDuplicates: number; // Total histórico de repetidos obtenidos
  obtainedAt: number;
}

export interface EncounterRate {
  speciesId: number;
  minLevel: number;
  maxLevel: number;
  rate: number; // Porcentaje exacto (ej. 55 para 55%)
  isBlueExclusive?: boolean;
}

export interface PendingMoveLearning {
  pokemonUid: string;
  pokemonName: string;
  speciesId: number;
  moveId: string;
}

export interface ZoneData {
  id: string;
  name: string;
  subtitle: string;
  order: number;
  description: string;
  requiredVictories?: number; // Victorias necesarias en esta zona para abrir la siguiente
  unlockRequirement?: {
    badge?: string;
    zoneId?: string;
    milestone?: string;
    requiredVictoriesInZone?: number;
    text: string;
  };
  nextZoneId?: string;
  encounterTable: EncounterRate[];
  blueAlternateTable?: EncounterRate[];
  fishingTable?: {
    oldRod?: EncounterRate[];
    goodRod?: EncounterRate[];
    superRod?: EncounterRate[];
  };
  surfTable?: EncounterRate[];
  isProvisionalTable?: boolean;
}

export interface GymLeader {
  id: string;
  name: string;
  city: string;
  title: string;
  badge: string;
  badgeName: string;
  unlocksText: string;
  team: Array<{
    speciesId: number;
    level: number;
    name: string;
  }>;
  rewardPoints: number;
  rewardItem?: {
    id: string;
    name: string;
    count: number;
  };
  dialogue: {
    intro: string;
    defeat: string;
  };
  cityZoneId?: string;
  previousGymId?: string;
  unlockRequirementText?: string;
  unlockCondition?: {
    previousGymId?: string;
    text: string;
  };
}

export interface Mission {
  id: string;
  title: string;
  category: 'inicial' | 'fosil' | 'regalo' | 'legendario' | 'postgame';
  description: string;
  location: string;
  requirementsText: string;
  isUnlocked: (state: GameSave) => boolean;
  reward: {
    type: 'pokemon' | 'item';
    speciesId?: number;
    level?: number;
    itemId?: string;
    itemCount?: number;
    text: string;
  };
}

export interface PokedexEntry {
  seen: boolean;
  caught: boolean;
  count: number;
  duplicates: number;
}

export interface GameSave {
  claimedRouteQuests?: string[];
  version: number; // version 2
  timestamp: number;
  player: {
    name: string;
    starterChosen: boolean;
    starterId?: number;
  };
  team: OwnedPokemon[];    // Máximo 6, especies estrictamente únicas
  pcBox: OwnedPokemon[];   // Especies estrictamente únicas (total 1 ejemplar por especie entre team y pcBox)
  pokedex: Record<number, PokedexEntry>;
  zonePoints: Record<string, number>;
  zoneVictories: Record<string, number>; // Victorias acumuladas en cada ruta (no disminuyen al comprar sobres)
  activeZoneId: string;
  unlockedZones: string[];
  badges: string[];
  defeatedGyms: string[];
  completedMissions: string[];
  pendingMoves: PendingMoveLearning[]; // Cola de movimientos aprendidos pendientes de equipar o sustituir
  items: Record<string, number>;
  trainerTokens: number; // Fichas ganadas en combates de entrenador (moneda separada de sobres)
  inventory: Record<string, number>; // Inventario de objetos comprados/obtenidos
  completedTrainers: string[]; // IDs de entrenadores derrotados
  trainerRewardHistory?: Record<string, number>;
  trainerCooldowns?: Record<string, number>;
  routeBattleUnlocks?: Record<string, { double: boolean; triple: boolean }>;
  unlockedDoubleBattle: boolean; // Desbloqueo permanente de combates dobles (2 carriles)
  unlockedTripleBattle: boolean; // Desbloqueo permanente de combates triples (3 carriles)
  completedTrials: string[]; // Retos superados ('double_trial', 'triple_trial')
  activeLaneCount: 1 | 2 | 3; // Carriles activos en la ruta actual
  oakCandies: number;
  stats: {
    totalVictories: number;
    totalPacksOpened: number;
    totalCardsDrawn: number;
    totalEvolutions: number;
    totalIvUpgrades?: number;
  };
  settings: {
    sound: boolean;
    battlePaused: boolean;
    battleSpeed?: number; // Obsoleto: Ignorado en favor del ritmo único fijo
  };
}

