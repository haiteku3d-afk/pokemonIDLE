export type ItemCategory = 'evolution' | 'combat';

export interface ShopItem {
  id: string;
  name: string;
  category: ItemCategory;
  cost: number; // en Fichas de Entrenador
  description: string;
  effectText: string;
  requiredBadge?: string;
  badgeName?: string;
  combatModifier?: {
    type: 'physical_attack' | 'special_attack' | 'damage_reduction';
    value: number; // ej. 0.10 (+10% o -10%)
  };
  evolutionTarget?: {
    stone?: 'fire' | 'water' | 'thunder' | 'leaf' | 'moon';
    item?: 'cable_link';
  };
}
