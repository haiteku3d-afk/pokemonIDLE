import assert from 'node:assert/strict';
import { getDefaultSave, migrateSave } from './src/utils/pokemonHelpers';
import { KANTO_TRAINERS } from './src/data/trainers';
import { POKEMON_BY_ID } from './src/data/pokemon151';
import { canRewardTrainer, getTrainerCooldownMs, getTrainerRewardPool, getTrainerRewardOptions, rollTrainerReward, getTrainerWaitMs } from './src/utils/trainerRewards';
import { getRouteTrials } from './src/data/specialTrials';

const now = 100000;
const save = { ...getDefaultSave(), badges: ['boulder', 'thunder'], unlockedZones: ['route-1', 'route-2'], zoneVictories: { 'route-1': 30, 'route-2': 30 } };
const joey = KANTO_TRAINERS[0];
assert(canRewardTrainer(save, joey.id, now));
const waiting = { ...save, trainerCooldowns: { [joey.id]: now + getTrainerCooldownMs(joey) } };
assert(!canRewardTrainer(waiting, joey.id, now));
assert.equal(getTrainerWaitMs(waiting, joey.id, now), 6 * 3600000);
assert(canRewardTrainer(waiting, joey.id, now + 6 * 3600000));
assert.equal(migrateSave(waiting).trainerCooldowns?.[joey.id], now + 6 * 3600000);
assert(!canRewardTrainer(save, 'unknown', now));
assert(!canRewardTrainer(getDefaultSave(), joey.id, now));
for (const trainer of KANTO_TRAINERS) {
  const pool = getTrainerRewardPool(trainer);
  assert(pool.length > 0);
  assert(pool.every(id => POKEMON_BY_ID[id]));
  const options = getTrainerRewardOptions(trainer);
  assert(Math.abs(options.reduce((sum, option) => sum + option.weight, 0) - 100) < 0.000001);
  assert(options.every(option => option.weight > 0));
  assert(pool.includes(rollTrainerReward(trainer, 0)));
  assert(pool.includes(rollTrainerReward(trainer, 0.999999)));
  assert.equal(getTrainerCooldownMs(trainer), ({normal:6, experto:12, elite:24}[trainer.difficulty]) * 3600000);
}
assert(getTrainerRewardPool(KANTO_TRAINERS.find(t => t.id === 'trainer_sammy')!).includes(10));
assert(getRouteTrials('route-1', save)[0].isUnlocked(save));
assert(!getRouteTrials('route-1', save)[1].isUnlocked(save));
const unlocked = { ...save, routeBattleUnlocks: { 'route-1': { double: true, triple: false } } };
assert(getRouteTrials('route-1', unlocked)[0].isCompleted(unlocked));
assert(getRouteTrials('route-1', unlocked)[1].isUnlocked(unlocked));
assert(!getRouteTrials('route-2', unlocked)[0].isCompleted(unlocked));
assert(!getRouteTrials('route-2', unlocked)[1].isUnlocked(unlocked));
assert(!getRouteTrials('route-1', save)[0].isUnlocked({ ...save, zoneVictories: { 'route-1': 29 } }));
const legacy = migrateSave({ ...save, activeZoneId: 'route-1', unlockedDoubleBattle: true, unlockedTripleBattle: true });
assert.deepEqual(legacy.routeBattleUnlocks, { 'route-1': { double: true, triple: true } });
assert(!getRouteTrials('route-2', legacy)[0].isCompleted(legacy));
assert.equal(migrateSave(legacy).routeBattleUnlocks?.['route-1'].triple, true);
console.log('Trainer reward pools, cooldown boundaries/persistence, per-route trials and legacy migration passed.');

const evolvedTrainer = { ...joey, team: [{ speciesId: 6, name: 'Charizard', level: 50 }] };
assert.deepEqual(getTrainerRewardOptions(evolvedTrainer), [{speciesId:4,weight:70},{speciesId:5,weight:20},{speciesId:6,weight:10}]);
assert.equal(rollTrainerReward(evolvedTrainer, .699), 4);
assert.equal(rollTrainerReward(evolvedTrainer, .70), 5);
assert.equal(rollTrainerReward(evolvedTrainer, .90), 6);
const eeveeTrainer = {...joey, team:[{speciesId:134,name:'Vaporeon',level:30},{speciesId:135,name:'Jolteon',level:30}]};
assert.deepEqual(getTrainerRewardOptions(eeveeTrainer), [{speciesId:133,weight:70},{speciesId:134,weight:15},{speciesId:135,weight:15}]);
console.log('Weighted evolution rewards passed: 70/20/10, roll boundaries and Eevee branches.');

const charmeleonTrainer = { ...joey, team: [{ speciesId: 5, name: 'Charmeleon', level: 20 }] };
assert.deepEqual(getTrainerRewardOptions(charmeleonTrainer), [{speciesId:4,weight:70},{speciesId:5,weight:30}]);
assert(!getTrainerRewardPool(charmeleonTrainer).includes(6));
