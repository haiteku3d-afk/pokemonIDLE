import assert from 'node:assert/strict';
import { getAvailableItemEvolutions } from './src/data/items';
import { KANTO_ZONES } from './src/data/zones';
import { KANTO_MISSIONS } from './src/data/gymsAndMissions';
import { POKEMON_BY_ID } from './src/data/pokemon151';
const obtainable = new Set<number>();
for (const zone of KANTO_ZONES) {
  [zone.encounterTable, zone.blueAlternateTable, zone.surfTable, ...Object.values(zone.fishingTable || {})].forEach(table => table?.forEach(entry => obtainable.add(entry.speciesId)));
}
for (const mission of KANTO_MISSIONS) if (mission.reward.speciesId) obtainable.add(mission.reward.speciesId);
console.log('Direct:', obtainable.size);
let changed = true;
while (changed) { changed = false; for (const id of [...obtainable]) { for (const branch of getAvailableItemEvolutions(id)) { if (!obtainable.has(branch.targetSpeciesId)) { obtainable.add(branch.targetSpeciesId); changed = true; } } const evo = POKEMON_BY_ID[id].evolution; if (evo && !obtainable.has(evo.into)) { obtainable.add(evo.into); changed = true; } } }
console.log('Missing:', Array.from({length:151}, (_,i)=>i+1).filter(id=>!obtainable.has(id)).map(id=>({id,name:POKEMON_BY_ID[id].name})));
for (const mission of KANTO_MISSIONS) {
  const zoneId = mission.zoneRequired || mission.pointsRequired?.zoneId;
  if (zoneId && !KANTO_ZONES.some(z=>z.id===zoneId)) console.log('Invalid zone', mission.id,zoneId);
}

assert.equal(obtainable.size, 151);
console.log('Verified all 151 obtainable through packs, events and implemented evolutions.');
