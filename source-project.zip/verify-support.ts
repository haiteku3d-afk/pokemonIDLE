import assert from 'node:assert/strict';
import {CombatantSnapshot,executeMoveInCombat,getAttackIntervalMs,getCombatMoveId,getNextUsefulMoveIndex} from './src/utils/combatEngine';
const make=(moves:string[],hp=120):CombatantSnapshot=>({name:'Prueba',speciesId:19,level:12,types:['normal'],currentHp:hp,maxHp:hp,attack:24,defense:24,spAtk:15,spDef:15,speed:25,stages:{attack:0,defense:0,spAtk:0,spDef:0,speed:0},equippedMoves:moves,currentMoveIndex:0,status:null});
assert.equal(getAttackIntervalMs(25,'latigo'),Math.round(getAttackIntervalMs(25,'placaje')*.6));
assert.equal(getAttackIntervalMs(25,'ataque_rapido'),Math.round(getAttackIntervalMs(25)*.75));
let a=make(['latigo','placaje']),d=make(['placaje']);d.stages.defense=-6;assert.equal(getNextUsefulMoveIndex(a.equippedMoves,0,a,d),1);assert.equal(getCombatMoveId(a,d),'placaje');
a=make(['onda_trueno','placaje']);d.status='veneno';assert.equal(getCombatMoveId(a,d),'placaje');
a=make(['agilidad','placaje']);a.stages.speed=6;assert.equal(getCombatMoveId(a,d),'placaje');
a=make(['onda_trueno']);assert.equal(getCombatMoveId(a,d),'forcejeo');
const originalRandom=Math.random;Math.random=()=>.5;
try {
 a=make(['latigo','placaje']);d=make(['placaje']);d.stages.defense=-6;assert.equal(executeMoveInCombat(a,d).moveUsed.id,'placaje');assert.equal(a.currentMoveIndex,1);
 function fight(moves:string[],hp:number){const p=make(moves),e=make(['placaje'],hp);let elapsed=0,actions=0;while(e.currentHp>0&&actions<1000){elapsed+=getAttackIntervalMs(p.speed,getCombatMoveId(p,e));const result=executeMoveInCombat(p,e);e.currentHp-=result.damage;p.currentHp-=result.recoilDamage||0;p.currentMoveIndex=(p.currentMoveIndex+1)%moves.length;actions++;}assert(e.currentHp<=0);return {seconds:Number((elapsed/1000).toFixed(1)),actions};}
 const short={solo:fight(['placaje'],20),support:fight(['placaje','latigo'],20)};
 const long={solo:fight(['placaje'],120),support:fight(['placaje','latigo'],120)};
 assert(long.support.seconds<long.solo.seconds);
 console.log(JSON.stringify({short,long}));
} finally {Math.random=originalRandom;}
console.log('Passed: support intervals, priority, stage/status skips, execution and comparative damage simulation.');
