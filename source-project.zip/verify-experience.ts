import assert from 'node:assert/strict';
import { calculateExpeditionExperience, getTrainingExperienceBonus } from './src/utils/expeditionExperience';
import { expRequiredForLevel } from './src/utils/pokemonHelpers';
import { getLevelCap } from './src/utils/levelCaps';
const defaults = {baseExp:50,enemyLevel:3,receiverLevel:7,levelCap:14,alive:true,active:true};
const active=calculateExpeditionExperience(defaults),reserve=calculateExpeditionExperience({...defaults,active:false});
assert(active>0 && reserve>0 && reserve<active);
assert.equal(calculateExpeditionExperience({...defaults,alive:false}),0);
assert.equal(calculateExpeditionExperience({...defaults,receiverLevel:14}),0);
assert(calculateExpeditionExperience({...defaults,receiverLevel:13})>0);
assert.equal(getLevelCap([]).cap,14);assert.equal(getLevelCap(['boulder']).cap,21);
assert.equal(getTrainingExperienceBonus(30),1);
function simulate(start:number,target:number,enemyLevel:number,old:boolean){let level=start,exp=0,wins=0;while(level<target&&wins<10000){const diff=level-enemyLevel;const oldFactor=diff<=0?1:diff<=2?.75:diff<=4?.5:diff<=6?.25:diff<=9?.1:0;exp+=old?Math.floor(Math.floor(50*enemyLevel/7)*oldFactor):calculateExpeditionExperience({...defaults,enemyLevel,receiverLevel:level,levelCap:21});wins++;while(exp>=Math.max(15,expRequiredForLevel(level+1)-expRequiredForLevel(level))&&level<target){exp-=Math.max(15,expRequiredForLevel(level+1)-expRequiredForLevel(level));level++;}}return wins;}
const oldWins=simulate(5,10,3,true),newWins=simulate(5,10,3,false);assert(newWins<oldWins);
console.log(JSON.stringify({activeExpAtLevel7:active,reserveExpAtLevel7:reserve,level5to10AgainstLevel3:{before:oldWins,after:newWins},level10to15AgainstLevel8:{before:simulate(10,15,8,true),after:simulate(10,15,8,false)}}));
console.log('Passed: experience improvement, living reserves, fainted exclusion and badge caps.');
